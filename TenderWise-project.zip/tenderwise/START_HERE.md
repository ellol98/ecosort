# Start TenderWise

This is a working Python application with a browser dashboard. It stores your data on your computer.

## 1. Open the application

On Windows, double-click **START.bat**. Python 3.11 or newer must be installed. Your first launch installs packages into the project's own `.venv` folder, so it needs an internet connection. The application opens at **http://127.0.0.1:8765**. Keep the terminal window open while using it.

If you prefer commands, open a terminal in this folder:

```powershell
py -3 launcher.py
```

macOS/Linux:

```sh
python3 launcher.py
```

## 2. Try the fictional demonstration

Click **Load demo**. Six invented construction tenders illustrate the workflow. They are clearly marked as fictional and cannot be sent as live opportunities. Demo mode makes no AI or WhatsApp API calls.

Open an opportunity to see its scope, matching reasons, requirements, risks, missing information and exact source excerpts. The fit score is a rules-based ranking, not a chance of winning.

## 3. Enter the real company profile

Open **Company profile**. Enter your dad's company name, operating locations, construction specialties, classification and actual financial limits. Leave unknown values blank. An empty location list means no geographic restriction; an empty financial limit means unknown, not unlimited. Saving a company profile resets previous approvals because the matching criteria changed.

## 4. Import a real tender

Use **Import tender** to upload a text-based PDF, TXT or HTML file, paste text, or fetch a public HTTPS document you are allowed to process. The original notice and its conditions remain authoritative. Scanned PDFs need OCR first; the app will tell you rather than pretending it read an image.

Without an AI key, labeled fields are extracted by conservative rules. Use the labeled format in `examples/construction-notice.txt` for an offline trial. Unlabeled prose generally needs AI or manual review. PDFs and documents remain local unless you enable the AI API; that sends extracted text to the provider.

## 5. Enable AI

Copy `.env.example` to `.env`. Enter your own `OPENAI_API_KEY`, check that your account supports `OPENAI_MODEL`, and restart the app. Never commit `.env` or paste credentials into tender text. Open a real tender and click **Re-analyze**. A configured provider error is shown as an error, not disguised as successful AI output.

API usage is billed separately by the provider. The application uses an existing trained model; you have not trained a foundation model. Each import normally uses one model request, with at most 60,000 input characters. Large documents are flagged as incomplete and need manual review.

## 6. Add sources

Open **Sources** and add a permitted RSS/Atom feed, JSON endpoint or server-rendered HTML listing. Check the source's permission and enter selectors/field mappings where needed. See `docs/SOURCES.md`. A source is connected only after a successful collection run; a saved URL alone does not prove coverage.

No TenderEgypt account, subscription, API or automated access permission is included. You can start by importing documents your dad may use, then arrange permitted collection with the provider.

## 7. Configure WhatsApp and scheduling

The application starts in **test mode**. Preview and save a dry run without sending anything. For real delivery, follow `docs/WHATSAPP.md`: configure a Meta sender, Graph API version and credentials; obtain the recipient's consent; approve a matching message template; and turn on live mode. The default review policy requires an approval within 24 hours of sending. For hands-free daily draft alerts, turn off **Require a fresh human approval**; this permits recently collected notices and labels unreviewed assessments as drafts. Fictional, closed, unknown-deadline, rejected, stale and already sent versions remain excluded.

The WhatsApp message includes a short study rather than just a title: scope, deadline, bid security, assessment and a check/next step when available. Long digests split into bounded batches; scheduled runs have a configurable message limit so messaging volume stays controlled.

Daily scheduling works while the server is running. For unattended use, deploy the app on an always-on server using `docs/DEPLOYMENT.md`.

## 8. Preserve your work

**Export workspace** downloads a JSON archive of records, versions, feedback, source settings and history. Back up the complete `data/` folder with the server stopped to preserve the database and original uploaded files. The JSON export is readable archival data; there is no automatic JSON restore endpoint.

For a university portfolio, read `docs/PORTFOLIO.md`. Describe the features you actually enabled and measured. A demo is not proof of live coverage or model accuracy.
