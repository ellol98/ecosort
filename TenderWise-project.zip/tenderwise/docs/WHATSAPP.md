# Connect WhatsApp

TenderWise prepares a daily tender digest and can send it through Meta's official
WhatsApp Business Platform. A normal personal WhatsApp account is not an API
credential. Live delivery has not been tested for your account; Meta onboarding,
template approval, account eligibility, and delivery remain external requirements.

## 1. Start with preview mode

Run the application locally and open `http://127.0.0.1:8765`. Import the demo or
your own tender documents, complete the company profile, and review the notices.
Keep `whatsapp_test_mode` enabled. A preview checks the report content without
sending a WhatsApp message or spending a messaging charge.

## 2. Set up a sender with Meta

Start at the [official developer hub](https://whatsappbusiness.com/developers/developer-hub/)
and follow its **Get started** flow. It provides test numbers and integration
resources. You will need a business account/app setup, a registered sender, and
credentials with the permissions required by Meta. Using a dedicated business
sender number makes the initial setup easier to separate from personal chats.

Copy `.env.example` to `.env`, then fill these values from your Meta setup:

```dotenv
WHATSAPP_ACCESS_TOKEN=your_access_token
WHATSAPP_PHONE_NUMBER_ID=your_numeric_sender_phone_number_id
WHATSAPP_API_VERSION=the_supported_version_from_your_Meta_dashboard
WHATSAPP_APP_SECRET=your_Meta_app_secret
WHATSAPP_VERIFY_TOKEN=a_long_random_value_you_choose
```

Use the numeric **phone number ID**, not the sender's telephone number. Set an
explicit supported Graph API version in the form `vNN.N`; the application does
not guess one. Restart the server after changing environment values. Keep `.env`
private and out of Git, screenshots, and portfolio videos. For continuing use,
follow Meta's guidance for appropriate long-lived/system-user credentials and
rotation rather than relying on a temporary dashboard token.

## 3. Obtain consent and an approved template

Ask your dad to agree to the sender, content, and frequency, for example: “I agree
to receive daily tender summaries and important tender corrections from
TenderWise at this number.” Record this agreement in your own records and enable
`whatsapp_opt_in` only after obtaining it. Respect any later request to stop.

In Meta's template manager, request a template in the language you want to use.
The current implementation expects **exactly one body text parameter**. For
example, the body could be:

```text
Your requested TenderWise monitoring update: {{1}}
Please verify the original tender documents before bidding.
```

Submit a realistic sample for `{{1}}`. Meta chooses whether to approve the
template and how to categorize it; this example is not a guarantee of Utility
classification or approval. TenderWise limits the digest parameter to 900
characters and collapses line breaks to spaces. Do not create a template that
requires a second variable or header variable: that shape is not supported here.

Proactive daily summaries generally arrive outside an active conversation, so
they require an approved template. Free-form replies are allowed only within the
24-hour customer-service window following the recipient's last message. See the
[official WhatsApp messaging policy](https://whatsappbusiness.com/policy/?faq=5).

## 4. Configure the recipient in TenderWise

In the application settings, set:

- `whatsapp_recipient`: the full international number, such as `+20…`; the
  application never guesses a country code.
- `whatsapp_template_name`: the exact approved template name.
- `whatsapp_template_approved`: true only after Meta has approved that exact
  one-parameter template in the selected language. This records your confirmation;
  the app does not obtain approval automatically.
- `whatsapp_language`: the exact approved language code, such as `en` or `ar`.
- `whatsapp_opt_in`: true after consent is obtained.
- `whatsapp_enabled`: true when the setup is ready.
- `whatsapp_test_mode`: leave true until you have checked the preview; change it
  to false only when you intend to permit live sends.
- `require_human_review`: true by default, requiring an approval within the last
  24 hours after checking originals/amendments. For hands-free daily draft alerts,
  turn it off; only recently collected real open notices qualify, and unreviewed
  assessments are labeled as drafts. Rejected, stale and fictional notices remain
  excluded under both policies.

Review the selected tenders and use the application's explicit live-send action
for the first test. Test with your own consenting recipient first. An API result
of **accepted** means Meta accepted the request; it does not prove the message
arrived or was read.

Each message includes a bounded mini-study, using scope, location, deadline,
stated bid security, fit/recommendation and a check/next step when available.
Long digests split into exact displayed batches. Scheduled runs send at most
`MAX_WHATSAPP_BATCHES_PER_RUN` messages (default 3, maximum 10); remaining records
stay eligible for a later batch. Only displayed records are marked as sent.

The app's reports are protected. `PUBLIC_BASE_URL` does not create a public
report-sharing service. A WhatsApp digest is useful on its own and should not
contain an inaccessible report link or an administrator token.

## 5. Configure delivery webhooks

For delivery updates, Meta needs a publicly reachable **HTTPS** callback:

```text
https://your-domain.example/webhooks/whatsapp
```

`localhost` and `127.0.0.1` cannot be reached by Meta. Follow the deployment guide
to use a TLS reverse proxy, or use a temporary HTTPS development tunnel for a
controlled test. Do not expose the entire unauthenticated development service.

Set the same chosen `WHATSAPP_VERIFY_TOKEN` in your app environment and Meta's
callback verification screen. The app's GET callback verifies that token. Its
POST callback authenticates Meta's signature using `WHATSAPP_APP_SECRET` and the
exact raw request bytes before processing the event. Subscribe to the relevant
WhatsApp message/status webhook events in Meta's dashboard.

Both GET and POST `/webhooks/whatsapp` intentionally bypass the app's bearer-token
login; they have their own verification. Ensure a reverse proxy does not add a
different login challenge to that route or alter the request body. Other API
routes still require `Authorization: Bearer <ADMIN_TOKEN>` when deployed remotely.

The outbox distinguishes preview, accepted, delivered, read, and failed results
when available. A network timeout or ambiguous provider response can occur after
Meta received a request. Do not blindly retry an unknown delivery state: inspect
the outbox and webhook updates first to avoid duplicate messages.

When a send is definitely rejected by Meta (for example after a configuration
error), correct the setup, then use **Retry after correcting setup** in delivery
history. This explicitly requests `retry_failed:true`; scheduled runs do not
retry such sends automatically. Ambiguous/pending/accepted results are blocked
from retries. Attempt history is retained.

## Cost and access limits

Budget for delivered messages using the recipient's market and Meta's assigned
message category, plus any integration-provider fees. Prices and rules change;
use the current [official pricing FAQ](https://whatsappbusiness.com/resources/faq/)
and your account's rate card. As of October 2026, the FAQ also describes charges
for service messages after a monthly free allowance; do not assume all API
messages are free.

WhatsApp connection does not unlock tender websites. Tender Egypt's automated
access has not been verified for this project. Use permitted feeds, authorized
exports, or manually supplied tender documents until a source is validated.
