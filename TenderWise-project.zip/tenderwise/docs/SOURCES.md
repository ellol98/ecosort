# Connecting real tender sources

TenderWise ships generic adapters, not a verified live TenderEgypt connector.
No external source is enabled by default. Upload a tender notice/PDF first,
validate the results with your father, and then configure one permitted source
at a time. Never represent a successful demonstration as complete tender coverage.

## Source research checked on 28 October 2026

- [TenderEgypt subscription plans](https://tenderegypt.com/plans) offer category
  filtering, email/Telegram delivery, paid WhatsApp add-ons, and tender documents
  where available. A subscription does not itself establish permission to scrape,
  store, republish, or process content with an external AI provider. A public API
  or machine-readable feed was not verified. Its public archive extraction did
  not expose actual notice text during research. Obtain an authorized export/feed
  or clarify permitted processing of subscription content with the provider.
- [Egypt government contracting system](https://gcs.digitalegypt.gov.eg/) and
  [legacy government tender portal](https://etenders.gov.eg/) are relevant
  discovery targets. Both timed out in this research environment; working access,
  automation permission, and adapter selectors remain to be verified locally.
  The [Ministry of Finance circular](https://assets.mof.gov.eg/files/2023-12/14926bd0-998e-11ee-8fda-6b0a772f8261.pdf)
  documents the portal transition. No government-portal API is assumed.
- [ITIDA/MCIT tenders](https://itida.gov.eg/English/ETenders/Pages/default.aspx)
  is a primary, sector-specific discovery page. Its page returned no notices
  during research. That does not establish that no relevant opportunities exist.
- [UNGM opportunity search](https://www.ungm.org/Public/Notice/) has active-only,
  country, deadline and goods/services filters. Public viewing and basic supplier
  registration are free, but [UNGM's terms](https://www.ungm.org/Public/Pages/Terms)
  restrict reuse, dissemination and inclusion in retrieval systems; do not enable
  scraping or import UNGM content into this system without the required permission.
  Its [Developer Center](https://developer.ungm.org/) documents authenticated
  APIs, but access for this project has not been established.
- [World Bank project opportunities](https://projects.worldbank.org/en/projects-operations/opportunities)
  distinguish current, upcoming and merely potential opportunities. Its
  [official email alert guide](https://pubdocs.worldbank.org/en/411131595878223948/Procurement-Notices-alerts-service.pdf)
  describes free alerts by country/product/service. Mailbox ingestion is not
  implemented in this version; use permitted document uploads or a separately
  approved structured source. No tender-notice API endpoint is invented here.

The main product advantage is personalized analysis and a requirements checklist:
TenderEgypt already offers tender alerts over WhatsApp.

## Authorize and test each source

Before setting `permission_confirmed` to `true`, confirm that automated access
and the intended storage, AI processing and delivery are permitted. Record the
permission basis in `permission_note`. This flag records the operator's decision;
the software cannot verify a license or grant permission. Keep source credentials
out of URLs. Authenticated feeds and login automation are not supported.

Start with `fetch_details: false` and manually inspect several returned notices.
Only enable linked-document downloads where permission also covers those links.
Cross-origin redirects are checked for network safety, but the operator must
verify that permission also covers the destination. HTML listing links default
to the same hostname; use `same_origin_only: false` only for known authorized
external document hosts.

## RSS and Atom

The following configuration is a format illustration. `supplier.example` is a
reserved documentation domain and must be replaced with a real authorized URL.

```json
{
  "type": "rss",
  "url": "https://supplier.example/notices.xml",
  "permission_confirmed": true,
  "permission_note": "Record the actual license or written permission here.",
  "limit": 10,
  "fetch_details": false
}
```

RSS item titles, descriptions, links and publication dates are read. Atom entry
titles, content/summary, alternate links and publication/update dates are read.
External XML entities are rejected. Feed excerpts carry
`metadata.document_scope: "listing_excerpt"` and may omit important conditions.

## JSON

```json
{
  "type": "json",
  "url": "https://supplier.example/notices.json",
  "permission_confirmed": true,
  "permission_note": "Record the actual license or written permission here.",
  "items_path": "payload.results",
  "fields": {
    "title": "name",
    "text": "description",
    "url": "document_url",
    "deadline": "closing_date",
    "buyer": "authority.name",
    "reference": "reference_number",
    "status": "status",
    "country": "delivery_country"
  },
  "limit": 25,
  "fetch_details": false
}
```

`items_path` locates an array. An array at the root needs no `items_path`.
Without an explicit path the common `items` or `results` arrays are accepted.
Field values are dotted paths, with numeric segments supported for array indexes.
Published structured facts are included in the text sent for analysis. The
adapter does not infer that a notice is open from its presence in a feed.

## HTML listings

```json
{
  "type": "html",
  "url": "https://supplier.example/tenders",
  "permission_confirmed": true,
  "permission_note": "Record the actual license or written permission here.",
  "selectors": {
    "item": "article.notice",
    "title": "h2",
    "link": "a.details",
    "text": ".description"
  },
  "same_origin_only": true,
  "limit": 10,
  "fetch_details": false
}
```

Selectors must match the actual authorized site's server-rendered HTML. Each
`item` must represent one notice, not the entire page. JavaScript-rendered
listings, CAPTCHAs, anti-bot pages, subscriptions and logins are not bypassed.
Changed HTML can yield zero records; inspect the page and update selectors.

## Document and network limits

- HTTPS on port 443 only; no URL credentials, localhost, private/reserved IPs,
  or DNS answers containing non-public addresses.
- Outbound connections use a validated, pinned IP while retaining the original
  hostname for TLS verification and the HTTP Host header. Environment proxies
  are disabled. Every redirect is revalidated, with at most three redirects.
- Each download is capped at 10 MB of decoded content, with per-operation
  timeouts and an additional 45-second transfer budget checked while streaming.
  DNS lookup duration is controlled by the operating system resolver.
- Text extraction is capped at 2 MB; PDFs at 250 pages and 8 MB of decoded page
  content per page. Parsing is local and does not execute PDF/HTML scripts.
  For an internet-facing multi-user service, isolate document parsing in a
  worker with operating-system memory/time limits before deployment.
- Scanned/image-only PDFs need an OCR step. This version detects missing
  selectable text and raises an explicit error; it does not silently claim OCR
  succeeded. Mixed documents warn about pages without selectable text.
- Arabic/English Unicode TXT, HTML and searchable PDF are supported. Legacy
  Windows-1256 text triggers a decoding warning. Verify PDF Arabic extraction
  order and numbers against the original document.
- At most 25 notices are returned per source run. This version does not paginate
  arbitrary sites automatically. Repeated runs without a provider's stable
  newest-first ordering can miss notices beyond that window; obtain a suitable
  feed or build and test a source-specific pagination adapter before claiming
  broader coverage.

Hashes help deduplicate identical extracted text. They do not merge every
cross-site copy or identify all amendments. A new deadline or cancellation
must be traced to the authoritative latest notice. A deadline in the future
alone does not prove the opportunity is active.

## Eligibility and mini-studies

An Egyptian delivery location, an Egypt country filter, or Egyptian nationality
does not establish a company's eligibility. Check local/international scope,
required registration, licenses, qualifications, financial conditions, supplier
category, submission method, amendments and exclusions against the actual
documents and company profile. Unknown requirements should remain unknown.

Listing excerpts support a preliminary opportunity review. A complete bid study
needs the tender dossier, bill of quantities, specifications, company costs,
capacity and delivery constraints. Do not infer profit, total contract value,
win probability, or confirmed eligibility from an advertisement alone.

For a public portfolio, use clearly labeled fictional fixtures or documents
whose license permits publication. Remove private company data, phone numbers,
credentials and subscription content from screenshots, demos and repositories.
