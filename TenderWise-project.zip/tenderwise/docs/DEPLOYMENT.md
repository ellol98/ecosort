# Run TenderWise reliably

The app is a single-process FastAPI service with SQLite storage and an in-process
daily scheduler. It can be used locally first and then placed on an always-on
machine. No cloud service has been deployed and no recurring job has been
enabled on your behalf.

## Local Windows setup

Install Python 3.12 or newer, then open PowerShell in the project directory:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m uvicorn tenderwise.app:app --host 127.0.0.1 --port 8765 --workers 1
```

Open `http://127.0.0.1:8765`. Local document extraction and demo mode require no
API keys. To use AI, configure the API key/model fields from `.env.example` and
check that your selected model is available to your API account. API usage may
cost money. Keep paid-call limits small while testing.

The default storage is `./data`, relative to the project. It contains business
settings, tender information, and outbox records. Preserve that directory when
updating the code. Stop the server before making a consistent file backup.

## Authentication

Without `ADMIN_TOKEN`, the app allows only loopback clients. Set a strong token
before using a container, LAN address, reverse proxy, or public host. Generate one
locally, then paste it into `.env`:

```powershell
.\.venv\Scripts\python.exe -c "import secrets; print(secrets.token_urlsafe(32))"
```

```dotenv
ADMIN_TOKEN=paste_the_generated_value_here
```

Restart the application. The browser interface asks for the token. Scripts must
send `Authorization: Bearer <ADMIN_TOKEN>` on protected API requests. Do not put
the token in query strings, report links, or public repository files. Use a
different token for each deployed installation.

## Docker Compose

Install Docker with Compose support. In the project directory, copy
`.env.example` to `.env`, set `ADMIN_TOKEN`, and add any optional provider
credentials you intend to use. The Compose file refuses to start with an empty
administrator token.

```powershell
docker compose build
docker compose up -d
docker compose ps
docker compose logs --tail 50 tenderwise
```

Open `http://127.0.0.1:8765` and enter your token. The host port binds to loopback
by default. The server listens on `0.0.0.0:8765` inside its container so Docker
can route requests to it.

The container runs as UID/GID 1000 rather than root. A named Docker volume mounts
at `/app/data`, and the image creates that directory with ownership for that
user. `TENDERWISE_DATA_DIR` is set to `/app/data` by Compose even if your local
`.env` contains the default relative path. If you substitute a Linux bind mount,
ensure its directory is writable by UID 1000. The application code is read-only;
temporary files use `/tmp`.

Check the unauthenticated liveness endpoint with `http://127.0.0.1:8765/health`.
The health check only confirms that the HTTP app responds; it does not verify
tender-source access, AI credentials, template approval, or message delivery.

To stop or update:

```powershell
docker compose down
docker compose up -d --build
```

The named volume survives `docker compose down`. Do not add `--volumes` unless
you intentionally want to erase the saved app data. Before updates, stop the
service and back up the volume, for example with Docker's volume-backup tooling
or by copying `/app/data` out of the stopped container. Keep backups private.

## Public HTTPS deployment

Use a TLS reverse proxy with a certificate for your domain. Configure
`ADMIN_TOKEN` first, then restrict network access so only the proxy can reach
the application port. If the proxy runs on the host, the existing loopback port
binding works. If it is another container, connect it to the same private Docker
network and route to `tenderwise:8765`; avoid publishing an additional public
application port.

Forward requests to the app without rewriting their bodies. Rate-limit public
traffic and keep credentials in environment/secret configuration. The
`/webhooks/whatsapp` route must be reachable by Meta without the app's bearer
login; its GET verify-token and POST signature checks provide the route's own
authentication. See [WHATSAPP.md](WHATSAPP.md) for the callback setup.

Setting `PUBLIC_BASE_URL` does not publish private reports. Public report sharing
is not implemented. Keep administrator credentials out of any URLs sent to a
phone. A digest can contain the key tender details without a report link.

## Scheduling

Set the schedule, hour, minute, and timezone in the app only after a manual run
works. `Africa/Cairo` is the default; the scheduler uses timezone rules including
daylight-saving changes. The internal job runs only while this server is running.
A sleeping laptop, stopped container, or offline host does not collect tenders.

The default policy requires fresh human approval before each live opportunity.
For automatic draft monitoring without a daily approval step, turn off **Require
a fresh human approval**. Such alerts still require fresh collection, an open
submission date, recipient consent and approved-template setup. Drafts are marked
as unreviewed. Each run sends at most `MAX_WHATSAPP_BATCHES_PER_RUN` bounded
messages (default 3, maximum 10); adjust this limit with the messaging budget.

Use **exactly one Uvicorn worker and one running app replica** when the internal
scheduler is enabled. Its single-instance limit is process-local; multiple
workers could each run the same schedule. The provided container command uses
one worker. Avoid `--reload` for an always-on installation.

An external scheduler can call the job endpoint instead. Disable the internal
schedule first. Configure the external system yourself to make a POST request to
`/api/jobs/run` and send the bearer token as a secret header. A PowerShell manual
example, using a token already stored in the process environment, is:

```powershell
$headers = @{ Authorization = "Bearer $env:ADMIN_TOKEN" }
Invoke-RestMethod -Method Post -Uri "https://your-domain.example/api/jobs/run" -Headers $headers
```

Do not enable overlapping external jobs. Persisted outbox state helps avoid
repeat sends; ambiguous delivery results still need review rather than blind
retries. The application is a small single-company deployment; larger,
multi-worker operation needs a shared queue/lock strategy and a suitable shared
database before scaling.

## Checks before relying on the service

- Use real permitted tender documents and compare extracted deadlines, bond
  amounts, eligibility, and requirements with the originals.
- Verify source access using your subscription or publisher permission. Tender
  Egypt integration and complete source coverage have not been established.
- Review a digest with your dad, then test one consented live WhatsApp send.
  Live sending and Meta template approval have not been verified for your account.
- Confirm that a scheduled run happens while the server is running, review its
  outbox state, and make sure your storage backup can be restored.

These checks are about the actual accounts and data you choose. The bundled
tests use mocked provider requests and do not spend money or send live messages.
