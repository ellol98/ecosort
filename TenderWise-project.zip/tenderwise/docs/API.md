# API reference

The dashboard uses this same-origin JSON API. `/docs` lists all routes without
external scripts, and `/openapi.json` returns the generated request schemas.
No API key, Meta token or environment secret is returned by these endpoints.

When `ADMIN_TOKEN` is configured, every `/api/` call requires:

```text
Authorization: Bearer <your administrator token>
```

JSON bodies use `Content-Type: application/json`. Normal browser writes must be
same-origin. `/health` is unauthenticated liveness only. Meta's webhook routes
use their own verification instead of the administrator token.

## Workspace and documents

- `GET /api/bootstrap`: company, settings, service configuration flags, tenders,
  sources, recent delivery history and metrics. No raw document text or secrets.
- `PUT /api/company`: save a company profile and invalidate previous approvals.
- `POST /api/import/text`: `{ "text": "...", "title": "...", "source_url": "" }`.
- `POST /api/import/url`: `{ "url": "https://permitted-source.example/notice" }`.
- `POST /api/import`: multipart upload with field `file` (maximum 10 MB).
- `POST /api/demo/seed`: idempotently create six fictional records.
- `PATCH /api/tenders/{id}`: `review_status` (`pending`, `approved`, `rejected`)
  and/or feedback (`relevant`, `irrelevant`, or empty string).
- `POST /api/tenders/{id}/analyze`: analyze the stored text again. Uses AI only
  when configured and the record is real; resets approval.
- `GET /api/tenders/{id}/report`: printable escaped HTML study.
- `GET /api/tenders/{id}/document`: original uploaded file, or extracted text
  when no original binary was stored.
- `GET /api/export`: archival JSON workspace export including raw text and
  document-version history. It contains private business data; handle accordingly.

## Sources and automation

- `POST /api/sources`: name, type (`rss`, `json`, `html`), public HTTPS URL,
  `permission_confirmed`, `enabled`, and adapter-specific `config` dictionary.
- `PATCH /api/sources/{id}`: `{ "enabled": false }` to pause a source.
- `DELETE /api/sources/{id}`: remove the source configuration; keep its tenders.
- `POST /api/sources/{id}/collect`: collect a single enabled/authorized source.
- `PUT /api/settings`: save all settings; see the OpenAPI AppSettings schema.
- `POST /api/jobs/run`: run enabled authorized collectors and the configured
  delivery workflow. In live mode this can send messages. Avoid overlapping jobs.
- `GET /api/digest?live=false`: exact next test-preview batch (may contain demos).
- `GET /api/digest?live=true`: exact next live-eligible batch under current policy.
- `POST /api/digest/send`: `{ "live": false }` saves a dry run. `live:true`
  uses sender configuration, recorded consent, approved template and review policy.
- `POST /api/digest/send` with `{ "live": true, "retry_failed": true }` can
  explicitly retry a definite provider rejection after setup correction. Pending,
  accepted and ambiguous states are never retried this way.

Saved schedules run in-process in the selected timezone; this is not a hosted
job service. Failed collection is recorded as an error, not a successful empty
result. A second overlapping collection receives a busy response.

## Meta webhooks

- `GET /webhooks/whatsapp`: checks `hub.mode`, `hub.verify_token` and returns
  `hub.challenge` only when the configured verify token matches.
- `POST /webhooks/whatsapp`: bounded to 1 MB and HMAC-verified using the exact raw
  bytes and `WHATSAPP_APP_SECRET`. Updates persisted message statuses without
  regressing delivered/read statuses to earlier states.

## Response semantics

Imports return `{ "tender": {...}, "duplicate": bool, "updated": bool }`.
Missing or unverified fields are null. `analysis_mode` is `rules`, `ai`, or `demo`.
An open status means a verified submission date has not passed on the Cairo
calendar; exact time still requires source verification. `fit_score` is a
transparent heuristic out of 100. `confidence` is evidence-field coverage, not
model accuracy. Full eligibility is never automatically asserted.

Delivery states include `dry_run`, `pending`, `accepted`, `sent`, `delivered`,
`read`, `failed`, and `delivery_unknown`. API acceptance is not proof of delivery.
Outbox IDs and versions refer only to records actually displayed in that batch.
