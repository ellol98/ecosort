# Presenting TenderWise in a technical portfolio

## Honest project description

"I built a tender decision-support application for an Egyptian construction business. It processes permitted documents, validates structured extraction against source evidence, ranks opportunities using a company profile, and integrates human-reviewed WhatsApp digests. I designed and tested document ingestion, matching, provenance, delivery controls and the dashboard. The language model is accessed through an API; I did not train its foundation model."

Adapt this to the work you understand and actually completed. Disclose AI coding assistance and third-party services where requested. Be ready to explain every module and demonstrate your own changes. A technical portfolio supports an application; it does not guarantee admission.

## What to publish

Publish source code without `.env`, private documents, recipient numbers, real business limits or the runtime database. Include a short screen recording, a clear architecture explanation, installation instructions, tests, known limitations and measured results. The fictional demonstration is safe to share but is not evidence of production accuracy.

MBZUAI's undergraduate admissions page recommends a technical portfolio with GitHub or relevant project URLs: https://mbzuai.ac.ae/admissions/undergraduate-admissions . Check current submission instructions for your own application cycle.

## Turn the pilot into an evaluated AI project

1. Obtain permission to use a collection of real Arabic and English construction notices, including difficult PDFs and incomplete notices. Keep a record of source and collection date.
2. Have your dad label whether each opportunity fits his company's actual capabilities. Separately annotate buyer, submission deadline, bid security, fee, requirements and supporting pages. Use a second reviewer for disputed critical fields.
3. Split by tender/project and source or time so duplicate announcements and amended versions cannot leak across train/development/test sets. Freeze a held-out test set before tuning prompts or weights.
4. Compare a simple keyword filter, the current transparent matcher and the AI-assisted pipeline. Evaluate the same documents on the same split.
5. Report per-field accuracy with missing/ambiguous facts scored appropriately, unsupported-claim rate, relevant opportunities among the top five, relevant opportunities missed, processing cost and runtime. Record how uncertain or unreadable documents are handled.
6. Measure your dad's actual time spent reviewing a sample manually and with the tool. Report sample sizes and the measurement method. Do not invent business savings or wins.
7. Document failures and improvements: date confusion, Arabic OCR, aliases, duplicate notices, classification requirements and amendments.

The included `python -m tenderwise.evaluate` only checks a tiny synthetic parser fixture. It is a reproducible software sanity check, not a model benchmark. Once you have real permission-cleared labels, replace/extend the fixture format or write a separate benchmark and report its provenance.

## Optional model-training extension

After collecting enough representative feedback, train a small relevance classifier or ranking model and compare it with the keyword baseline and current matcher on held-out data. You do not need to train a large language model. Keep training data separate from the test set and publish only data you have permission to share. Model training is valuable when it produces a measurable improvement over simpler methods.

## Suggested demonstration

Show a company profile, import a permitted notice, inspect the supporting evidence, explain a rejected/unknown fact, compare two recommendations, record relevance feedback, approve after reviewing the original notice, and save a dry-run digest. Demonstrate a source failure and duplicate import so reliability work is visible. Claim live AI or WhatsApp delivery only after actually testing it with authorized accounts.
