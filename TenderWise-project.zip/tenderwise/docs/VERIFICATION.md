# Verification record

Checked on 28 October 2026 using Windows and Python 3.12.

## Passed

- 86 automated tests, with 14 additional passing unittest subtests.
- The full test suite was also run after installing the pinned dependencies into
  a separate clean Python virtual environment without bundled site packages.
- `pip check`: no broken requirements in that clean environment.
- Six explicitly synthetic parser cases: 11/11 field checks. These are software
  sanity checks, not evidence of real-tender or AI-model accuracy.
- JavaScript syntax check with `node --check`.
- FastAPI lifespan/startup and real in-memory API requests through TestClient.
- Document imports, field extraction, source evidence, deduplication, amended
  versions, company limits, approval reset, safe HTML reports, originals/export.
- Bilingual location/specialty matching, unknown/conflicting dates and conservative
  EGP amount handling.
- Permission-gated collection, source errors, source freshness, disabled sources,
  public-URL validation, DNS pinning and bounded document/network helpers.
- Mocked structured AI requests, incomplete/malformed responses, sanitized errors,
  and no model tools or response storage requested.
- Mocked WhatsApp payloads, exact digest batching, history-independent deduplication,
  definite versus ambiguous send failures, explicit retries, signatures, consent,
  template confirmation, review policy and fictional-data exclusion.
- Daily scheduler construction, timezone validation and single-job configuration.

## Not verified here

- Browser visual/interaction verification: the browser permission gate declined
  access to the local preview. No alternative browser method was used.
- Live OpenAI calls or real-world model accuracy: no user API key was supplied.
- Live WhatsApp sends, account eligibility, template approval or real delivery:
  no sender account or consenting recipient was configured.
- Automated access to TenderEgypt or complete tender coverage. Source access and
  field mappings need validation with the selected publisher/account.
- A real daily unattended run on an always-on server.
- Docker image build/runtime or a cloud deployment.

One dependency deprecation warning is emitted by Starlette's current TestClient
HTTPX compatibility layer. Tests pass; this warning concerns the testing client,
not a failed application request. Runtime versions are pinned in
`requirements.lock.txt`.

The shipped application starts with scheduling/live delivery disabled. The local
preview data is fictional and separate from the downloadable source archive.
