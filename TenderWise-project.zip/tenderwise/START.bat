@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" launcher.py
  goto finish
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 launcher.py
  goto finish
)
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" launcher.py
  goto finish
)
python launcher.py
:finish
if errorlevel 1 (
  echo.
  echo Could not start. Install Python 3.11 or newer from https://www.python.org/downloads/
  echo Then try again. See START_HERE.md for manual setup.
  pause
)
endlocal
