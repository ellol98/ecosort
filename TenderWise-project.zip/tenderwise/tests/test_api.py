"""Offline end-to-end checks for user-visible API behavior and delivery gates."""

import html
from datetime import date, timedelta
from unittest.mock import Mock

import httpx
import pytest
from fastapi.testclient import TestClient

import tenderwise.app as appmod
from tenderwise.ingestion import IngestionError


@pytest.fixture(autouse=True)
def offline_environment(monkeypatch):
    for name in (
        "OPENAI_API_KEY", "ADMIN_TOKEN", "WHATSAPP_ACCESS_TOKEN",
        "WHATSAPP_PHONE_NUMBER_ID", "WHATSAPP_API_VERSION",
        "WHATSAPP_VERIFY_TOKEN", "WHATSAPP_APP_SECRET",
    ):
        monkeypatch.setenv(name, "")
    monkeypatch.setenv("AI_ENABLED", "false")

    def block_network(*args, **kwargs):
        raise AssertionError("API integration tests must not make external HTTP requests")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", block_network)


@pytest.fixture
def client(tmp_path):
    with TestClient(appmod.create_app(tmp_path)) as active:
        yield active


def notice_text(title="School renovation", *, bond=25000, value=1000000):
    future = (date.today() + timedelta(days=45)).isoformat()
    return (
        f"Title: {title}\nBuyer: Public Works Authority\nLocation: Cairo\n"
        f"Category: Renovation\nSubmission deadline: {future}\n"
        f"Estimated contract value: EGP {value}\nBid security: EGP {bond}\n"
        "Document fee: EGP 500\nScope: Renovation of school classrooms and electrical installations.\n"
        "Requirements: Valid contractor registration; Technical and financial proposals"
    )


def import_notice(client, text=None, source_url=""):
    response = client.post("/api/import/text", json={"title": "School renovation", "text": text or notice_text(), "source_url": source_url})
    assert response.status_code == 200, response.text
    return response.json()


def bootstrap(client):
    response = client.get("/api/bootstrap")
    assert response.status_code == 200, response.text
    return response.json()


def approve(client, tender_id):
    response = client.patch(f"/api/tenders/{tender_id}", json={"review_status": "approved"})
    assert response.status_code == 200, response.text
    return response.json()


def test_text_import_extracts_facts_and_deduplicates_without_ai(client):
    first = import_notice(client)
    second = import_notice(client)
    assert first["duplicate"] is False
    assert second["duplicate"] is True
    assert second["tender"]["id"] == first["tender"]["id"]
    state = bootstrap(client)
    assert state["stats"]["total"] == 1
    tender = state["tenders"][0]
    assert tender["buyer"] == "Public Works Authority"
    assert tender["project_value"] == 1000000
    assert tender["bid_bond"] == 25000
    assert tender["analysis_mode"] == "rules"
    assert tender["is_demo"] is False
    assert tender["review_status"] == "pending"
    assert tender["status"] == "open"
    assert tender["eligibility"] != "confirmed"


def test_company_limits_recompute_fit_and_invalidate_bid_approval(client):
    tender = import_notice(client)["tender"]
    approved = approve(client, tender["id"])
    assert approved["reviewed_at"]
    company = bootstrap(client)["company"]
    company.update(available_bid_bond=10000, max_project_value=500000)
    response = client.put("/api/company", json=company)
    assert response.status_code == 200, response.text
    changed = bootstrap(client)["tenders"][0]
    assert changed["review_status"] == "pending"
    assert changed["reviewed_at"] is None
    assert changed["recommendation"] == "Unsuitable under current profile"
    assert any("exceeds" in risk.lower() for risk in changed["risks"])
    assert changed["fit_score"] < 100
    assert changed["id"] not in client.get("/api/digest?live=true").json()["tender_ids"]


def test_amended_document_updates_record_preserves_old_version_and_requires_review(client):
    url = "https://public.example/notices/42"
    initial = import_notice(client, source_url=url)["tender"]
    approve(client, initial["id"])
    updated = import_notice(client, notice_text(bond=45000), source_url=url)
    assert updated["updated"] is True
    assert updated["duplicate"] is False
    assert updated["tender"]["id"] == initial["id"]
    assert updated["tender"]["bid_bond"] == 45000
    assert updated["tender"]["review_status"] == "pending"
    assert updated["tender"]["reviewed_at"] is None
    backup = client.get("/api/export").json()
    assert len(backup["tenders"]) == 1
    assert len(backup["versions"]) == 1


def test_demo_seed_is_idempotent_and_never_appears_in_live_digest(client, monkeypatch):
    sender = Mock(side_effect=AssertionError("Demo content must not be delivered"))
    monkeypatch.setattr(appmod, "send_whatsapp", sender)
    first = client.post("/api/demo/seed")
    assert first.status_code == 200
    assert first.json()["created"] == 6
    first_ids = {row["id"] for row in bootstrap(client)["tenders"]}
    second = client.post("/api/demo/seed")
    assert second.status_code == 200
    assert second.json()["created"] == 0
    state = bootstrap(client)
    assert {row["id"] for row in state["tenders"]} == first_ids
    assert all(row["is_demo"] for row in state["tenders"])
    for row in state["tenders"]:
        approve(client, row["id"])
    preview = client.get("/api/digest?live=true")
    assert preview.status_code == 200
    assert preview.json()["count"] == 0
    dry_run = client.post("/api/digest/send", json={"live": False})
    assert dry_run.status_code == 200, dry_run.text
    assert dry_run.json()["status"] == "dry_run"
    assert dry_run.json()["live"] is False
    assert all(not row["live"] for row in bootstrap(client)["outbox"])
    sender.assert_not_called()


def test_upload_and_report_escape_untrusted_title_and_company(client):
    hostile_title = '<script>alert("tender")</script>'
    company = bootstrap(client)["company"]
    company["name"] = '<img src=x onerror="alert(1)">'
    assert client.put("/api/company", json=company).status_code == 200
    text = notice_text(hostile_title)
    response = client.post("/api/import", files={"file": ("notice.txt", text.encode(), "text/plain")})
    assert response.status_code == 200, response.text
    tender_id = response.json()["tender"]["id"]
    report = client.get(f"/api/tenders/{tender_id}/report")
    assert report.status_code == 200
    assert "<script>" not in report.text
    assert '<img src=x onerror=' not in report.text
    assert html.escape(hostile_title) in report.text
    assert html.escape(company["name"]) in report.text
    assert "frame-ancestors 'none'" in report.headers["content-security-policy"]
    original = client.get(f"/api/tenders/{tender_id}/document")
    assert original.status_code == 200
    assert "attachment" in original.headers["content-disposition"]
    assert original.content == text.encode()


def test_source_permission_gate_prevents_collection_and_scheduled_fetches(client, monkeypatch):
    collector = Mock(side_effect=AssertionError("Unapproved source must not be fetched"))
    monkeypatch.setattr(appmod, "collect_source", collector)
    response = client.post("/api/sources", json={"name": "Unapproved feed", "type": "rss", "url": "https://public.example/feed.xml", "permission_confirmed": False})
    assert response.status_code == 200, response.text
    source_id = response.json()["id"]
    collect = client.post(f"/api/sources/{source_id}/collect")
    assert collect.status_code == 422, collect.text
    assert "permission" in collect.json()["detail"].lower()
    job = client.post("/api/jobs/run")
    assert job.status_code == 200, job.text
    assert job.json()["sources"] == []
    collector.assert_not_called()


def test_source_failure_is_visible_in_job_and_dashboard(client, monkeypatch):
    monkeypatch.setattr(appmod, "collect_source", Mock(side_effect=IngestionError("Source unavailable; retry after provider recovery")))
    response = client.post("/api/sources", json={"name": "Permitted feed", "type": "rss", "url": "https://public.example/feed.xml", "permission_confirmed": True})
    assert response.status_code == 200, response.text
    job = client.post("/api/jobs/run")
    assert job.status_code == 200, job.text
    result = job.json()["sources"][0]
    assert result["status"] == "error"
    assert "Source unavailable" in " ".join(result["errors"])
    state = bootstrap(client)
    assert state["sources"][0]["status"] == "error"
    assert "Source unavailable" in state["sources"][0]["last_error"]
    assert state["last_job"]["sources"][0]["status"] == "error"


def test_admin_token_and_cross_origin_write_protection(client, monkeypatch):
    monkeypatch.setenv("ADMIN_TOKEN", "integration-admin-secret")
    assert client.get("/api/bootstrap").status_code == 401
    headers = {"Authorization": "Bearer integration-admin-secret"}
    assert client.get("/api/bootstrap", headers=headers).status_code == 200
    blocked = client.post("/api/demo/seed", headers={**headers, "Origin": "https://untrusted.example"})
    assert blocked.status_code == 403
    assert "origin" in blocked.json()["detail"].lower()
    allowed = client.post("/api/demo/seed", headers={**headers, "Origin": "http://testserver"})
    assert allowed.status_code == 200


def test_no_token_requires_localhost_host(tmp_path):
    with TestClient(appmod.create_app(tmp_path), base_url="http://untrusted.example") as remote:
        response = remote.get("/api/bootstrap")
        assert response.status_code == 403
        assert "ADMIN_TOKEN" in response.json()["detail"]


def test_live_delivery_requires_consent_and_sender_credentials(client, monkeypatch):
    sender = Mock(side_effect=AssertionError("Delivery gates must block the provider call"))
    monkeypatch.setattr(appmod, "send_whatsapp", sender)
    tender = import_notice(client)["tender"]
    approve(client, tender["id"])
    settings = bootstrap(client)["settings"]
    settings.update(whatsapp_enabled=True, whatsapp_test_mode=False, whatsapp_recipient="201000000001", whatsapp_template_name="tender_digest", whatsapp_template_approved=True, whatsapp_opt_in=False)
    refused = client.put("/api/settings", json=settings)
    assert refused.status_code == 422, refused.text
    assert "consent" in refused.json()["detail"].lower()
    settings["whatsapp_opt_in"] = True
    accepted = client.put("/api/settings", json=settings)
    assert accepted.status_code == 200, accepted.text
    send = client.post("/api/digest/send", json={"live": True})
    assert send.status_code == 422, send.text
    assert "credentials" in send.json()["detail"].lower()
    assert bootstrap(client)["outbox"] == []
    sender.assert_not_called()


def test_export_does_not_include_environment_credentials(client, monkeypatch):
    import_notice(client)
    secrets = {
        "OPENAI_API_KEY": "unique-ai-secret-should-not-export",
        "WHATSAPP_ACCESS_TOKEN": "unique-wa-secret-should-not-export",
        "WHATSAPP_APP_SECRET": "unique-app-secret-should-not-export",
        "WHATSAPP_VERIFY_TOKEN": "unique-verify-secret-should-not-export",
        "ADMIN_TOKEN": "unique-admin-secret-should-not-export",
    }
    for name, value in secrets.items():
        monkeypatch.setenv(name, value)
    headers = {"Authorization": "Bearer " + secrets["ADMIN_TOKEN"]}
    exported = client.get("/api/export", headers=headers)
    state = client.get("/api/bootstrap", headers=headers)
    assert exported.status_code == 200
    assert state.status_code == 200
    assert "attachment" in exported.headers["content-disposition"]
    assert exported.json()["tenders"]
    for secret in secrets.values():
        assert secret not in exported.text
        assert secret not in state.text
