"""Offline regression tests for untrusted documents and source adapters."""

from io import BytesIO
from unittest import TestCase
from unittest.mock import patch

import httpx
from pypdf import PdfWriter
from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject

from tenderwise import ingestion as ing


def downloaded(data, url="https://public.example/notices", content_type="text/html"):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return ing._Download(data, url, content_type)


class ExtractionTests(TestCase):
    def test_arabic_text_and_stable_content_hash(self):
        text = "توريد معدات\nالموعد النهائي: 2030-10-31"
        first = ing.extract_upload(text.encode(), "../../tender.txt")
        second = ing.extract_upload(text.encode(), "other.txt")
        self.assertEqual(first.text, text)
        self.assertEqual(first.filename, "tender.txt")
        self.assertEqual(first.content_hash, second.content_hash)
        self.assertEqual(first.metadata["extraction_method"], "plain_text")

    def test_html_removes_executable_content_and_preserves_title(self):
        data = b"<html><title>Medical tender</title><body><h1>Supply masks</h1><script>steal secrets</script><style>hidden css</style><p>Deadline 2030-11-01</p></body></html>"
        document = ing.extract_upload(data, "notice.html")
        self.assertEqual(document.title, "Medical tender")
        self.assertIn("Supply masks", document.text)
        self.assertNotIn("steal secrets", document.text)
        self.assertNotIn("hidden css", document.text)

    def test_binary_and_unsupported_files_are_rejected(self):
        with self.assertRaises(ing.IngestionError):
            ing.extract_upload(b"MZ\x00\x00\x01\x02", "disguised.txt")
        with self.assertRaises(ing.IngestionError):
            ing.extract_upload(b"spreadsheet", "notices.xlsx")

    def test_input_and_extracted_text_limits(self):
        with patch.object(ing, "MAX_DOWNLOAD_BYTES", 10):
            with self.assertRaisesRegex(ing.IngestionError, "input limit"):
                ing.extract_upload(b"a" * 11, "notice.txt")
        with patch.object(ing, "MAX_TEXT_BYTES", 5):
            with self.assertRaisesRegex(ing.IngestionError, "2 MB"):
                ing.extract_upload("عربي".encode(), "notice.txt")

    def test_scanned_or_blank_pdf_requires_ocr(self):
        writer = PdfWriter()
        writer.add_blank_page(width=100, height=100)
        buffer = BytesIO()
        writer.write(buffer)
        with self.assertRaisesRegex(ing.OCRRequiredError, "OCR"):
            ing.extract_upload(buffer.getvalue(), "scan.pdf")

    def test_pdf_text_keeps_page_reference(self):
        writer = PdfWriter()
        page = writer.add_blank_page(width=300, height=300)
        font = DictionaryObject({
            NameObject("/Type"): NameObject("/Font"),
            NameObject("/Subtype"): NameObject("/Type1"),
            NameObject("/BaseFont"): NameObject("/Helvetica"),
        })
        page[NameObject("/Resources")] = DictionaryObject({
            NameObject("/Font"): DictionaryObject({NameObject("/F1"): writer._add_object(font)})
        })
        stream = DecodedStreamObject()
        stream.set_data(b"BT /F1 12 Tf 10 100 Td (Supply computers. Deadline 2030-10-31.) Tj ET")
        page[NameObject("/Contents")] = writer._add_object(stream)
        writer.add_blank_page(width=300, height=300)
        buffer = BytesIO()
        writer.write(buffer)
        document = ing.extract_upload(buffer.getvalue(), "notice.pdf")
        self.assertIn("[Page 1]", document.text)
        self.assertIn("Supply computers", document.text)
        self.assertEqual(document.metadata["empty_text_pages"], [2])
        self.assertTrue(document.metadata["warnings"])


class UrlSafetyTests(TestCase):
    def test_private_urls_credentials_and_protocols_are_rejected(self):
        cases = [
            "http://public.example/a", "file:///etc/passwd",
            "https://127.0.0.1/", "https://10.0.0.1/", "https://169.254.169.254/",
            "https://[::1]/", "https://[::ffff:127.0.0.1]/",
            "https://localhost/", "https://intranet/", "https://portal.local/",
            "https://user:password@public.example/", "https://public.example:8443/",
            "https://public.example/\r\nHeader:value", "https://public.example\\@127.0.0.1/",
        ]
        for url in cases:
            with self.subTest(url=url), self.assertRaises(ing.IngestionError):
                ing.normalize_url(url)

    def test_url_normalization_preserves_query_and_drops_fragment(self):
        self.assertEqual(ing.normalize_url("HTTPS://Public.Example:443/a?q=1#section"), "https://public.example/a?q=1")

    def test_mixed_private_dns_answer_is_rejected(self):
        answers = [(2, 1, 6, "", ("93.184.216.34", 443)), (2, 1, 6, "", ("10.0.0.4", 443))]
        with patch.object(ing.socket, "getaddrinfo", return_value=answers):
            with self.assertRaisesRegex(ing.IngestionError, "private"):
                ing._resolve_public_addresses("public.example")

    def _client(self, handler):
        # Preserve the real constructor before patching its module attribute.
        real_client = httpx.Client
        return lambda **kwargs: real_client(transport=httpx.MockTransport(handler), **kwargs)

    def test_connection_is_pinned_but_tls_and_host_use_source_hostname(self):
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, text="Tender document", headers={"content-type": "text/plain"})
        factory = self._client(handler)
        with patch.object(ing, "_resolve_public_addresses", return_value=["93.184.216.34"]), patch.object(ing.httpx, "Client", side_effect=factory):
            document = ing.fetch_document("https://public.example/notice")
        self.assertEqual(requests[0].url.host, "93.184.216.34")
        self.assertEqual(requests[0].headers["host"], "public.example")
        self.assertEqual(requests[0].extensions["sni_hostname"], "public.example")
        self.assertEqual(document.source_url, "https://public.example/notice")

    def test_private_redirect_is_blocked_before_second_request(self):
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(302, headers={"location": "https://127.0.0.1/private"})
        factory = self._client(handler)
        with patch.object(ing, "_resolve_public_addresses", return_value=["93.184.216.34"]), patch.object(ing.httpx, "Client", side_effect=factory):
            with self.assertRaises(ing.IngestionError):
                ing.fetch_document("https://public.example/notice")
        self.assertEqual(len(requests), 1)

    def test_stream_limit_is_enforced_even_without_content_length(self):
        def handler(request):
            return httpx.Response(200, content=b"x" * 20, headers={"content-type": "text/plain"})
        factory = self._client(handler)
        with patch.object(ing, "MAX_DOWNLOAD_BYTES", 10), patch.object(ing, "_resolve_public_addresses", return_value=["93.184.216.34"]), patch.object(ing.httpx, "Client", side_effect=factory):
            with self.assertRaisesRegex(ing.IngestionError, "download limit"):
                ing.fetch_document("https://public.example/notice")


class SourceAdapterTests(TestCase):
    def collect(self, body, kind="rss", **config):
        with patch.object(ing, "_fetch_bytes", return_value=downloaded(body)):
            return ing.collect_source({"type": kind, "url": "https://public.example/notices", "permission_confirmed": True, **config})

    def test_permission_is_required_before_network_access(self):
        with patch.object(ing, "_fetch_bytes") as fetch:
            for permission in [False, None, "true"]:
                with self.assertRaises(ing.IngestionError):
                    ing.collect_source({"type": "rss", "url": "https://public.example/feed", "permission_confirmed": permission})
            fetch.assert_not_called()

    def test_rss_extracts_arabic_excerpt_and_relative_link(self):
        xml = """<rss><channel><item><title>توريد حواسيب</title><description><![CDATA[<p>Deadline 2030-11-10</p>]]></description><link>/notice/42</link><pubDate>2030-10-20</pubDate></item></channel></rss>"""
        documents = self.collect(xml)
        self.assertEqual(documents[0].source_url, "https://public.example/notice/42")
        self.assertIn("توريد حواسيب", documents[0].text)
        self.assertIn("Deadline 2030-11-10", documents[0].text)
        self.assertEqual(documents[0].metadata["document_scope"], "listing_excerpt")

    def test_atom_namespaces_and_alternate_link(self):
        xml = """<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Supply chairs</title><link rel="self" href="/api/1"/><link rel="alternate" href="/tenders/1"/><summary>Deliver 30 chairs</summary></entry></feed>"""
        documents = self.collect(xml)
        self.assertEqual(documents[0].source_url, "https://public.example/tenders/1")

    def test_unsafe_xml_entities_are_rejected(self):
        xml = '<!DOCTYPE rss [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><rss><item><title>&xxe;</title></item></rss>'
        with self.assertRaisesRegex(ing.IngestionError, "safe RSS"):
            self.collect(xml)

    def test_json_mapping_keeps_deadline_as_published_without_claiming_open(self):
        body = '{"payload":{"notices":[{"name":"Supply gloves","body":"1000 units","href":"/tenders/7","close":"2030-12-01","owner":"Hospital"}]}}'
        documents = self.collect(body, kind="json", items_path="payload.notices", fields={"title":"name","text":"body","url":"href","deadline":"close","buyer":"owner"})
        self.assertEqual(documents[0].title, "Supply gloves")
        self.assertIn("deadline: 2030-12-01", documents[0].text)
        self.assertEqual(documents[0].metadata["buyer"], "Hospital")
        self.assertNotIn("open", documents[0].metadata)

    def test_html_selector_adapter_filters_offsite_and_private_links(self):
        body = '<article><h2>Supply pipes</h2><a href="/one">Details</a><p>500 pipes</p></article><article><a href="https://other.example/two">Other</a></article><article><a href="https://127.0.0.1/">Unsafe</a></article>'
        documents = self.collect(body, kind="html", selectors={"item":"article","title":"h2","link":"a","text":"p"})
        self.assertEqual(len(documents), 1)
        self.assertEqual(documents[0].source_url, "https://public.example/one")
        self.assertIn("500 pipes", documents[0].text)

    def test_maximum_twenty_five_documents_and_deduplication(self):
        body = '<rss><channel>' + ''.join(f'<item><title>Tender {i}</title><link>/t/{i}</link></item>' for i in range(40)) + '</channel></rss>'
        self.assertEqual(len(self.collect(body, limit=1000)), 25)
        repeated = '<rss><channel><item><title>A</title><link>/a</link></item><item><title>A</title><link>/a</link></item></channel></rss>'
        self.assertEqual(len(self.collect(repeated)), 1)

    def test_failed_detail_retains_excerpt_with_visible_error(self):
        body = '<rss><item><title>Supply paper</title><description>100 reams</description><link>/paper.pdf</link></item></rss>'
        with patch.object(ing, "fetch_document", side_effect=ing.OCRRequiredError("OCR required")):
            documents = self.collect(body, fetch_details=True)
        self.assertEqual(documents[0].metadata["detail_fetch_error"], "OCR required")
        self.assertEqual(documents[0].metadata["document_scope"], "listing_excerpt")
