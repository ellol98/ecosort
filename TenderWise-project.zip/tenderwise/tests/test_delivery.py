from datetime import datetime, timedelta, timezone
from unittest.mock import Mock

import pytest

import tenderwise.app as appmod
from tenderwise.db import Store, utcnow
from tenderwise.ingestion import IngestedDocument, extract_upload
from tenderwise.models import AppSettings


@pytest.fixture
def ready(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "")
    monkeypatch.setenv("WHATSAPP_ACCESS_TOKEN", "fake-test-token")
    monkeypatch.setenv("WHATSAPP_PHONE_NUMBER_ID", "12345")
    monkeypatch.setenv("WHATSAPP_API_VERSION", "v99.0")
    store = Store(tmp_path)
    store.set("settings", AppSettings(whatsapp_enabled=True, whatsapp_test_mode=False, whatsapp_opt_in=True, whatsapp_template_approved=True, whatsapp_recipient="201000000001", whatsapp_template_name="test_digest").model_dump())
    sender = Mock(return_value={"ok": True, "message_id": "test-message", "error": None})
    monkeypatch.setattr(appmod, "send_whatsapp", sender)
    return store, sender


def add_approved(store, index=1, title=None):
    future = (datetime.now(timezone.utc).date() + timedelta(days=30)).isoformat()
    text = f"Title: {title or ('School renovation ' + str(index))}\nBuyer: Test Buyer {index}\nScope: Building renovation\nSubmission deadline: {future}"
    record = appmod.import_document(store, extract_upload(text.encode(), "notice.txt"))["tender"]
    record.update(review_status="approved", reviewed_at=utcnow())
    store.save_tender(record, text)
    return record


def test_only_displayed_tenders_are_marked_sent(ready):
    store, sender = ready
    for index in range(9):
        add_approved(store, index, "School renovation " + str(index) + " " + "long scope " * 18)
    result = appmod.deliver_digest(store, live=True)
    assert result["status"] == "accepted"
    assert 0 < len(result["tender_ids"]) < 9
    assert len(result["digest"]) <= 900
    remaining = appmod.digest_candidates(store, live=True)
    assert len(remaining) == 9 - len(result["tender_ids"])
    assert not set(result["tender_ids"]) & {t["id"] for t in remaining}
    sender.assert_called_once()


def test_historical_send_deduplication_survives_many_previews(ready):
    store, sender = ready
    record = add_approved(store)
    first = appmod.deliver_digest(store, live=True)
    assert first["status"] == "accepted"
    for index in range(105):
        store.reserve_outbox({"id": f"preview-{index}", "status": "dry_run", "live": False}, f"preview-{index}")
    assert first["id"] not in {o["id"] for o in store.outbox()}
    assert appmod.digest_candidates(store, live=True) == []
    assert appmod.deliver_digest(store, live=True)["status"] == "skipped"
    sender.assert_called_once()


def test_failed_provider_rejection_can_be_explicitly_retried(ready):
    store, sender = ready
    add_approved(store)
    sender.return_value = {"ok": False, "message_id": None, "error": "provider_rejected"}
    failed = appmod.deliver_digest(store, live=True)
    assert failed["status"] == "failed"
    appmod.deliver_digest(store, live=True)
    assert sender.call_count == 1
    sender.return_value = {"ok": True, "message_id": "retry-accepted", "error": None}
    retried = appmod.deliver_digest(store, live=True, retry_failed=True)
    assert retried["status"] == "accepted"
    assert retried["id"] == failed["id"]
    assert retried["attempt_history"][0]["error"] == "provider_rejected"
    assert sender.call_count == 2


def test_ambiguous_send_is_never_automatically_retried(ready):
    store, sender = ready
    add_approved(store)
    sender.return_value = {"ok": False, "message_id": None, "error": "timeout_delivery_unknown"}
    assert appmod.deliver_digest(store, live=True)["status"] == "delivery_unknown"
    assert appmod.deliver_digest(store, live=True, retry_failed=True)["status"] == "skipped"
    sender.assert_called_once()


def test_stale_review_is_excluded(ready):
    store, sender = ready
    record = add_approved(store)
    record["reviewed_at"] = (datetime.now(timezone.utc) - timedelta(hours=25)).isoformat()
    store.save_tender(record, "stored text")
    assert appmod.deliver_digest(store, live=True)["status"] == "skipped"
    sender.assert_not_called()


def test_fictional_uploaded_sample_stays_demo(ready):
    store, sender = ready
    record = appmod.import_document(store, extract_upload(b"FICTIONAL DEMONSTRATION. Not a real tender.\nTitle: School renovation\nSubmission deadline: 2099-01-01", "sample.txt"))["tender"]
    assert record["is_demo"] is True
    assert record["analysis_mode"] == "demo"


def test_linkless_feed_items_do_not_overwrite_each_other(ready):
    store, sender = ready
    for index in range(3):
        text = f"Title: School renovation {index}\nScope: Building maintenance"
        doc = extract_upload(text.encode(), "feed-item.txt")
        doc.source_url = "https://example.org/feed.xml"
        doc.metadata.update(document_scope="listing_excerpt", source_feed_url=doc.source_url)
        appmod.import_document(store, doc)
    assert len(store.tenders()) == 3


def test_failed_source_excluded_from_live_digest(ready):
    store, sender = ready
    record = add_approved(store)
    record["source_metadata"]["source_id"] = "offline-source"
    store.save_tender(record, "stored text")
    store.save_source({"id": "offline-source", "status": "error", "enabled": True})
    assert appmod.deliver_digest(store, live=True)["status"] == "skipped"
    sender.assert_not_called()


def test_optional_hands_free_mode_sends_fresh_drafts_not_stale_or_rejected(ready):
    store, sender = ready
    record = add_approved(store)
    record.update(review_status="pending", reviewed_at=None)
    store.save_tender(record, "stored text")
    assert appmod.digest_candidates(store, live=True) == []
    settings = store.get("settings")
    settings["require_human_review"] = False
    store.set("settings", settings)
    assert len(appmod.digest_candidates(store, live=True)) == 1
    message = appmod.deliver_digest(store, live=True)
    assert message["status"] == "accepted"
    assert "Draft: human review pending" in message["digest"]
    sender.assert_called_once()


def test_digest_includes_short_study_fields(ready):
    store, sender = ready
    add_approved(store)
    digest = appmod.digest_preview(store, live=True)["text"]
    assert "Scope:" in digest
    assert "Assessment:" in digest
    assert "Fit:" in digest
    assert "Check:" in digest
