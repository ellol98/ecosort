import json
from unittest.mock import Mock

import httpx
import pytest

from tenderwise.analysis import ai_extract, extraction_schema, locations_match, match_company, rule_extract


def provider(monkeypatch, body, status=200):
    response = httpx.Response(status, json=body)
    client = Mock()
    client.post.return_value = response
    context = Mock()
    context.__enter__ = Mock(return_value=client)
    context.__exit__ = Mock(return_value=False)
    monkeypatch.setattr(httpx, "Client", Mock(return_value=context))
    return client


def test_ai_request_uses_structured_schema_no_tools_and_no_storage(monkeypatch):
    expected = rule_extract("Title: School renovation\nBuyer: Demo Client")
    expected = {key: expected.get(key) for key in extraction_schema()["properties"]}
    client = provider(monkeypatch, {"status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(expected)}]}]})
    config = {"api_key": "test-secret", "model": "configured-model"}
    result = ai_extract("Title: School renovation\nBuyer: Demo Client", config)
    assert result["buyer"] == "Demo Client"
    request = client.post.call_args.kwargs["json"]
    assert request["store"] is False
    assert request["text"]["format"]["strict"] is True
    assert request["model"] == "configured-model"
    assert "tools" not in request
    assert "test-secret" not in json.dumps(request)


def test_incomplete_ai_response_is_never_accepted(monkeypatch):
    provider(monkeypatch, {"status": "incomplete", "output": []})
    with pytest.raises(ValueError, match="incomplete"):
        ai_extract("Notice", {"api_key": "test", "model": "test"})


def test_invalid_ai_schema_rejected(monkeypatch):
    provider(monkeypatch, {"status": "completed", "output": [{"content": [{"type": "output_text", "text": "[]"}]}]})
    with pytest.raises(ValueError, match="schema"):
        ai_extract("Notice", {"api_key": "test", "model": "test"})


def test_provider_errors_are_sanitized(monkeypatch):
    provider(monkeypatch, {"error": {"message": "private provider details test-secret"}}, 401)
    with pytest.raises(ValueError) as error:
        ai_extract("Notice", {"api_key": "test-secret", "model": "test"})
    assert "401" in str(error.value)
    assert "test-secret" not in str(error.value)


def test_egypt_locations_match_across_arabic_and_english():
    assert locations_match("القاهرة", ["Cairo"])
    assert locations_match("Alexandria", ["الإسكندرية"])
    assert locations_match("Giza", ["Egypt"])
    assert not locations_match("London", ["Egypt"])


def test_arabic_construction_specialism_matches():
    result = match_company({"title": "صيانة أعمال الكهرباء", "status": "open", "location": "القاهرة"}, {"sectors": ["كهرباء"], "locations": ["Cairo"]})
    assert result["recommendation"] == "Investigate"
    assert result["fit_score"] >= 65
