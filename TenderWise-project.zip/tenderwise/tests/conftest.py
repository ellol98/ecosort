import os
import tempfile

# All tests run offline with isolated data; no developer credentials are used.
_data = tempfile.TemporaryDirectory(prefix="tenderwise-tests-")
os.environ["OPENAI_API_KEY"] = ""
os.environ["ADMIN_TOKEN"] = ""
os.environ["TENDERWISE_DATA_DIR"] = _data.name
