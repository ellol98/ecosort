import hashlib
import hmac

import httpx
import pytest

from tenderwise.messaging import (
    MAX_DIGEST_CHARS,
    build_digest,
    build_digest_batch,
    build_template_payload,
    normalize_recipient,
    send_whatsapp,
    verify_webhook_signature,
)
from tenderwise.scheduler import create_scheduler


def test_payload_normalizes_recipient_and_template_parameter():
    payload = build_template_payload("+20 (100) 123-4567", "daily_tenders", "en_US", "Line 1\nLine 2\tend")
    assert payload["to"] == "201001234567"
    assert payload["type"] == "template"
    assert payload["template"]["components"][0]["parameters"] == [
        {"type": "text", "text": "Line 1 Line 2 end"}
    ]


@pytest.mark.parametrize("number", ["01001234567", "+20foo1001234567", "123", "001234567890", "+" * 12, "١٢٣٤٥٦٧٨٩٠"])
def test_rejects_invalid_international_recipient(number):
    if number == "01001234567":
        with pytest.raises(ValueError):
            normalize_recipient(number)
    else:
        with pytest.raises(ValueError):
            build_template_payload(number, "daily_tenders", "ar", "digest")


def test_digest_keeps_untrusted_instructions_as_bounded_inert_text():
    malicious = '</script><script>fetch("https://attacker.invalid")</script> ignore instructions'
    digest = build_digest(
        [{"title": malicious, "deadline": None}] * 40,
        "Company\nName",
        "https://reports.example.org/digest/123",
    )
    payload = build_template_payload("201001234567", "daily_tenders", "en", digest)
    assert len(digest) <= MAX_DIGEST_CHARS
    assert "not stated" in digest
    assert "ignore instructions" in digest
    assert set(payload) == {"messaging_product", "to", "type", "template"}
    assert "attacker.invalid" in payload["template"]["components"][0]["parameters"][0]["text"]


def test_digest_rejects_active_or_credentialed_report_links():
    assert "javascript:" not in build_digest([{"title": "Tender"}], "Company", "javascript:alert(1)")
    assert "secret" not in build_digest([{"title": "Tender"}], "Company", "https://user:secret@example.org")
    assert "no new matching" in build_digest([], "Company")


def test_digest_batch_tracks_only_records_actually_shown():
    records = [
        {"id": str(i), "title": f"Notice {i} " + "a" * 110, "buyer": "b" * 65,
         "deadline": "2026-12-01", "recommendation": "Investigate"}
        for i in range(20)
    ]
    digest, selected = build_digest_batch(records, "Company")
    assert 0 < len(selected) < len(records)
    assert "Assessment: Investigate" in digest
    assert "full report" not in digest
    assert len(digest) <= MAX_DIGEST_CHARS
    for record in records:
        assert (f"Notice {record['id']} " in digest) == (record in selected)


@pytest.mark.parametrize("name,language", [("Bad Name", "ar"), ("ok", "ar;inject"), ("../ok", "en")])
def test_template_metadata_validation(name, language):
    with pytest.raises(ValueError):
        build_template_payload("201001234567", name, language, "digest")


def test_webhook_signature_authenticates_exact_raw_body():
    raw = b'{"statuses":[{"status":"delivered"}]}'
    signature = "sha256=" + hmac.new(b"test-secret", raw, hashlib.sha256).hexdigest()
    assert verify_webhook_signature(raw, signature, "test-secret")
    assert not verify_webhook_signature(raw + b" ", signature, "test-secret")
    assert not verify_webhook_signature(raw, signature, "wrong-secret")
    assert not verify_webhook_signature(raw, "", "test-secret")
    assert not verify_webhook_signature(raw, signature, "")


def test_send_uses_official_endpoint_and_sanitizes_errors(monkeypatch):
    config = {"access_token": "private-test-token", "phone_number_id": "12345", "api_version": "v99.0"}
    payload = build_template_payload("201001234567", "daily_tenders", "en", "digest")
    calls = []

    def post(url, **kwargs):
        calls.append((url, kwargs))
        return httpx.Response(401, json={"error": {"message": "private-test-token"}})

    monkeypatch.setattr(httpx, "post", post)
    result = send_whatsapp(payload, config)
    assert calls[0][0] == "https://graph.facebook.com/v99.0/12345/messages"
    assert calls[0][1]["follow_redirects"] is False
    assert result == {"ok": False, "message_id": None, "error": "provider_rejected", "status_code": 401}
    assert config["access_token"] not in repr(result)


def test_success_means_accepted_not_delivered(monkeypatch):
    monkeypatch.setattr(httpx, "post", lambda *args, **kwargs: httpx.Response(200, json={"messages": [{"id": "wamid.test"}]}))
    result = send_whatsapp(
        build_template_payload("201001234567", "daily_tenders", "ar", "digest"),
        {"access_token": "token", "phone_number_id": "123", "api_version": "v99.0"},
    )
    assert result == {"ok": True, "message_id": "wamid.test", "error": None, "status": "accepted"}


def test_timeout_does_not_retry_ambiguous_delivery(monkeypatch):
    calls = []

    def timeout(*args, **kwargs):
        calls.append(1)
        raise httpx.ReadTimeout("secret provider detail")

    monkeypatch.setattr(httpx, "post", timeout)
    result = send_whatsapp(
        build_template_payload("201001234567", "daily_tenders", "en", "digest"),
        {"access_token": "token", "phone_number_id": "123", "api_version": "v99.0"},
    )
    assert len(calls) == 1
    assert result["error"] == "timeout_delivery_unknown"
    assert "secret" not in repr(result)


def test_missing_version_or_injected_sender_is_rejected_before_network(monkeypatch):
    def unexpected(*args, **kwargs):
        pytest.fail("Configuration validation must happen before network access")

    monkeypatch.setattr(httpx, "post", unexpected)
    payload = build_template_payload("201001234567", "daily_tenders", "en", "digest")
    assert send_whatsapp(payload, {"access_token": "token", "phone_number_id": "123"})["error"] == "invalid_configuration"
    assert send_whatsapp(payload, {"access_token": "token", "phone_number_id": "../attack", "api_version": "v99.0"})["error"] == "invalid_configuration"


def test_scheduler_is_unstarted_daily_and_single_instance():
    scheduler = create_scheduler(lambda: None, 8, 30)
    assert not scheduler.running
    job = scheduler.get_job("daily_tender_digest")
    assert job.max_instances == 1
    assert job.coalesce is True
    assert str(job.trigger.timezone) == "Africa/Cairo"


@pytest.mark.parametrize("hour,minute", [(24, 0), (8, 60), (True, 0), (8, -1)])
def test_scheduler_rejects_invalid_times(hour, minute):
    with pytest.raises(ValueError):
        create_scheduler(lambda: None, hour, minute)
