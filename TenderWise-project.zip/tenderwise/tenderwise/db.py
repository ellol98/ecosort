import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def encode(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


class Store:
    def __init__(self, folder: Path):
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / "tenderwise.sqlite3"
        self.lock = threading.RLock()
        self.ingestion_lock = threading.RLock()
        with self.connection() as conn:
            conn.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS tenders (
                    id TEXT PRIMARY KEY, content_hash TEXT NOT NULL,
                    source_url TEXT NOT NULL, payload TEXT NOT NULL, raw_text TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS tender_hash ON tenders(content_hash);
                CREATE INDEX IF NOT EXISTS tender_source ON tenders(source_url);
                CREATE TABLE IF NOT EXISTS versions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, tender_id TEXT NOT NULL,
                    content_hash TEXT NOT NULL, payload TEXT NOT NULL,
                    raw_text TEXT NOT NULL, saved_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sources (id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS outbox (
                    id TEXT PRIMARY KEY, dedupe_key TEXT UNIQUE NOT NULL,
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
                    details TEXT NOT NULL, created_at TEXT NOT NULL
                );
            """)

    @contextmanager
    def connection(self):
        with self.lock:
            conn = sqlite3.connect(self.path, timeout=15)
            conn.row_factory = sqlite3.Row
            try:
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def get(self, key, default=None):
        with self.connection() as conn:
            row = conn.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set(self, key, value):
        with self.connection() as conn:
            conn.execute("INSERT INTO kv VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, encode(value)))

    def tenders(self, include_raw=False):
        with self.connection() as conn:
            rows = conn.execute("SELECT payload,raw_text FROM tenders ORDER BY rowid DESC").fetchall()
        return [dict(json.loads(r["payload"]), **({"raw_text": r["raw_text"]} if include_raw else {})) for r in rows]

    def tender(self, tender_id, include_raw=False):
        with self.connection() as conn:
            row = conn.execute("SELECT payload,raw_text FROM tenders WHERE id=?", (tender_id,)).fetchone()
        if not row:
            return None
        result = json.loads(row["payload"])
        if include_raw:
            result["raw_text"] = row["raw_text"]
        return result

    def duplicate(self, content_hash, source_url=""):
        with self.connection() as conn:
            row = conn.execute("SELECT payload FROM tenders WHERE content_hash=? LIMIT 1", (content_hash,)).fetchone()
            if row:
                return json.loads(row[0]), True
            if source_url:
                row = conn.execute("SELECT payload FROM tenders WHERE source_url=? LIMIT 1", (source_url,)).fetchone()
        return (json.loads(row[0]), False) if row else (None, False)

    def save_tender(self, record, raw_text):
        payload = dict(record)
        payload.pop("raw_text", None)
        with self.connection() as conn:
            old = conn.execute("SELECT * FROM tenders WHERE id=?", (payload["id"],)).fetchone()
            if old and old["content_hash"] != payload["content_hash"]:
                conn.execute("INSERT INTO versions(tender_id,content_hash,payload,raw_text,saved_at) VALUES(?,?,?,?,?)", (payload["id"], old["content_hash"], old["payload"], old["raw_text"], utcnow()))
            conn.execute("INSERT INTO tenders VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET content_hash=excluded.content_hash,source_url=excluded.source_url,payload=excluded.payload,raw_text=excluded.raw_text", (payload["id"], payload["content_hash"], payload.get("identity_key", payload.get("source_url", "")), encode(payload), raw_text))
        return payload

    def save_source(self, record):
        with self.connection() as conn:
            conn.execute("INSERT INTO sources VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload", (record["id"], encode(record)))

    def sources(self):
        with self.connection() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT payload FROM sources ORDER BY rowid DESC").fetchall()]

    def source(self, source_id):
        return next((s for s in self.sources() if s["id"] == source_id), None)

    def delete_source(self, source_id):
        with self.connection() as conn:
            return conn.execute("DELETE FROM sources WHERE id=?", (source_id,)).rowcount

    def reserve_outbox(self, record, key, retry_failed=False):
        with self.connection() as conn:
            old = conn.execute("SELECT payload FROM outbox WHERE dedupe_key=?", (key,)).fetchone()
            if old:
                prior = json.loads(old[0])
                if retry_failed and prior.get("status") == "failed" and prior.get("error") in {"provider_rejected", "invalid_configuration", "invalid_payload"}:
                    history = prior.get("attempt_history", []) + [{"created_at": prior["created_at"], "status": prior["status"], "error": prior.get("error"), "message_id": prior.get("message_id")}]
                    record.update(id=prior["id"], attempt_history=history)
                    conn.execute("UPDATE outbox SET payload=? WHERE id=?", (encode(record), prior["id"]))
                    return record, True
                return prior, False
            conn.execute("INSERT INTO outbox VALUES(?,?,?)", (record["id"], key, encode(record)))
        return record, True

    def save_outbox(self, record):
        with self.connection() as conn:
            conn.execute("UPDATE outbox SET payload=? WHERE id=?", (encode(record), record["id"]))

    def outbox(self):
        with self.connection() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT payload FROM outbox ORDER BY rowid DESC LIMIT 100").fetchall()]

    def all_outbox(self):
        with self.connection() as conn:
            return [json.loads(r[0]) for r in conn.execute("SELECT payload FROM outbox ORDER BY rowid DESC").fetchall()]

    def audit(self, action, details):
        with self.connection() as conn:
            conn.execute("INSERT INTO audit(action,details,created_at) VALUES(?,?,?)", (action, encode(details), utcnow()))

    def export(self):
        with self.connection() as conn:
            audit = [dict(row) for row in conn.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 500").fetchall()]
            versions = [dict(row) for row in conn.execute("SELECT * FROM versions ORDER BY id DESC").fetchall()]
        return {"schema_version": 1, "exported_at": utcnow(), "company": self.get("company"), "settings": self.get("settings"), "sources": self.sources(), "tenders": self.tenders(True), "versions": versions, "outbox": self.all_outbox(), "audit": audit}
