import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env", override=False)


def data_dir() -> Path:
    value = Path(os.getenv("TENDERWISE_DATA_DIR", str(ROOT / "data")))
    return value if value.is_absolute() else ROOT / value


def ai_config() -> dict:
    return {
        "api_key": os.getenv("OPENAI_API_KEY", ""),
        "model": os.getenv("OPENAI_MODEL", "gpt-5-mini"),
        "enabled": os.getenv("AI_ENABLED", "true").lower() == "true",
    }


def whatsapp_config() -> dict:
    return {
        "access_token": os.getenv("WHATSAPP_ACCESS_TOKEN", ""),
        "phone_number_id": os.getenv("WHATSAPP_PHONE_NUMBER_ID", ""),
        "api_version": os.getenv("WHATSAPP_API_VERSION", ""),
    }


def services() -> dict:
    ai = ai_config()
    wa = whatsapp_config()
    return {
        "ai_configured": bool(ai["api_key"] and ai["enabled"]),
        "whatsapp_configured": all(wa.values()),
        "admin_auth": bool(os.getenv("ADMIN_TOKEN")),
        "model": ai["model"],
        "public_report_links": False,
    }
