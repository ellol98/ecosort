from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, Field, field_validator


class CompanyProfile(BaseModel):
    name: str = Field(default="Your construction company", min_length=1, max_length=160)
    sectors: list[str] = Field(default_factory=lambda: ["General construction", "Buildings", "Renovation", "Infrastructure", "MEP"])
    locations: list[str] = Field(default_factory=list)
    max_project_value: float | None = Field(default=None, ge=0)
    available_bid_bond: float | None = Field(default=None, ge=0)
    contractor_grade: str = Field(default="", max_length=160)
    notes: str = Field(default="", max_length=5000)

    @field_validator("sectors", "locations")
    @classmethod
    def limit_items(cls, values):
        if len(values) > 40 or any(len(v) > 160 for v in values):
            raise ValueError("Use at most 40 short entries.")
        return [v.strip() for v in values if v.strip()]


class AppSettings(BaseModel):
    schedule_enabled: bool = False
    digest_hour: int = Field(default=8, ge=0, le=23)
    digest_minute: int = Field(default=0, ge=0, le=59)
    timezone: str = "Africa/Cairo"
    whatsapp_recipient: str = Field(default="", max_length=24)
    whatsapp_opt_in: bool = False
    whatsapp_enabled: bool = False
    whatsapp_template_name: str = Field(default="", max_length=512)
    whatsapp_template_approved: bool = False
    whatsapp_language: str = Field(default="en", max_length=12)
    whatsapp_test_mode: bool = True
    require_human_review: bool = True

    @field_validator("timezone")
    @classmethod
    def valid_zone(cls, value):
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError) as exc:
            raise ValueError("Use a valid IANA timezone, for example Africa/Cairo.") from exc
        return value


class SourceInput(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    type: Literal["rss", "json", "html"]
    url: str = Field(min_length=8, max_length=2048)
    permission_confirmed: bool = False
    enabled: bool = True
    config: dict = Field(default_factory=dict)


class TextImport(BaseModel):
    text: str = Field(min_length=20, max_length=2_000_000)
    title: str = Field(default="Imported tender", max_length=300)
    source_url: str = Field(default="", max_length=2048)


class URLImport(BaseModel):
    url: str = Field(min_length=8, max_length=2048)


class TenderReview(BaseModel):
    review_status: Literal["pending", "approved", "rejected"] | None = None
    feedback: Literal["relevant", "irrelevant", ""] | None = None


class SendRequest(BaseModel):
    live: bool = False
    retry_failed: bool = False
