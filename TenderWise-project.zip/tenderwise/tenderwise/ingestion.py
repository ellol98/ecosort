"""Permission-gated, bounded tender document ingestion.

No source is enabled implicitly. ``collect_source`` accepts dictionaries such as::

    {"type": "rss", "url": "https://supplier.example/feed.xml",
     "permission_confirmed": True, "limit": 10, "fetch_details": False}
    {"type": "json", "url": "https://supplier.example/notices.json",
     "permission_confirmed": True, "items_path": "results",
     "fields": {"title": "name", "text": "description", "url": "link",
                "deadline": "closing_date", "buyer": "authority"}}
    {"type": "html", "url": "https://supplier.example/notices",
     "permission_confirmed": True,
     "selectors": {"item": "article.notice", "title": "h2",
                   "link": "a[href]", "text": ".description"}}

HTML adapters read server-rendered pages only; they do not bypass logins,
CAPTCHAs, subscriptions, robots rules, or website permissions. Permission must
cover automated access and the intended use. Public availability alone does
not establish permission. Detail fetching is off by default, and each adapter
returns at most 25 documents per run. No built-in TenderEgypt integration is
claimed. Configurable adapters must be tested against each permitted source.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
import socket
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from io import BytesIO
from pathlib import PurePosixPath
from typing import Any, TypedDict
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit

import httpx
from bs4 import BeautifulSoup
from defusedxml import ElementTree
from pypdf import PdfReader

MAX_DOWNLOAD_BYTES = 10 * 1024 * 1024
MAX_TEXT_BYTES = 2 * 1024 * 1024
MAX_DOCUMENTS = 25
MAX_REDIRECTS = 3
MAX_PDF_PAGES = 250
MAX_PDF_PAGE_STREAM_BYTES = 8 * 1024 * 1024
FETCH_WALL_SECONDS = 45


class IngestionError(ValueError):
    """An input could not be safely fetched or faithfully extracted."""


class OCRRequiredError(IngestionError):
    """A PDF has no selectable text and needs an OCR processing step."""


class SourceConfig(TypedDict, total=False):
    type: str
    url: str
    permission_confirmed: bool
    permission_note: str
    limit: int
    fetch_details: bool
    items_path: str
    fields: dict[str, str]
    selectors: dict[str, str]
    same_origin_only: bool


@dataclass
class IngestedDocument:
    title: str
    text: str
    source_url: str | None = None
    filename: str | None = None
    content_hash: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class _Download:
    data: bytes
    url: str
    content_type: str


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_filename(filename: str) -> str:
    name = str(filename or "document.txt").replace("\\", "/").rsplit("/", 1)[-1]
    name = re.sub(r"[\x00-\x1f\x7f]", "", name).strip(" .")
    return name[:180] or "document.txt"


def _clean_text(text: str) -> str:
    text = str(text).replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[^\S\n]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if len(text.encode("utf-8")) > MAX_TEXT_BYTES:
        raise IngestionError("Extracted text exceeds the 2 MB limit; split this document.")
    return text


def _plain_html(value: str | bytes) -> str:
    soup = BeautifulSoup(value, "html.parser")
    for tag in soup(["script", "style", "noscript", "template", "iframe", "object"]):
        tag.decompose()
    return _clean_text(soup.get_text("\n", strip=True))


def _make_document(title: str, text: str, **kwargs: Any) -> IngestedDocument:
    text = _clean_text(text)
    if not text:
        raise IngestionError("The document contains no usable text.")
    return IngestedDocument(
        title=_clean_text(title)[:500] or "Untitled tender document",
        text=text,
        content_hash=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        **kwargs,
    )


def extract_upload(data: bytes, filename: str) -> IngestedDocument:
    """Extract an uploaded PDF, HTML, or text file without executing its contents.

    Scanned PDFs require OCR and return an explicit error rather than an empty
    successful result. Mixed PDFs retain page markers and flag empty pages.
    """
    if not isinstance(data, bytes) or not data:
        raise IngestionError("Upload a non-empty document.")
    if len(data) > MAX_DOWNLOAD_BYTES:
        raise IngestionError("The document exceeds the 10 MB input limit.")
    filename = _safe_filename(filename)
    suffix = PurePosixPath(filename).suffix.lower()
    metadata: dict[str, Any] = {
        "ingested_at": _utc_now(),
        "raw_sha256": hashlib.sha256(data).hexdigest(),
        "input_bytes": len(data),
        "warnings": [],
    }
    title = PurePosixPath(filename).stem
    if data.lstrip().startswith(b"%PDF-") or suffix == ".pdf":
        metadata["extraction_method"] = "pdf_text"
        try:
            reader = PdfReader(BytesIO(data), strict=False)
            if reader.is_encrypted and not reader.decrypt(""):
                raise IngestionError("This PDF is encrypted; provide an unlocked copy.")
            if len(reader.pages) > MAX_PDF_PAGES:
                raise IngestionError(f"PDF exceeds {MAX_PDF_PAGES} pages; split it first.")
            metadata["page_count"] = len(reader.pages)
            pages: list[str] = []
            empty_pages: list[int] = []
            total_text_bytes = 0
            for number, page in enumerate(reader.pages, 1):
                contents = page.get_contents()
                if contents and len(contents.get_data()) > MAX_PDF_PAGE_STREAM_BYTES:
                    raise IngestionError(f"PDF page {number} is too complex to process safely.")
                page_text = _clean_text(page.extract_text() or "")
                total_text_bytes += len(page_text.encode("utf-8"))
                if total_text_bytes > MAX_TEXT_BYTES:
                    raise IngestionError("Extracted text exceeds the 2 MB limit; split this PDF.")
                if page_text:
                    pages.append(f"[Page {number}]\n{page_text}")
                else:
                    empty_pages.append(number)
            if not pages:
                raise OCRRequiredError(
                    "This PDF has no selectable text (it may be scanned). "
                    "Run Arabic/English OCR and upload the searchable PDF or extracted TXT."
                )
            if empty_pages:
                metadata["empty_text_pages"] = empty_pages
                metadata["warnings"].append(
                    "Some pages have no selectable text and may need OCR; the extraction may be incomplete."
                )
            pdf_title = reader.metadata.title if reader.metadata else None
            if pdf_title:
                title = str(pdf_title)
            text = "\n\n".join(pages)
        except IngestionError:
            raise
        except Exception as exc:
            raise IngestionError("The PDF could not be read; provide a valid searchable PDF.") from exc
    elif suffix in {".html", ".htm"}:
        metadata["extraction_method"] = "html_text"
        soup = BeautifulSoup(data, "html.parser")
        if soup.title:
            title = soup.title.get_text(" ", strip=True) or title
        text = _plain_html(data)
    elif suffix in {".txt", ".text", ".md"}:
        metadata["extraction_method"] = "plain_text"
        try:
            if data.startswith((b"\xff\xfe", b"\xfe\xff")):
                text = data.decode("utf-16")
            else:
                text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            # Windows-1256 covers many legacy Arabic tender text exports.
            text = data.decode("cp1256", errors="replace")
            metadata["warnings"].append("Input was decoded as Windows-1256; verify unusual characters.")
        if "\x00" in text or sum(ord(ch) < 32 and ch not in "\n\r\t" for ch in text) > max(2, len(text) // 100):
            raise IngestionError("This file appears to be binary. Use PDF, HTML, or plain TXT.")
    else:
        raise IngestionError("Supported uploads: .pdf, .html, .htm, .txt, .text, and .md.")
    return _make_document(title, text, filename=filename, metadata=metadata)


def _public_ip(value: str) -> bool:
    try:
        address = ipaddress.ip_address(value.split("%", 1)[0])
    except ValueError:
        return False
    if not address.is_global or address.is_multicast or address.is_unspecified:
        return False
    if isinstance(address, ipaddress.IPv6Address):
        embedded = address.ipv4_mapped or address.sixtofour
        if embedded is not None and not embedded.is_global:
            return False
        if address.teredo is not None and any(not part.is_global for part in address.teredo):
            return False
    return True


def normalize_url(url: str) -> str:
    """Normalize an HTTPS URL, rejecting credentials, local literals, and ports.

    DNS is checked separately immediately before every outbound connection.
    """
    if not isinstance(url, str) or not url.strip() or len(url) > 8192:
        raise IngestionError("Provide a valid public HTTPS URL.")
    url = url.strip()
    if re.search(r"[\x00-\x20\x7f\\]", url):
        raise IngestionError("URLs must not contain whitespace, control characters, or backslashes.")
    try:
        parts = urlsplit(url)
        if parts.scheme.lower() != "https" or not parts.hostname:
            raise IngestionError("Only public HTTPS URLs are supported.")
        if parts.username is not None or parts.password is not None:
            raise IngestionError("Credentials in source URLs are not allowed.")
        if parts.port not in (None, 443):
            raise IngestionError("Only the standard HTTPS port 443 is supported.")
        host = parts.hostname.rstrip(".").lower().encode("idna").decode("ascii")
    except (ValueError, UnicodeError) as exc:
        raise IngestionError("The source URL is malformed.") from exc
    if not host or "%" in host or host == "localhost" or host.endswith((".localhost", ".local", ".internal", ".invalid")):
        raise IngestionError("Local and private hosts are not allowed.")
    try:
        ipaddress.ip_address(host)
    except ValueError:
        if "." not in host or not re.fullmatch(r"[a-z0-9.-]+", host):
            raise IngestionError("Provide a public fully qualified hostname.")
    else:
        if not _public_ip(host):
            raise IngestionError("Local, private, reserved, and non-public IP addresses are not allowed.")
    authority = f"[{host}]" if ":" in host else host
    return urlunsplit(("https", authority, parts.path or "/", parts.query, ""))


def _resolve_public_addresses(host: str) -> list[str]:
    try:
        ipaddress.ip_address(host)
    except ValueError:
        try:
            records = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise IngestionError("Could not resolve the source hostname.") from exc
        addresses = list(dict.fromkeys(record[4][0] for record in records))
    else:
        addresses = [host]
    # Reject a mixed public/private DNS answer rather than choosing its public
    # entry and accidentally accepting a split-horizon/internal target.
    if not addresses or any(not _public_ip(address) for address in addresses):
        raise IngestionError("The hostname resolves to a private or non-public address.")
    return addresses


def _fetch_bytes(url: str) -> _Download:
    current = normalize_url(url)
    started = time.monotonic()
    # Disable environment proxies: they could resolve a hostname differently
    # from our validation. DNS is pinned to a validated IP for each connection;
    # the original hostname is retained for Host, SNI, and certificate checking.
    try:
        with httpx.Client(
            timeout=httpx.Timeout(12.0, connect=8.0),
            follow_redirects=False,
            trust_env=False,
            limits=httpx.Limits(max_connections=1, max_keepalive_connections=0),
            headers={"User-Agent": "TenderWise/0.1 (authorized source research)", "Accept-Encoding": "identity"},
        ) as client:
            for hop in range(MAX_REDIRECTS + 1):
                if time.monotonic() - started > FETCH_WALL_SECONDS:
                    raise IngestionError("The source exceeded the download time limit.")
                parts = urlsplit(current)
                host = parts.hostname or ""
                address = _resolve_public_addresses(host)[0]
                authority = f"[{address}]" if ":" in address else address
                pinned_url = urlunsplit(("https", authority, parts.path, parts.query, ""))
                original_authority = f"[{host}]" if ":" in host else host
                with client.stream(
                    "GET", pinned_url,
                    headers={"Host": original_authority},
                    extensions={"sni_hostname": host},
                ) as response:
                    if response.status_code in {301, 302, 303, 307, 308}:
                        if hop == MAX_REDIRECTS:
                            raise IngestionError("Too many source redirects.")
                        location = response.headers.get("location")
                        if not location:
                            raise IngestionError("The source returned a redirect without a destination.")
                        current = normalize_url(urljoin(current, location))
                        continue
                    response.raise_for_status()
                    length = response.headers.get("content-length", "")
                    if length.isdigit() and int(length) > MAX_DOWNLOAD_BYTES:
                        raise IngestionError("The source document exceeds the 10 MB download limit.")
                    chunks: list[bytes] = []
                    size = 0
                    for chunk in response.iter_bytes(chunk_size=65536):
                        size += len(chunk)
                        if size > MAX_DOWNLOAD_BYTES:
                            raise IngestionError("The source document exceeds the 10 MB download limit.")
                        if time.monotonic() - started > FETCH_WALL_SECONDS:
                            raise IngestionError("The source exceeded the download time limit.")
                        chunks.append(chunk)
                    return _Download(b"".join(chunks), current, response.headers.get("content-type", "").lower())
    except IngestionError:
        raise
    except httpx.HTTPStatusError as exc:
        raise IngestionError(f"The source returned HTTP {exc.response.status_code}.") from exc
    except httpx.HTTPError as exc:
        raise IngestionError("Could not download the source over verified HTTPS. Check access and try again.") from exc
    raise IngestionError("Could not retrieve the source.")


def fetch_document(url: str) -> IngestedDocument:
    """Download and extract one public HTTPS document with validated redirects."""
    requested_url = normalize_url(url)
    downloaded = _fetch_bytes(requested_url)
    path_name = _safe_filename(unquote(urlsplit(downloaded.url).path.rsplit("/", 1)[-1]))
    content_type = downloaded.content_type.split(";", 1)[0].strip()
    if downloaded.data.lstrip().startswith(b"%PDF-") or content_type == "application/pdf":
        filename = str(PurePosixPath(path_name).with_suffix(".pdf"))
    elif content_type in {"text/html", "application/xhtml+xml"}:
        filename = str(PurePosixPath(path_name).with_suffix(".html"))
    elif content_type == "text/plain":
        filename = str(PurePosixPath(path_name).with_suffix(".txt"))
    elif PurePosixPath(path_name).suffix.lower() in {".txt", ".text", ".md", ".html", ".htm", ".pdf"}:
        filename = path_name
    else:
        raise IngestionError("The URL does not identify a supported PDF, HTML, or text document.")
    document = extract_upload(downloaded.data, filename)
    document.source_url = downloaded.url
    document.metadata.update({"requested_url": requested_url, "fetched_at": _utc_now(), "content_type": content_type})
    return document


def _nested(value: Any, path: str, default: Any = "") -> Any:
    if not path:
        return value
    for component in path.split("."):
        if isinstance(value, dict):
            value = value.get(component, default)
        elif isinstance(value, list) and component.isdigit() and int(component) < len(value):
            value = value[int(component)]
        else:
            return default
    return value


def _string(value: Any) -> str:
    if value is None:
        return ""
    return str(value) if isinstance(value, (str, int, float, bool)) else json.dumps(value, ensure_ascii=False)


def _entry_document(title: str, text: str, link: str, feed_url: str, metadata: dict[str, Any]) -> IngestedDocument:
    source_url = normalize_url(urljoin(feed_url, link)) if link else feed_url
    # These are excerpts, not a claim that all bidding documents were read.
    metadata.update({"source_feed_url": feed_url, "document_scope": "listing_excerpt", "ingested_at": _utc_now()})
    return _make_document(title, f"{title}\n\n{_plain_html(text)}", source_url=source_url, metadata=metadata)


def _rss_documents(download: _Download, limit: int) -> list[IngestedDocument]:
    try:
        root = ElementTree.fromstring(download.data)
    except Exception as exc:
        raise IngestionError("The source did not return valid, safe RSS/Atom XML.") from exc
    documents = []
    for entry in root.iter():
        if entry.tag.rsplit("}", 1)[-1].lower() not in {"item", "entry"}:
            continue
        values: dict[str, str] = {}
        link = ""
        for child in entry:
            name = child.tag.rsplit("}", 1)[-1].lower()
            value = "".join(child.itertext()).strip()
            if name == "link":
                if child.get("href") and child.get("rel", "alternate") == "alternate":
                    link = child.get("href", "")
                elif not child.get("href") and value:
                    link = value
            elif value:
                values[name] = value
        title = values.get("title", "Untitled tender")
        description = values.get("encoded") or values.get("content") or values.get("description") or values.get("summary", "")
        metadata = {"source_type": "rss", "reference": values.get("guid") or values.get("id", ""), "published": values.get("pubdate") or values.get("published") or values.get("updated", "")}
        try:
            documents.append(_entry_document(title, description, link, download.url, metadata))
        except IngestionError:
            # A hostile link is never fetched or returned. Valid entries in a
            # publisher's feed remain usable when an unrelated entry is bad.
            continue
        if len(documents) >= limit:
            break
    return documents


def _json_documents(download: _Download, config: dict[str, Any], limit: int) -> list[IngestedDocument]:
    try:
        data = json.loads(download.data)
    except (ValueError, UnicodeError) as exc:
        raise IngestionError("The source did not return valid JSON.") from exc
    path = config.get("items_path", "")
    if not isinstance(path, str):
        raise IngestionError("JSON items_path must be a dotted string path.")
    items = _nested(data, path)
    if not path and isinstance(items, dict):
        items = items.get("items", items.get("results", items))
    if not isinstance(items, list):
        raise IngestionError("JSON items_path must point to an array of notices.")
    fields = config.get("fields", {})
    if not isinstance(fields, dict) or any(not isinstance(v, str) for v in fields.values()):
        raise IngestionError("JSON fields must map field names to dotted string paths.")
    documents = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = _string(_nested(item, fields.get("title", "title"))) or "Untitled tender"
        description = _string(_nested(item, fields.get("text", "description")))
        if not description and "text" not in fields:
            description = _string(item.get("summary") or item.get("content") or item.get("text"))
        link = _string(_nested(item, fields.get("url", "url"))) or _string(item.get("link"))
        metadata: dict[str, Any] = {"source_type": "json"}
        for key in {"deadline", "buyer", "reference", "published", "status", "country"}:
            value = _nested(item, fields.get(key, key))
            if value != "":
                metadata[key] = _string(value)
        # Include structured facts in the analysis input, retaining their exact
        # published values rather than inferring whether a notice is open.
        facts = "\n".join(f"{key}: {value}" for key, value in metadata.items() if key != "source_type")
        try:
            documents.append(_entry_document(title, f"{description}\n{facts}", link, download.url, metadata))
        except IngestionError:
            continue
        if len(documents) >= limit:
            break
    return documents


def _html_documents(download: _Download, config: dict[str, Any], limit: int) -> list[IngestedDocument]:
    selectors = config.get("selectors", {})
    if not isinstance(selectors, dict) or not selectors.get("item"):
        raise IngestionError("An HTML source requires selectors.item for its notice rows.")
    try:
        soup = BeautifulSoup(download.data, "html.parser")
        items = soup.select(selectors["item"])
        documents = []
        for item in items:
            title_node = item.select_one(selectors["title"]) if selectors.get("title") else None
            text_node = item.select_one(selectors["text"]) if selectors.get("text") else item
            link_selector = selectors.get("link", "a[href]")
            link_node = item if item.name == "a" and item.has_attr("href") else item.select_one(link_selector)
            link = str(link_node.get("href", "")) if link_node else ""
            title = title_node.get_text(" ", strip=True) if title_node else (link_node.get_text(" ", strip=True) if link_node else "Untitled tender")
            text = str(text_node) if text_node else ""
            try:
                document = _entry_document(title, text, link, download.url, {"source_type": "html"})
            except IngestionError:
                continue
            if config.get("same_origin_only", True) and urlsplit(document.source_url or "").hostname != urlsplit(download.url).hostname:
                continue
            documents.append(document)
            if len(documents) >= limit:
                break
        return documents
    except IngestionError:
        raise
    except Exception as exc:
        raise IngestionError("The HTML selectors are invalid or do not match this source format.") from exc


def collect_source(config: dict[str, Any]) -> list[IngestedDocument]:
    """Collect bounded excerpts from an explicitly authorized RSS/JSON/HTML source.

    ``fetch_details=True`` additionally retrieves linked documents. Individual
    detail failures retain the excerpt with a ``detail_fetch_error`` warning.
    An empty list means no matching entries were found, not verified absence of
    open tenders. Opening dates, deadlines, amendments and eligibility must be
    verified from the source documents by the application/user.
    """
    if not isinstance(config, dict) or config.get("permission_confirmed") is not True:
        raise IngestionError("Confirm permission for automated access and intended use before enabling this source.")
    kind = config.get("type", "")
    if kind not in {"rss", "json", "html"}:
        raise IngestionError("Source type must be rss, json, or html.")
    try:
        limit = int(config.get("limit", MAX_DOCUMENTS))
        if limit < 1:
            raise ValueError("non-positive limit")
        limit = min(MAX_DOCUMENTS, limit)
    except (ValueError, TypeError) as exc:
        raise IngestionError("Source limit must be a positive integer.") from exc
    download = _fetch_bytes(config.get("url", ""))
    if kind == "rss":
        documents = _rss_documents(download, limit)
    elif kind == "json":
        documents = _json_documents(download, config, limit)
    else:
        documents = _html_documents(download, config, limit)
    unique: list[IngestedDocument] = []
    seen: set[tuple[str | None, str]] = set()
    for document in documents:
        identity = (document.source_url, document.content_hash)
        if identity in seen:
            continue
        seen.add(identity)
        document.metadata["permission_confirmed"] = True
        document.metadata["permission_note"] = _string(config.get("permission_note", ""))[:2000]
        if config.get("fetch_details") is True and document.source_url and document.source_url != download.url:
            try:
                detail = fetch_document(document.source_url)
                detail.metadata.update(document.metadata)
                detail.metadata["document_scope"] = "linked_document"
                document = detail
            except IngestionError as exc:
                document.metadata["detail_fetch_error"] = str(exc)
        unique.append(document)
    return unique
