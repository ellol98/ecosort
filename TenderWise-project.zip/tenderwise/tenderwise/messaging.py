"""Bounded WhatsApp digests and official Cloud API delivery helpers.

Consent, template approval, dry-run mode, and an idempotent outbox belong to the
calling service. An API acceptance is not confirmation of delivery: use signed
status webhooks to update the outbox.
"""

from __future__ import annotations

import hashlib
import hmac
import re
from typing import Any
from urllib.parse import urlsplit

import httpx


MAX_DIGEST_CHARS = 900
_TEMPLATE_NAME = re.compile(r"[a-z][a-z0-9_]{0,511}\Z")
_LANGUAGE = re.compile(r"[a-z]{2,3}(?:_[A-Z]{2})?\Z")
_API_VERSION = re.compile(r"v[1-9][0-9]*\.[0-9]+\Z")


def _text(value: Any, limit: int = 180) -> str:
    """Keep untrusted source text as inert, single-line bounded plain text."""
    if value is None:
        return ""
    value = "".join(c if c.isprintable() else " " for c in str(value))
    return " ".join(value.split())[:limit]


def normalize_recipient(recipient: str) -> str:
    """Return international-format digits; never infer a country code."""
    if not isinstance(recipient, str):
        raise ValueError("Recipient must be an international-format phone number")
    candidate = re.sub(r"[\s()\-]", "", recipient.strip())
    if candidate.startswith("+"):
        candidate = candidate[1:]
    if not re.fullmatch(r"[1-9][0-9]{9,14}", candidate):
        raise ValueError("Recipient requires 10–15 international-format digits")
    return candidate


def _public_link(value: str) -> str:
    """Accept a plain HTTP(S) link for display only; this function never fetches."""
    candidate = _text(value, 350)
    try:
        parsed = urlsplit(candidate)
    except ValueError:
        return ""
    if parsed.scheme not in {"https", "http"} or not parsed.hostname:
        return ""
    if parsed.username or parsed.password or any(c.isspace() for c in candidate):
        return ""
    return candidate


def build_digest(
    tenders: list[dict], company_name: str, report_base_url: str = ""
) -> str:
    return build_digest_batch(tenders, company_name, report_base_url)[0]


def build_digest_batch(
    tenders: list[dict], company_name: str, report_base_url: str = ""
) -> tuple[str, list[dict]]:
    """Build a small preview/digest from already ranked and checked tenders.

    The caller chooses which records are open and relevant. Unknown deadlines
    remain unknown, and fit/recommendation text is included only if supplied.
    Return the exact displayed records so callers never mark omitted tenders as
    sent. Call this once per send and use that same snapshot for outbox versions.
    """
    company = _text(company_name, 80) or "your company"
    if not tenders:
        return f"TenderWise for {company}: no new matching tenders in this digest.", []
    lines = [f"TenderWise for {company}: {len(tenders)} matching tender(s)."]
    shown_records = []
    report_link = _public_link(report_base_url)
    suffix = f"Full report: {report_link}" if report_link else "Review the original notices before bidding."
    available = MAX_DIGEST_CHARS - len(suffix) - 1
    for index, tender in enumerate(tenders[:5], 1):
        title = _text(tender.get("title"), 90) or "Untitled notice"
        buyer = _text(tender.get("buyer") or tender.get("organization"), 40)
        deadline = _text(tender.get("deadline") or tender.get("closing_date"), 35) or "not stated"
        line = f"{index}. {title}"
        if buyer:
            line += f" | Buyer: {buyer}"
        line += f" | Deadline: {deadline}"
        location = _text(tender.get("location"), 30)
        if location:
            line += f" | {location}"
        scope = _text(tender.get("scope"), 90)
        if scope:
            line += f" | Scope: {scope}"
        bond = tender.get("bid_bond")
        if isinstance(bond, (int, float)) and not isinstance(bond, bool):
            line += f" | Bond: EGP {bond:,.0f}"
        analysis = tender.get("analysis")
        recommendation = _text(
            tender.get("recommendation")
            or (analysis.get("recommendation") if isinstance(analysis, dict) else ""),
            45,
        )
        if recommendation:
            line += f" | Assessment: {recommendation}"
        if tender.get("fit_score") is not None:
            line += f" | Fit: {_text(tender['fit_score'], 4)}/100"
        requirements = tender.get("requirements") or []
        points = tender.get("missing_information") or tender.get("risks") or []
        if requirements:
            line += f" | Required: {_text(requirements[0], 60)}"
        if points:
            line += f" | Check: {_text(points[0], 65)}"
        if tender.get("review_status") not in {None, "approved"}:
            line += " | Draft: human review pending"
        if len("\n".join(lines + [line])) > available:
            break
        lines.append(line)
        shown_records.append(tender)
    shown = len(lines) - 1
    if shown < len(tenders):
        remaining = (
            f"{len(tenders) - shown} more in the full report."
            if report_link
            else f"{len(tenders) - shown} additional matching tender(s) omitted from this digest."
        )
        if len("\n".join(lines + [remaining])) <= available:
            lines.append(remaining)
    lines.append(suffix)
    return "\n".join(lines)[:MAX_DIGEST_CHARS], shown_records


def build_template_payload(
    recipient: str, template_name: str, language: str, digest_text: str
) -> dict:
    """Build one approved-template body parameter, with no dynamic instructions.

    The matching approved template must have exactly one body text parameter.
    A digest is made single-line because template text parameters reject newlines.
    """
    number = normalize_recipient(recipient)
    if not isinstance(template_name, str) or not _TEMPLATE_NAME.fullmatch(template_name):
        raise ValueError("Template name must use lowercase letters, digits and underscores")
    if not isinstance(language, str) or not _LANGUAGE.fullmatch(language):
        raise ValueError("Template language must use a code such as en or en_US")
    digest = _text(digest_text, MAX_DIGEST_CHARS)
    if not digest:
        raise ValueError("Digest text is required")
    return {
        "messaging_product": "whatsapp",
        "to": number,
        "type": "template",
        "template": {
            "name": template_name,
            "language": {"code": language},
            "components": [
                {"type": "body", "parameters": [{"type": "text", "text": digest}]}
            ],
        },
    }


def send_whatsapp(payload: dict, config: dict) -> dict:
    """Send once via Meta; return sanitized results without tokens/provider text.

    Required config: access_token, phone_number_id, api_version. The explicit
    Graph API version must be selected from the account's supported versions.
    This function deliberately does not retry ambiguous sends.
    """
    token = config.get("access_token")
    phone_id = config.get("phone_number_id")
    api_version = config.get("api_version")
    if (
        not isinstance(token, str)
        or not token.strip()
        or not isinstance(phone_id, str)
        or not re.fullmatch(r"[0-9]{1,30}", phone_id)
        or not isinstance(api_version, str)
        or not _API_VERSION.fullmatch(api_version)
    ):
        return {"ok": False, "message_id": None, "error": "invalid_configuration"}
    try:
        template = payload["template"]
        components = template["components"]
        if (
            payload.get("messaging_product") != "whatsapp"
            or payload.get("type") != "template"
            or len(components) != 1
            or components[0]["type"] != "body"
            or len(components[0]["parameters"]) != 1
            or components[0]["parameters"][0]["type"] != "text"
        ):
            raise ValueError("Unexpected template payload")
        safe_payload = build_template_payload(
            payload["to"],
            template["name"],
            template["language"]["code"],
            components[0]["parameters"][0]["text"],
        )
    except (KeyError, IndexError, TypeError, ValueError, AttributeError):
        return {"ok": False, "message_id": None, "error": "invalid_payload"}
    endpoint = f"https://graph.facebook.com/{api_version}/{phone_id}/messages"
    try:
        response = httpx.post(
            endpoint,
            headers={"Authorization": f"Bearer {token.strip()}"},
            json=safe_payload,
            timeout=20.0,
            follow_redirects=False,
        )
    except httpx.TimeoutException:
        return {"ok": False, "message_id": None, "error": "timeout_delivery_unknown"}
    except httpx.HTTPError:
        return {"ok": False, "message_id": None, "error": "network_delivery_unknown"}
    if not 200 <= response.status_code < 300:
        return {
            "ok": False,
            "message_id": None,
            "error": "provider_rejected" if response.status_code < 500 else "provider_delivery_unknown",
            "status_code": response.status_code,
        }
    try:
        message_id = response.json()["messages"][0]["id"]
        if not isinstance(message_id, str) or not message_id or len(message_id) > 500:
            raise ValueError("Unexpected message ID")
    except (ValueError, TypeError, KeyError, IndexError):
        return {"ok": False, "message_id": None, "error": "invalid_response_delivery_unknown"}
    return {"ok": True, "message_id": message_id, "error": None, "status": "accepted"}


def verify_webhook_signature(raw: bytes, signature: str, app_secret: str) -> bool:
    """Authenticate the exact raw webhook bytes before JSON parsing."""
    if (
        not isinstance(raw, bytes)
        or not isinstance(app_secret, str)
        or not app_secret
        or not isinstance(signature, str)
        or not re.fullmatch(r"sha256=[0-9a-f]{64}", signature)
    ):
        return False
    expected = "sha256=" + hmac.new(app_secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(signature, expected)
