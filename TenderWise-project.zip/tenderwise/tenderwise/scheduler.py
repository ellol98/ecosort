"""Daily single-process scheduling; persist settings in the application DB."""

from collections.abc import Callable
from zoneinfo import ZoneInfo

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger


def create_scheduler(
    run_job: Callable[[], object], hour: int, minute: int, timezone: str = "Africa/Cairo"
) -> BackgroundScheduler:
    """Return an unstarted daily scheduler using local time and DST rules.

    Run exactly one application worker with this scheduler enabled. Process-local
    max_instances cannot coordinate multiple workers or multiple deployments.
    """
    if not callable(run_job):
        raise ValueError("run_job must be callable")
    if isinstance(hour, bool) or not isinstance(hour, int) or not 0 <= hour <= 23:
        raise ValueError("Hour must be between 0 and 23")
    if isinstance(minute, bool) or not isinstance(minute, int) or not 0 <= minute <= 59:
        raise ValueError("Minute must be between 0 and 59")
    zone = ZoneInfo(timezone)
    scheduler = BackgroundScheduler(timezone=zone, daemon=True)
    scheduler.add_job(
        run_job,
        trigger=CronTrigger(hour=hour, minute=minute, timezone=zone),
        id="daily_tender_digest",
        replace_existing=True,
        coalesce=True,
        max_instances=1,
        misfire_grace_time=3600,
    )
    return scheduler
