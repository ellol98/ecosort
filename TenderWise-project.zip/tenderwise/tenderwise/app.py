import hashlib
import hmac
import html
import ipaddress
import json
import os
import re
import threading
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .analysis import analyze_document, match_company, status_for
from .config import ROOT, ai_config, data_dir, services, whatsapp_config
from .db import Store, utcnow
from .demo import demo_documents
from .ingestion import IngestedDocument, IngestionError, collect_source, extract_upload, fetch_document
from .messaging import build_digest_batch, build_template_payload, normalize_recipient, send_whatsapp, verify_webhook_signature
from .models import AppSettings, CompanyProfile, SendRequest, SourceInput, TenderReview, TextImport, URLImport
from .scheduler import create_scheduler


def current_settings(store):
    return AppSettings(**(store.get("settings") or {})).model_dump()


def current_company(store):
    return CompanyProfile(**(store.get("company") or {})).model_dump()


def public_tenders(store):
    rows = store.tenders()
    company = current_company(store)
    for row in rows:
        row["status"] = status_for(row)
        row.update(match_company(row, company))
    return rows


def document_identity(document):
    if document.metadata.get("document_scope") == "listing_excerpt" and document.source_url == document.metadata.get("source_feed_url"):
        reference = document.metadata.get("reference")
        # A feed URL alone is not a tender identity: never merge unrelated items.
        return document.source_url + "#item-" + hashlib.sha256(str(reference).encode()).hexdigest() if reference else ""
    return document.source_url or ""


def import_document(store, document, *, is_demo=False, source_name="Manual import", allow_ai=True):
    with store.ingestion_lock:
        return _import_document(store, document, is_demo=is_demo, source_name=source_name, allow_ai=allow_ai)


def _import_document(store, document, *, is_demo=False, source_name="Manual import", allow_ai=True):
    identity = document_identity(document)
    prior, same = store.duplicate(document.content_hash, identity)
    if same:
        prior["collected_at"] = utcnow()
        prior["source_metadata"] = dict(prior.get("source_metadata", {}), **document.metadata)
        store.save_tender(prior, document.text)
        return {"tender": prior, "duplicate": True, "updated": False}
    is_demo = is_demo or bool(re.search(r"fictional demonstration|not a real (?:tender|procurement)|demo reference:\s*DEMO-", document.text[:4000], re.I))
    config = ai_config() if allow_ai and not is_demo else {}
    # A configured provider failure is visible; never disguise it as successful AI.
    analysis = analyze_document(document, current_company(store), config)
    now = utcnow()
    record = dict(analysis, id=prior["id"] if prior else str(uuid.uuid4()), identity_key=identity, source_url=document.source_url or "", source_name=source_name, filename=document.filename, content_hash=document.content_hash, is_demo=is_demo, review_status="pending", reviewed_at=None, feedback="", created_at=prior["created_at"] if prior else now, updated_at=now, collected_at=now, source_metadata=document.metadata)
    if is_demo:
        record["analysis_mode"] = "demo"
    if document.metadata.get("detail_fetch_error") or document.metadata.get("document_scope") == "listing_excerpt":
        record["risks"].append("Only a listing excerpt was available. Obtain and review the full original notice.")
    store.save_tender(record, document.text)
    store.audit("tender_updated" if prior else "tender_imported", {"id": record["id"], "source": source_name, "analysis_mode": record["analysis_mode"], "demo": is_demo})
    return {"tender": record, "duplicate": False, "updated": bool(prior)}


def collect_one(store, source_id, ai_budget=10):
    source = store.source(source_id)
    if not source:
        raise HTTPException(404, "Source not found.")
    if not source.get("enabled"):
        raise ValueError("This source is disabled.")
    if not source.get("permission_confirmed"):
        raise ValueError("Confirm permission to collect from this source before running it.")
    counts = {"imported": 0, "updated": 0, "duplicates": 0, "ai_calls": 0, "errors": []}
    source["last_checked"] = utcnow()
    try:
        config = dict(source.get("config", {}), type=source["type"], url=source["url"], permission_confirmed=True)
        documents = collect_source(config)
        for document in documents:
            try:
                prior, same = store.duplicate(document.content_hash, document_identity(document))
                document.metadata["source_id"] = source_id
                use_ai = not same and services()["ai_configured"]
                if use_ai and counts["ai_calls"] >= ai_budget:
                    counts["errors"].append("AI call budget reached; remaining documents deferred until the next run.")
                    break
                if use_ai:
                    counts["ai_calls"] += 1
                result = import_document(store, document, source_name=source["name"])
                counts["duplicates" if result["duplicate"] else "updated" if result["updated"] else "imported"] += 1
            except ValueError as exc:
                counts["errors"].append(str(exc)[:400])
        source["status"] = "error" if counts["errors"] else "ok"
        source["last_error"] = "; ".join(counts["errors"])[:1000] or None
        source["last_success"] = utcnow() if not counts["errors"] else source.get("last_success")
        source["last_result"] = counts
    except (IngestionError, ValueError) as exc:
        source["status"] = "error"
        source["last_error"] = str(exc)[:1000]
        counts["errors"].append(source["last_error"])
    store.save_source(source)
    store.audit("source_checked", {"source_id": source_id, "status": source["status"], "result": counts})
    return dict(counts, source_id=source_id, status=source["status"])


def digest_candidates(store, live=False):
    rows = [r for r in public_tenders(store) if r["status"] == "open" and r["review_status"] != "rejected" and r.get("recommendation") != "Unsuitable under current profile"]
    if live:
        now = datetime.now(timezone.utc)
        settings = current_settings(store)
        checked = []
        for row in rows:
            if row.get("is_demo"):
                continue
            source_id = row.get("source_metadata", {}).get("source_id")
            source = store.source(source_id) if source_id else None
            if source_id and (not source or source.get("status") != "ok"):
                continue
            try:
                if settings["require_human_review"] and row.get("review_status") != "approved":
                    continue
                freshness = row.get("reviewed_at") if settings["require_human_review"] else row.get("collected_at")
                reviewed = datetime.fromisoformat(freshness or "")
                if reviewed.tzinfo is None or now - reviewed > timedelta(hours=24) or reviewed > now + timedelta(minutes=5):
                    continue
            except (ValueError, TypeError):
                continue
            checked.append(row)
        rows = checked
        recipient = current_settings(store)["whatsapp_recipient"]
        sent = set()
        for message in store.all_outbox():
            if message.get("live") and message.get("recipient") == recipient and message.get("status") in {"pending", "accepted", "sent", "delivered", "read", "delivery_unknown"}:
                sent.update(message.get("versions", []))
        rows = [r for r in rows if r["id"] + ":" + r["content_hash"] not in sent]
    return sorted(rows, key=lambda r: (-r.get("fit_score", 0), r.get("deadline", "9999")))


def compose_digest(store, rows):
    # Reports require dashboard authentication; never embed an admin token in links.
    text, displayed = build_digest_batch(rows, current_company(store)["name"], "")
    if any(r.get("is_demo") for r in displayed):
        text = "DEMO PREVIEW — contains fictional tenders.\n" + text
    return {"text": text[:900], "tender_ids": [r["id"] for r in displayed], "count": len(displayed), "available_count": len(rows)}, displayed


def digest_preview(store, live=False):
    return compose_digest(store, digest_candidates(store, live))[0]


def deliver_digest(store, live=False, retry_failed=False):
    settings = current_settings(store)
    if live:
        if settings["whatsapp_test_mode"] or not settings["whatsapp_enabled"]:
            raise ValueError("Live delivery is disabled. Review WhatsApp settings and turn off test mode first.")
        if not settings["whatsapp_opt_in"]:
            raise ValueError("Recipient consent must be confirmed before sending.")
        if not settings["whatsapp_template_approved"]:
            raise ValueError("Confirm that Meta approved the matching one-parameter message template.")
        if not services()["whatsapp_configured"]:
            raise ValueError("WhatsApp sender credentials and Graph API version are not configured in .env.")
        recipient = normalize_recipient(settings["whatsapp_recipient"])
    else:
        recipient = settings["whatsapp_recipient"].strip()
    candidates = digest_candidates(store, live)
    if live and not candidates:
        return {"status": "skipped", "detail": "No unsent real open tenders meet the configured review and freshness requirements."}
    preview, candidates = compose_digest(store, candidates)
    versions = [r["id"] + ":" + r["content_hash"] for r in candidates]
    key = hashlib.sha256(json.dumps([live, recipient, versions, settings["whatsapp_template_name"], settings["whatsapp_language"]], sort_keys=True).encode()).hexdigest()
    record = {"id": str(uuid.uuid4()), "status": "pending" if live else "dry_run", "digest": preview["text"], "created_at": utcnow(), "recipient": recipient, "live": live, "tender_ids": preview["tender_ids"], "versions": versions, "error": None, "message_id": None}
    # Validate the entire provider request before reserving the outbox entry.
    payload = build_template_payload(recipient, settings["whatsapp_template_name"], settings["whatsapp_language"], preview["text"]) if live else None
    record, created = store.reserve_outbox(record, key, retry_failed=live and retry_failed)
    if not created:
        return dict(record, duplicate=True)
    if live:
        result = send_whatsapp(payload, whatsapp_config())
        record["status"] = "accepted" if result["ok"] else "delivery_unknown" if "delivery_unknown" in (result.get("error") or "") else "failed"
        record["message_id"] = result.get("message_id")
        record["error"] = result.get("error")
        store.save_outbox(record)
    store.audit("digest_send" if live else "digest_preview_saved", {"outbox_id": record["id"], "status": record["status"], "count": len(versions)})
    return record


def run_job(app):
    if not app.state.job_lock.acquire(blocking=False):
        return {"status": "busy", "detail": "A collection job is already running."}
    store = app.state.store
    try:
        budget = max(0, min(100, int(os.getenv("MAX_AI_CALLS_PER_RUN", "10"))))
        results = []
        for source in store.sources():
            if source.get("enabled") and source.get("permission_confirmed"):
                result = collect_one(store, source["id"], budget)
                results.append(result)
                budget -= result["ai_calls"]
        settings = current_settings(store)
        delivery = {"status": "disabled"}
        if settings["whatsapp_enabled"]:
            try:
                if settings["whatsapp_test_mode"]:
                    delivery = deliver_digest(store, live=False)
                else:
                    batches = []
                    cap = max(1, min(10, int(os.getenv("MAX_WHATSAPP_BATCHES_PER_RUN", "3"))))
                    for _ in range(cap):
                        batch = deliver_digest(store, live=True)
                        batches.append(batch)
                        if batch.get("status") != "accepted" or batch.get("duplicate"):
                            break
                    delivery = {"status": batches[-1]["status"], "messages_accepted": sum(b.get("status") == "accepted" for b in batches), "batches": batches}
            except ValueError as exc:
                delivery = {"status": "blocked", "detail": str(exc)}
        result = {"status": "completed", "finished_at": utcnow(), "sources": results, "delivery": delivery}
        store.set("last_job", result)
        return result
    finally:
        app.state.job_lock.release()


def configure_scheduler(app):
    old = getattr(app.state, "scheduler", None)
    if old and old.running:
        old.shutdown(wait=False)
    settings = current_settings(app.state.store)
    app.state.scheduler = None
    if settings["schedule_enabled"]:
        scheduler = create_scheduler(lambda: run_job(app), settings["digest_hour"], settings["digest_minute"], settings["timezone"])
        scheduler.start()
        app.state.scheduler = scheduler


def create_app(folder=None):
    @asynccontextmanager
    async def lifespan(application):
        configure_scheduler(application)
        yield
        scheduler = application.state.scheduler
        if scheduler and scheduler.running:
            scheduler.shutdown(wait=False)

    application = FastAPI(title="TenderWise", version=__version__, lifespan=lifespan, docs_url=None, redoc_url=None)
    application.state.store = Store(Path(folder) if folder else data_dir())
    application.state.job_lock = threading.Lock()
    application.state.scheduler = None
    application.mount("/static", StaticFiles(directory=ROOT / "tenderwise" / "static"), name="static")

    @application.middleware("http")
    async def protect_api(request, call_next):
        if request.url.path.startswith("/api"):
            token = os.getenv("ADMIN_TOKEN", "")
            if token:
                provided = request.headers.get("authorization", "")
                if not hmac.compare_digest(provided, "Bearer " + token):
                    return JSONResponse({"detail": "Enter your ADMIN_TOKEN using the dashboard connection settings."}, status_code=401)
            else:
                hostname = request.url.hostname
                client = request.client.host if request.client else ""
                try:
                    loopback = ipaddress.ip_address(client).is_loopback
                except ValueError:
                    loopback = client == "testclient"
                if not loopback or hostname not in {"127.0.0.1", "localhost", "::1", "testserver"}:
                    return JSONResponse({"detail": "Set ADMIN_TOKEN before accessing TenderWise from another machine."}, status_code=403)
            origin = request.headers.get("origin")
            if request.method not in {"GET", "HEAD", "OPTIONS"} and origin and urlsplit(origin).netloc != request.headers.get("host"):
                return JSONResponse({"detail": "Cross-origin writes are not allowed."}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if request.url.path.startswith("/api"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @application.exception_handler(ValueError)
    async def invalid_request(request, exc):
        return JSONResponse({"detail": str(exc)[:1000]}, status_code=422)

    @application.get("/", include_in_schema=False)
    def dashboard():
        return FileResponse(ROOT / "tenderwise" / "static" / "index.html")

    @application.get("/health")
    def health():
        return {"status": "ok", "version": __version__}

    @application.get("/docs", response_class=HTMLResponse, include_in_schema=False)
    def api_documentation():
        # Self-contained documentation keeps the offline UI's strict CSP intact.
        paths = application.openapi()["paths"]
        items = "".join("<li><code>" + html.escape(method.upper() + " " + path) + "</code> — " + html.escape(details.get("summary", "")) + "</li>" for path, operations in paths.items() for method, details in operations.items() if isinstance(details, dict))
        return "<!doctype html><html lang='en'><meta charset='utf-8'><title>TenderWise API</title><link rel='stylesheet' href='/static/styles.css'><main><h1>TenderWise API</h1><p>Protected endpoints require <code>Authorization: Bearer &lt;ADMIN_TOKEN&gt;</code> when configured. Without a token only loopback clients are allowed.</p><p><a href='/'>Open dashboard</a> · <a href='/openapi.json'>Download OpenAPI schema</a></p><ul style='line-height:2.2'>" + items + "</ul><p>Schema definitions describe request and response fields. See docs/API.md in the project for examples.</p></main></html>"

    @application.get("/api/bootstrap")
    def bootstrap():
        store = application.state.store
        tenders = public_tenders(store)
        return {"company": current_company(store), "tenders": tenders, "sources": store.sources(), "settings": current_settings(store), "services": services(), "outbox": store.outbox(), "last_job": store.get("last_job"), "stats": {"total": len(tenders), "open": sum(t["status"] == "open" for t in tenders), "needs_review": sum(t["review_status"] == "pending" for t in tenders), "sources_connected": sum(s.get("status") == "ok" for s in store.sources()), "demo": sum(bool(t.get("is_demo")) for t in tenders)}}

    @application.put("/api/company")
    def save_company(profile: CompanyProfile):
        store = application.state.store
        store.set("company", profile.model_dump())
        # A changed company profile invalidates previous bid-fit approvals.
        for tender in store.tenders(True):
            raw = tender.pop("raw_text")
            tender.update(review_status="pending", reviewed_at=None)
            store.save_tender(tender, raw)
        store.audit("company_updated", {"name": profile.name})
        return profile.model_dump()

    @application.post("/api/import/text")
    def import_text(body: TextImport):
        doc = extract_upload(body.text.encode("utf-8"), "pasted-tender.txt")
        doc.title = body.title
        if body.source_url:
            parsed = urlsplit(body.source_url)
            if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                raise ValueError("Source provenance must be an HTTPS URL without credentials.")
            doc.source_url = body.source_url
        return import_document(application.state.store, doc)

    @application.post("/api/import/url")
    def import_url(body: URLImport):
        return import_document(application.state.store, fetch_document(body.url), source_name="URL import")

    @application.post("/api/import")
    async def import_file(file: UploadFile):
        data = await file.read(10 * 1024 * 1024 + 1)
        if len(data) > 10 * 1024 * 1024:
            raise HTTPException(413, "Upload must be at most 10 MB.")
        document = extract_upload(data, file.filename or "tender.txt")
        # Analysis is blocking network/CPU work; keep it off the event loop.
        from starlette.concurrency import run_in_threadpool
        result = await run_in_threadpool(import_document, application.state.store, document)
        folder = application.state.store.path.parent / "documents"
        folder.mkdir(exist_ok=True)
        safe_suffix = ".pdf" if data.startswith(b"%PDF") else ".txt"
        (folder / (document.content_hash + safe_suffix)).write_bytes(data)
        return result

    @application.post("/api/demo/seed")
    def seed_demo():
        store = application.state.store
        existing = [t for t in store.tenders() if t.get("is_demo")]
        if existing:
            return {"created": 0, "detail": "Fictional demo records are already loaded."}
        for filename, text in demo_documents():
            import_document(store, extract_upload(text.encode(), filename), is_demo=True, source_name="Fictional demonstration", allow_ai=False)
        return {"created": 6, "detail": "Six fictional records created. These can never be sent as live opportunities."}

    @application.patch("/api/tenders/{tender_id}")
    def review(tender_id: str, body: TenderReview):
        store = application.state.store
        record = store.tender(tender_id, True)
        if not record:
            raise HTTPException(404, "Tender not found.")
        raw = record.pop("raw_text")
        updates = body.model_dump(exclude_none=True)
        record.update(updates)
        if body.review_status is not None:
            record["reviewed_at"] = utcnow() if body.review_status == "approved" else None
        store.save_tender(record, raw)
        store.audit("tender_reviewed", {"id": tender_id, **updates})
        return record

    @application.post("/api/tenders/{tender_id}/analyze")
    def reanalyze(tender_id: str):
        store = application.state.store
        record = store.tender(tender_id, True)
        if not record:
            raise HTTPException(404, "Tender not found.")
        text = record.pop("raw_text")
        doc = IngestedDocument(record["title"], text, record["source_url"], record.get("filename", "tender.txt"), record["content_hash"], record.get("source_metadata", {}))
        record.update(analyze_document(doc, current_company(store), {} if record["is_demo"] else ai_config()))
        record.update(updated_at=utcnow(), review_status="pending", reviewed_at=None)
        if record["is_demo"]:
            record["analysis_mode"] = "demo"
        store.save_tender(record, text)
        return record

    @application.get("/api/tenders/{tender_id}/report", response_class=HTMLResponse)
    def report(tender_id: str):
        tender = next((t for t in public_tenders(application.state.store) if t["id"] == tender_id), None)
        if not tender:
            raise HTTPException(404, "Tender not found.")
        return render_report(tender, current_company(application.state.store))

    @application.get("/api/tenders/{tender_id}/document")
    def original_document(tender_id: str):
        record = application.state.store.tender(tender_id, True)
        if not record:
            raise HTTPException(404, "Tender not found.")
        for suffix in (".pdf", ".txt"):
            target = application.state.store.path.parent / "documents" / (record["content_hash"] + suffix)
            if target.is_file():
                return FileResponse(target, filename="tender-original" + suffix)
        return PlainTextResponse(record["raw_text"], headers={"Content-Disposition": 'attachment; filename="tender-extracted.txt"'})

    @application.get("/api/export")
    def export():
        return JSONResponse(application.state.store.export(), headers={"Content-Disposition": 'attachment; filename="tenderwise-backup.json"'})

    @application.post("/api/sources")
    def add_source(body: SourceInput):
        parsed = urlsplit(body.url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Sources must use HTTPS URLs without embedded credentials.")
        source = dict(body.model_dump(), id=str(uuid.uuid4()), status="not_checked", last_checked=None, last_error=None)
        application.state.store.save_source(source)
        return source

    @application.delete("/api/sources/{source_id}")
    def delete_source(source_id: str):
        if not application.state.store.delete_source(source_id):
            raise HTTPException(404, "Source not found.")
        return {"deleted": True}

    @application.patch("/api/sources/{source_id}")
    def toggle_source(source_id: str, body: dict):
        source = application.state.store.source(source_id)
        if not source:
            raise HTTPException(404, "Source not found.")
        if set(body) != {"enabled"} or not isinstance(body["enabled"], bool):
            raise ValueError("Supply only an enabled boolean.")
        source["enabled"] = body["enabled"]
        application.state.store.save_source(source)
        return source

    @application.post("/api/sources/{source_id}/collect")
    def collect(source_id: str):
        if not application.state.job_lock.acquire(blocking=False):
            raise HTTPException(409, "A collection job is already running.")
        try:
            return collect_one(application.state.store, source_id, max(0, min(100, int(os.getenv("MAX_AI_CALLS_PER_RUN", "10")))))
        finally:
            application.state.job_lock.release()

    @application.put("/api/settings")
    def save_settings(body: AppSettings):
        store = application.state.store
        prior = current_settings(store)
        value = body.model_dump()
        if value["whatsapp_recipient"]:
            value["whatsapp_recipient"] = normalize_recipient(value["whatsapp_recipient"])
        if value["whatsapp_enabled"] and not value["whatsapp_test_mode"]:
            if not all((value["whatsapp_opt_in"], value["whatsapp_template_approved"], value["whatsapp_template_name"], value["whatsapp_recipient"])):
                raise ValueError("Live mode requires recipient, consent and a confirmed approved template.")
        store.set("settings", value)
        if value["whatsapp_opt_in"] and (not prior["whatsapp_opt_in"] or prior["whatsapp_recipient"] != value["whatsapp_recipient"]):
            store.audit("recipient_consent_confirmed", {"recipient": value["whatsapp_recipient"], "confirmed_at": utcnow()})
        configure_scheduler(application)
        return value

    @application.get("/api/digest")
    def digest(live: bool = False):
        return digest_preview(application.state.store, live)

    @application.post("/api/digest/send")
    def send(body: SendRequest):
        return deliver_digest(application.state.store, body.live, body.retry_failed)

    @application.post("/api/jobs/run")
    def job():
        return run_job(application)

    @application.get("/webhooks/whatsapp")
    def verify_webhook(request: Request):
        expected = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
        provided = request.query_params.get("hub.verify_token", "")
        if not expected or request.query_params.get("hub.mode") != "subscribe" or not hmac.compare_digest(provided, expected):
            raise HTTPException(403, "Webhook verification failed.")
        return PlainTextResponse(request.query_params.get("hub.challenge", ""))

    @application.post("/webhooks/whatsapp")
    async def delivery_webhook(request: Request):
        buffer = bytearray()
        async for chunk in request.stream():
            buffer.extend(chunk)
            if len(buffer) > 1_000_000:
                raise HTTPException(413, "Webhook too large.")
        raw = bytes(buffer)
        if not verify_webhook_signature(raw, request.headers.get("x-hub-signature-256", ""), os.getenv("WHATSAPP_APP_SECRET", "")):
            raise HTTPException(403, "Webhook signature failed.")
        try:
            payload = json.loads(raw)
            updates = [s for entry in payload.get("entry", []) for change in entry.get("changes", []) for s in change.get("value", {}).get("statuses", [])]
        except (ValueError, TypeError, AttributeError):
            raise HTTPException(400, "Invalid webhook JSON.")
        store = application.state.store
        rank = {"pending": 0, "accepted": 1, "sent": 2, "delivered": 3, "read": 4}
        for update in updates:
            if not isinstance(update, dict):
                continue
            if update.get("status") not in {"sent", "delivered", "read", "failed"}:
                continue
            for row in store.all_outbox():
                if row.get("message_id") == update.get("id") and row.get("message_id"):
                    new = update["status"]
                    if rank.get(new, -1) >= rank.get(row["status"], 0) or new == "failed" and row["status"] not in {"delivered", "read"}:
                        row.update(status=new, webhook_at=utcnow())
                        store.save_outbox(row)
        return {"received": True}

    return application


def render_report(tender, company):
    esc = lambda value: html.escape(str(value if value is not None else "Unknown"))
    money = lambda value: "Unknown" if value is None else f"EGP {value:,.2f}"
    fields = [("Client", tender.get("buyer")), ("Location", tender.get("location")), ("Submission date", tender.get("deadline")), ("Status", tender.get("status")), ("Contract estimate", money(tender.get("project_value"))), ("Bid security", money(tender.get("bid_bond"))), ("Document fee", money(tender.get("document_fee"))), ("Recommendation", tender.get("recommendation")), ("Heuristic fit / 100", tender.get("fit_score")), ("Eligibility", tender.get("eligibility")), ("Analysis method", tender.get("analysis_mode"))]
    details = "".join(f"<dt>{esc(k)}</dt><dd dir='auto'>{esc(v)}</dd>" for k, v in fields)
    sections = "".join(f"<h2>{esc(title)}</h2><ul>" + "".join(f"<li dir='auto'>{esc(v)}</li>" for v in tender.get(field, [])) + "</ul>" for title, field in (("Company fit", "fit_reasons"), ("Requirements", "requirements"), ("Risks", "risks"), ("Missing information and next steps", "missing_information")))
    evidence = "".join(f"<li><strong>{esc(e['field'])}</strong> — page {esc(e.get('page') or 'not numbered')}<blockquote dir='auto'>{esc(e['quote'])}</blockquote></li>" for e in tender.get("evidence", []))
    banner = "<p class='banner'>FICTIONAL DEMONSTRATION — not a real tender</p>" if tender.get("is_demo") else ""
    source = esc(tender.get("source_url") or tender.get("source_name"))
    return f"""<!doctype html><html lang='en'><meta charset='utf-8'><title>{esc(tender['title'])} — TenderWise</title><style>body{{font:15px/1.65 system-ui,sans-serif;color:#162f38;max-width:850px;margin:50px auto;padding:0 28px}}h1{{line-height:1.2}}h2{{font-size:19px;border-top:1px solid #ddd;padding-top:20px}}dl{{display:grid;grid-template-columns:180px 1fr;gap:8px}}dt{{font-weight:650}}dd{{margin:0}}blockquote{{margin:8px 0;color:#445}}.banner{{padding:12px;background:#fff1d9}}small{{color:#59696d}}@media print{{body{{margin:0}}h2{{break-after:avoid}}li{{break-inside:avoid}}}}</style><body>{banner}<small>TENDERWISE / TENDER REVIEW • {esc(company['name'])}</small><h1 dir='auto'>{esc(tender['title'])}</h1><p dir='auto'>{esc(tender.get('scope'))}</p><dl>{details}</dl>{sections}<h2>Document evidence</h2><ol>{evidence}</ol><h2>Provenance</h2><p>Source: {source}<br>Retrieved: {esc(tender.get('collected_at'))}<br>SHA-256: {esc(tender.get('content_hash'))}</p><small>Draft decision support. Fit is a transparent heuristic, not a probability of winning. This report does not establish full eligibility or profitability. Verify all original documents, amendments and exact submission time. Print with your browser to save as PDF.</small></body></html>"""


app = create_app()
