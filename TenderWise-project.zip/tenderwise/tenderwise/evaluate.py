"""Small synthetic extraction sanity check; explicitly NOT an AI benchmark."""
import json
from pathlib import Path

from .analysis import rule_extract, validate_extraction


CASES = [
    {"name": "English labeled notice", "text": "Buyer: Demo Client\nSubmission deadline: 2027-12-15\nBid bond: EGP 25,000", "expected": {"buyer": "Demo Client", "deadline": "2027-12-15", "bid_bond": 25000}},
    {"name": "Arabic labeled notice", "text": "الجهة: جهة تجريبية\nآخر موعد للتقديم: ٢٠٢٧-١٢-١٥\nالتأمين الابتدائي: ٢٥٬٠٠٠ جنيه مصري", "expected": {"buyer": "جهة تجريبية", "deadline": "2027-12-15", "bid_bond": 25000}},
    {"name": "Opening date is not a deadline", "text": "Opening session: 2027-12-15\nBid bond: Not stated", "expected": {"deadline": None, "bid_bond": None}},
    {"name": "Unknown currency remains unknown", "text": "Bid bond: USD 5,000", "expected": {"bid_bond": None}},
    {"name": "Conflicting dates need review", "text": "Submission deadline: 2027-12-15\nSubmission deadline: 2027-12-16", "expected": {"deadline": None}},
    {"name": "Multiplier is not a literal amount", "text": "Estimated contract value: EGP 2.5 million", "expected": {"project_value": None}},
]


def evaluate(cases=CASES):
    total, correct, rows = 0, 0, []
    for case in cases:
        result = validate_extraction(rule_extract(case["text"]), case["text"])
        checks = {field: result.get(field) == expected for field, expected in case["expected"].items()}
        total += len(checks)
        correct += sum(checks.values())
        rows.append({"name": case["name"], "checks": checks, "passed": all(checks.values())})
    return {"dataset": "synthetic functionality fixtures; not real tenders or an AI benchmark", "cases": len(cases), "field_checks": total, "correct": correct, "all_passed": correct == total, "results": rows}


if __name__ == "__main__":
    result = evaluate()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["all_passed"] else 1)
