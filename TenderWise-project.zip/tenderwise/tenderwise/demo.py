from datetime import datetime, timedelta
from zoneinfo import ZoneInfo


def demo_documents():
    today = datetime.now(ZoneInfo("Africa/Cairo")).date()
    rows = [
        ("School campus renovation", "Demo Education Client", "Cairo", "Renovation", 14, "EGP 4,800,000", "EGP 96,000", "EGP 1,500", "Civil repairs, finishes, plumbing and electrical upgrades across a fictional school campus.", "Contractor registration; Similar completed projects; Site visit required; BOQ review"),
        ("Water network rehabilitation", "Demo Utilities Client", "Giza", "Infrastructure", 8, "EGP 12,000,000", "EGP 240,000", "EGP 2,000", "Replacement of water distribution pipes and reinstatement of excavated roads.", "Infrastructure experience; Equipment availability; Environmental plan"),
        ("إنشاء مبنى إداري وتجهيز الموقع", "جهة تجريبية خيالية", "Alexandria", "Buildings", 21, "EGP 8,500,000", "EGP 170,000", "EGP 1,800", "إنشاء مبنى إداري وأعمال الخرسانة والتشطيبات والكهرباء والصحي.", "تصنيف مقاول مناسب; سابقة أعمال مماثلة; معاينة الموقع; مراجعة كراسة الشروط"),
        ("Hospital HVAC maintenance", "Demo Healthcare Client", "Cairo", "MEP", 4, "Not stated", "EGP 40,000", "EGP 800", "Preventive maintenance and replacement of selected HVAC components.", "Specialist maintenance team; Similar references; Equipment schedule"),
        ("Road resurfacing package", "Demo Roads Client", "Suez", "Infrastructure", -3, "EGP 6,000,000", "EGP 120,000", "EGP 1,200", "Asphalt milling and resurfacing of a fictional local road segment.", "Road works experience; Traffic management plan"),
        ("Community building structural repairs", "Demo Community Client", "Dakahlia", "Renovation", None, "Not stated", "Not stated", "Not stated", "Structural rehabilitation; quantities and submission deadline need clarification.", "Structural engineering review; Full bidding documents required"),
    ]
    result = []
    for index, (title, buyer, location, category, days, value, bond, fee, scope, requirements) in enumerate(rows):
        deadline = (today + timedelta(days=days)).isoformat() if days is not None else "Not stated"
        text = f"""FICTIONAL DEMONSTRATION. Not a real procurement opportunity.
Demo reference: DEMO-{index+1:03d}
Title: {title}
Buyer: {buyer}
Location: {location}
Category: {category}
Submission deadline: {deadline}
Estimated contract value: {value}
Bid bond: {bond}
Document fee: {fee}
Scope: {scope}
Requirements: {requirements}
All content and amounts in this document are invented for software demonstration.
"""
        result.append((f"demo-{index+1:03d}.txt", text))
    return result
