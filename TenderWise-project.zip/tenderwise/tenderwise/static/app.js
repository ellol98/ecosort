/* TenderWise. No third-party scripts; all tender content is rendered as text. */
'use strict';
const S = { data: null, page: 'overview', search: '', filter: 'all', tab: 'all', token: sessionStorage.getItem('tenderwise-token') || '', busy: false };
const $ = (q, root = document) => root.querySelector(q);
const paths = {
  grid: ['M3 3h7v7H3z','M14 3h7v7h-7z','M3 14h7v7H3z','M14 14h7v7h-7z'],
  file: ['M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z','M14 2v6h6','M8 13h8','M8 17h6'],
  layers: ['m12 3 10 5-10 5L2 8z','m2 12 10 5 10-5','m2 16 10 5 10-5'],
  building: ['M4 21V3h12v18','M16 9h4v12','M8 7h4','M8 11h4','M8 15h4','M10 21v-3','M2 21h20'],
  clock: ['M12 8v4l3 2'],
  settings: ['M12 3v3','M12 18v3','M3 12h3','M18 12h3','m5.6 5.6 2.1 2.1','m16.3 16.3 2.1 2.1','m5.6 18.4 2.1-2.1','m16.3 7.7 2.1-2.1'],
  arrow: ['M5 12h14','m13 6 6 6-6 6'],
  plus: ['M12 5v14','M5 12h14'],
  search: ['M21 21l-5-5'],
  refresh: ['M20 7v5h-5','M4 17v-5h5','M6.1 6a8 8 0 0 1 13.3 3','M17.9 18A8 8 0 0 1 4.6 15'],
  upload: ['M12 16V3','m7 8 5-5 5 5','M3 15v5a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-5'],
  download: ['M12 3v13','m7 11 5 5 5-5','M3 17v4h18v-4'],
  location: ['M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z'],
  calendar: ['M4 5h16v16H4z','M16 3v4','M8 3v4','M4 11h16'],
  check: ['m5 12 4 4L19 6'],
  close: ['m6 6 12 12','M18 6 6 18'],
  info: ['M12 11v6','M12 7h.01'],
  chevron: ['m9 5 7 7-7 7'],
  help: ['M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2-3 4','M12 18h.01'],
  chat: ['M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-3 3V11.5A8.5 8.5 0 0 1 9.5 3h3a8.5 8.5 0 0 1 8.5 8.5Z','M6 11h10','M6 15h6'],
  shield: ['m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6z','m8 12 3 3 5-6'],
  external: ['M14 3h7v7','M10 14 21 3','M21 14v7H3V3h7'],
  trash: ['M3 6h18','M9 6V3h6v3','M5 6l1 15h12l1-15','M10 10v7','M14 10v7'],
  bookmark: ['M6 3h12v19l-6-4-6 4z'],
  spark: ['m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z']
};
function icon(name) {
  const n = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  Object.entries({viewBox:'0 0 24 24',fill:'none',stroke:'currentColor','stroke-width':'1.5','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true'}).forEach(([k,v]) => n.setAttribute(k,v));
  if (['clock','search','info','help'].includes(name)) { const c = document.createElementNS(n.namespaceURI,'circle'); c.setAttribute('cx',name==='search'?'10.5':'12'); c.setAttribute('cy',name==='search'?'10.5':'12'); c.setAttribute('r',name==='search'?'7.5':'9'); n.append(c); }
  if (name === 'location') { const c = document.createElementNS(n.namespaceURI,'circle'); c.setAttribute('cx','12'); c.setAttribute('cy','10'); c.setAttribute('r','2.5'); n.append(c); }
  (paths[name] || paths.file).forEach(d => { const p = document.createElementNS(n.namespaceURI,'path'); p.setAttribute('d',d); n.append(p); }); return n;
}
function el(tag, attrs = {}, ...children) {
  const n = document.createElement(tag);
  for (const [k,v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) n.addEventListener(k.slice(2).toLowerCase(),v);
    else if (k === 'class') n.className = v;
    else if (k === 'value') n.value = v;
    else if (k === 'checked') n.checked = Boolean(v);
    else if (k === 'disabled') n.disabled = Boolean(v);
    else n.setAttribute(k,v === true ? '' : String(v));
  }
  children.flat(Infinity).filter(c => c != null && c !== false).forEach(c => n.append(c instanceof Node ? c : document.createTextNode(String(c))));
  return n;
}
const text = v => v == null || v === '' ? 'Not provided' : String(v);
const list = v => Array.isArray(v) ? v : (v ? [String(v)] : []);
const titleCase = v => String(v || '').replace(/[_-]/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
const tag = (label, color = '') => el('span',{class:`tag ${color}`},label);
const button = (label, name, action, cls = '') => el('button',{type:'button',class:`button ${cls}`,onclick:action}, name ? icon(name) : null,label);
function date(v, withTime = false) {
  if (!v) return 'Not provided'; const d = new Date(v); if (Number.isNaN(d.getTime())) return String(v);
  return new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'numeric',...(withTime ? {hour:'2-digit',minute:'2-digit',timeZone:'Africa/Cairo'} : {})}).format(d);
}
function money(v) { if (v == null || v === '') return 'Not stated'; const n = Number(v); return Number.isFinite(n) ? `EGP ${n.toLocaleString('en-GB',{maximumFractionDigits:0})}` : String(v); }
function safeLink(v) { try { const u = new URL(v); return ['http:','https:'].includes(u.protocol) && !u.username && !u.password ? u.href : null; } catch { return null; } }
function field(label, control, hint = '', full = false) { return el('label',{class:`field ${full?'full':''}`},el('span',{},label),control,hint ? el('small',{},hint) : null); }
function input(name, value = '', type = 'text', attrs = {}) { return el('input',{name,type,value:value == null ? '' : value,...attrs}); }
function select(name, value, choices) { const n = el('select',{name},choices.map(([v,label])=>el('option',{value:v},label))); n.value = value; return n; }
function checkbox(name, checked, label) { return el('label',{class:'checkbox-field'},input(name,'on','checkbox',{checked}),el('span',{},label)); }
function note(copy, warning = false) { return el('div',{class:`info-note ${warning?'warning':''}`},copy); }
function toast(message, error = false) { const n = el('div',{class:`toast ${error?'error':''}`,role:error?'alert':'status'},String(message)); $('#toast-region').append(n); setTimeout(()=>n.remove(),error ? 11000 : 5500); }
async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (S.token) headers.set('Authorization',`Bearer ${S.token}`);
  if (options.body && !(options.body instanceof FormData)) { headers.set('Content-Type','application/json'); options.body = JSON.stringify(options.body); }
  const r = await fetch(path,{...options,headers});
  if (!r.ok) {
    let message = `Request failed (${r.status})`;
    try { const b = await r.json(); const d = b.detail || b.error || b.message; message = typeof d === 'string' ? d : (Array.isArray(d) ? d.map(x=>`${(x.loc||[]).slice(1).join('.')}: ${x.msg}`).join('; ') : JSON.stringify(d || message)); } catch { /* Keep HTTP status if response isn't JSON. */ }
    if (r.status === 401 || r.status === 403) $('#connection-dot').className = 'status-dot error';
    throw new Error(message);
  }
  if (options.raw) return r;
  return r.status === 204 ? null : r.json();
}
async function busy(btn, action) {
  if (btn?.disabled) return;
  const original = btn ? [...btn.childNodes] : null;
  if (btn) { btn.disabled = true; btn.replaceChildren(el('span',{class:'spinner'}),'Working…'); }
  try { return await action(); } catch(e) { toast(e.message || String(e),true); }
  finally { if (btn) { btn.replaceChildren(...original); btn.disabled = false; } }
}
async function reload(render = true) {
  S.data = await api('/api/bootstrap');
  ['tenders','sources','outbox'].forEach(k => { if (!Array.isArray(S.data[k])) S.data[k] = []; });
  S.data.company ||= {}; S.data.settings ||= {}; S.data.services ||= {};
  $('#connection-dot').className = 'status-dot'; $('#connection-label').textContent = 'Workspace connected';
  const initials = (S.data.company.name || 'Construction workspace').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase();
  $('#profile-shortcut').textContent = initials;
  renderNav(); if (render) renderPage();
  return S.data;
}
const pages = {overview:['Overview','grid'],tenders:['Tender inbox','file'],sources:['Sources','layers'],company:['Company profile','building'],automation:['Automation','clock'],settings:['Setup & guide','settings']};
function navigate(page) { S.page = pages[page] ? page : 'overview'; location.hash = S.page; $('#sidebar').classList.remove('is-open'); $('#mobile-menu').setAttribute('aria-expanded','false'); renderNav(); renderPage(); }
function renderNav() { $('#navigation').replaceChildren(...Object.entries(pages).map(([k,[label,name]])=>el('button',{type:'button',class:`nav-item ${S.page===k?'active':''}`,'aria-current':S.page===k?'page':null,onclick:()=>navigate(k)},icon(name),label,k==='tenders' && S.data?.tenders.length ? el('span',{class:'nav-count'},S.data.tenders.length) : null))); }
function heading(eyebrow,title,description,actions = []) { return el('div',{class:'page-heading'},el('div',{},el('p',{class:'eyebrow'},eyebrow),el('h1',{},title),el('p',{class:'page-description'},description)),actions.length ? el('div',{class:'button-group'},actions) : null); }
function renderPage() {
  if (!S.data) return;
  $('#breadcrumb-current').textContent = pages[S.page][0];
  const main = $('#main'); main.replaceChildren();
  ({overview:renderOverview,tenders:renderInbox,sources:renderSources,company:renderCompany,automation:renderAutomation,settings:renderSetup}[S.page])(main);
}
function importAction() { return button('Import tender','plus',openImport,'primary'); }
function demoBanner() { return el('div',{class:'demo-banner'},el('div',{class:'banner-copy'},icon('info'),el('span',{},el('strong',{},'Fictional demo data. '),'Sample opportunities demonstrate the workflow. They are not real tenders and will not be sent on WhatsApp.')),button('How it works','arrow',()=>navigate('settings'),'small')); }
function statusOpen(t) { return String(t.status).toLowerCase()==='open'; }
function needsReview(t) { return !t.review_status || ['unreviewed','pending','needs_review'].includes(t.review_status); }
function shortListed(t) { return ['shortlisted','approved'].includes(t.review_status); }
function archived(t) { return ['archived','dismissed','rejected'].includes(t.review_status); }
function statsCards() {
  const ts = S.data.tenders; const real = ts.filter(t=>!t.is_demo); const display = real.length ? real : ts; const demos = !real.length && ts.length;
  const due = display.filter(t=>statusOpen(t) && t.deadline && (new Date(t.deadline)-Date.now())/86400000 <= 7).length;
  return el('div',{class:'metrics'},metric('Open opportunities',display.filter(statusOpen).length,demos ? 'Fictional sample opportunities' : 'Across your connected sources','layers'),metric('Ready for review',display.filter(t=>needsReview(t)&&!archived(t)).length,'Read the study. Check the details.','file'),metric('Closing within 7 days',due,'Plan document preparation early','calendar'));
}
function metric(label,value,sub,name) { return el('div',{class:'metric'},el('div',{},el('div',{class:'metric-label'},label),el('div',{class:'metric-value'},value),el('div',{class:'metric-sub'},sub)),el('span',{class:'metric-icon'},icon(name))); }
function renderOverview(main) {
  main.append(heading('YOUR OPPORTUNITY DESK','Build on the right opportunity.','Construction tenders, clear assessments, and a practical next step.',[button('Export workspace','download',e=>exportWorkspace(e.currentTarget)),importAction()]));
  if (S.data.tenders.some(t=>t.is_demo)) main.append(demoBanner());
  main.append(statsCards());
  const grid = el('div',{class:'overview-grid'}); const content=el('section',{'aria-label':'Tender opportunities'});
  content.append(el('div',{class:'section-heading'},el('h2',{},'Your opportunities'),el('small',{},'Evidence backed · Human reviewed')));
  appendTenderBrowser(content);
  grid.append(content,overviewAside()); main.append(grid);
}
function overviewAside() {
  const services = S.data.services;
  const aside = el('aside',{class:'overview-aside'});
  const panel = el('section',{class:'side-panel'},el('span',{class:'tiny-label'},'FROM NOTICE TO NEXT STEP'),el('h2',{},'A clearer path to your next project.'),el('p',{},'TenderWise prepares the first assessment. Your team makes the bidding decision.'));
  panel.append(el('ol',{class:'workflow-list'},[['01','Set your company profile','Capabilities, capacity, and the places you work.'],['02','Check the tender study','Requirements, missing information, and source evidence.'],['03','Shortlist what fits','Review first, then include it in your digest.']].map(([n,t,d])=>el('li',{},el('span',{class:'step-number'},n),el('div',{},el('strong',{},t),el('p',{},d))))),button('Update company profile','arrow',()=>navigate('company'),'text small'));
  const quiet=el('section',{class:'quiet-panel'},el('h3',{},'Workspace connections'));
  quiet.append(serviceLine('Analysis',services.ai_configured ? 'AI connected' : 'Rules only',services.ai_configured),serviceLine('Source adapters',`${S.data.sources.filter(s=>s.enabled).length} enabled`,S.data.sources.some(s=>s.enabled)),serviceLine('WhatsApp',services.whatsapp_configured ? 'Credentials set' : 'Needs setup',services.whatsapp_configured),button('Configure connections','arrow',()=>navigate('settings'),'text small'));
  aside.append(panel,quiet);return aside;
}
function serviceLine(label,value,ok) { return el('div',{class:'service-line'},el('span',{},label),el('span',{class:'service-state'},el('span',{class:`status-dot ${ok?'':'warning'}`}),value)); }
function renderInbox(main) {
  main.append(heading('TENDER INBOX','Every opportunity, in context.','Search, assess, and shortlist tenders for your construction company.',[importAction()]));
  if(S.data.tenders.some(t=>t.is_demo))main.append(demoBanner());
  const wrapper=el('section',{'aria-label':'Tender inbox'});appendTenderBrowser(wrapper);main.append(wrapper);
}
function appendTenderBrowser(parent) {
  const listContainer=el('div',{class:'tender-list'}); const count=el('p',{class:'count-note'});
  const search=input('search',S.search,'search',{placeholder:'Search title, buyer, or location…','aria-label':'Search tenders'});
  search.addEventListener('input',()=>{S.search=search.value;draw();});
  const filter=select('status',S.filter,[['all','All statuses'],['open','Open for bidding'],['closing','Closing in 7 days'],['real','Real tenders only'],['demo','Demo samples']]);filter.setAttribute('aria-label','Filter tenders');filter.className='filter-select';filter.addEventListener('change',()=>{S.filter=filter.value;draw();});
  const tabs=el('div',{class:'tabs',role:'tablist','aria-label':'Review status'});
  const tabDefs=[['all','All opportunities',t=>true],['review','Needs review',needsReview],['shortlisted','Shortlisted',shortListed],['archived','Archived',archived]];
  function drawTabs() { tabs.replaceChildren(...tabDefs.map(([v,l,fn])=>el('button',{type:'button',role:'tab','aria-selected':S.tab===v,class:`tab ${S.tab===v?'active':''}`,onclick:()=>{S.tab=v;drawTabs();draw();}},l,el('span',{},S.data.tenders.filter(fn).length)))); }
  function draw() {
    let ts=S.data.tenders.filter(t=>({all:()=>!archived(t),review:()=>needsReview(t),shortlisted:()=>shortListed(t),archived:()=>archived(t)}[S.tab]||(()=>true))());
    if(S.search.trim()){const q=S.search.trim().toLowerCase();ts=ts.filter(t=>[t.title,t.buyer,t.location,t.scope,t.category].some(v=>String(v||'').toLowerCase().includes(q)));}
    if(S.filter==='open')ts=ts.filter(statusOpen);
    if(S.filter==='closing')ts=ts.filter(t=>statusOpen(t)&&t.deadline&&(new Date(t.deadline)-Date.now())/86400000<=7);
    if(S.filter==='real')ts=ts.filter(t=>!t.is_demo);
    if(S.filter==='demo')ts=ts.filter(t=>t.is_demo);
    ts.sort((a,b)=>(Number(b.fit_score)||0)-(Number(a.fit_score)||0));
    listContainer.replaceChildren(...ts.map(tenderCard));
    if(!ts.length){const empty=el('div',{class:'empty-state'},icon('file'),el('h3',{},S.data.tenders.length?'No matching opportunities':'Your next opportunity starts here.'),el('p',{},S.data.tenders.length?'Try a different search or filter to see more tenders.':'Import a tender document to prepare your first assessment, or explore a clearly labeled fictional demo.'),el('div',{class:'button-group'},importAction(),!S.data.tenders.length?button('Explore demo','grid',e=>seedDemo(e.currentTarget),'secondary'):button('Clear filters','refresh',()=>{S.search='';S.filter='all';S.tab='all';renderPage();},'secondary')));listContainer.append(empty);}
    count.textContent=ts.length?`${ts.length} ${ts.length===1?'opportunity':'opportunities'} shown · Match scores help prioritize review; they do not confirm eligibility.`:'';
  }
  parent.append(el('div',{class:'toolbar'},el('label',{class:'searchbox'},icon('search'),search),filter),tabs,listContainer,count);drawTabs();draw();
}
function tenderCard(t) {
  const score=t.fit_score==null?null:Math.max(0,Math.min(100,Number(t.fit_score)||0));
  const fit=el('div',{class:'fit-box'},el('div',{class:'fit-number'},score==null?'—':Math.round(score),score!=null?el('small',{},'/100'):null),el('div',{class:'fit-track'},el('span',{style:`width:${score||0}%`})),el('div',{class:'fit-caption'},'COMPANY FIT'));
  const tags=el('div',{class:'tender-tags'},tag(titleCase(t.category||'Construction')),t.is_demo?tag('FICTIONAL DEMO','demo'):null,shortListed(t)?tag('SHORTLISTED','green'):null,tag(titleCase(t.eligibility||'Eligibility unconfirmed'),t.eligibility==='eligible'?'green':'amber'));
  const title=el('button',{type:'button',class:'tender-title',dir:'auto',onclick:()=>openTender(t)},text(t.title));
  const body=el('div',{class:'tender-card-main'},tags,title,el('div',{class:'buyer',dir:'auto'},icon('building'),t.buyer||'Buyer not provided'),el('p',{class:'scope-excerpt',dir:'auto'},t.scope||'Open the study to review extracted information and missing details.'));
  const due=t.deadline&&(new Date(t.deadline)-Date.now())/86400000<=7&&statusOpen(t);
  const bottom=el('div',{class:'tender-card-bottom'},el('div',{class:'tender-meta'},el('span',{},icon('location'),t.location||'Location unknown'),el('span',{class:due?'due-soon':''},icon('calendar'),t.deadline?`Due ${date(t.deadline)}`:'Deadline unconfirmed'),el('span',{},icon('shield'),t.analysis_mode==='ai'?'AI-assisted study':'Rules-based study')),button('View study','arrow',()=>openTender(t),'text'));
  return el('article',{class:'tender-card'},el('div',{class:'tender-card-top'},body,fit),bottom);
}
function modal(title,subtitle,wide=false) { const m=$('#modal'); m.className=wide?'wide':''; m.replaceChildren(el('div',{class:'modal-head'},el('div',{},el('h2',{id:'modal-title'},title),subtitle?el('p',{},subtitle):null),el('button',{class:'icon-button',type:'button','aria-label':'Close dialog',onclick:()=>m.close()},icon('close'))));if(!m.open)m.showModal();return m; }
function closeModal(){ $('#modal').close(); }
function openTender(t) {
  const m=modal('Tender study','Review the evidence before deciding whether to bid.',true);
  const source=safeLink(t.source_url);
  m.append(el('div',{class:'report-heading'},el('div',{class:'tender-tags'},tag(titleCase(t.category||'Construction')),tag(titleCase(t.status||'Status unconfirmed')),t.is_demo?tag('FICTIONAL DEMO','demo'):null),el('h2',{dir:'auto'},text(t.title)),el('p',{dir:'auto'},[t.buyer,t.location].filter(Boolean).join(' · ')||'Buyer and location not provided')));
  const left=el('div',{class:'report-main'});
  if(t.is_demo)left.append(note('This is a fictional sample, included only to demonstrate the workflow. It is excluded from live WhatsApp digests.',true));
  left.append(el('div',{class:'recommendation-block'},el('h3',{},'Recommended next step'),el('p',{dir:'auto'},text(t.recommendation))));
  const facts=el('dl',{class:'report-facts'});[['Submission deadline',t.deadline?(String(t.deadline).length<=10?`${date(t.deadline)} · time unconfirmed`:date(t.deadline,true)):'Unconfirmed'],['Bid security',money(t.bid_bond)],['Document fee',money(t.document_fee)],['Project value',money(t.project_value)],['Eligibility',titleCase(t.eligibility||'Needs confirmation')],['Analysis method',t.analysis_mode==='ai'?'AI-assisted, evidence checked':t.is_demo?'Fictional demo · rules-based':'Rules-based extraction']].forEach(([a,b])=>facts.append(el('div',{class:'report-fact'},el('dt',{},a),el('dd',{dir:'auto'},b))));left.append(facts);
  left.append(reportSection('Scope of work',t.scope||'The scope could not be extracted. Check the original document.'),reportSection('Requirements & submission',list(t.requirements),'No confirmed requirements were extracted.'),reportSection('Risks to investigate',list(t.risks),'No specific risks were extracted. This does not confirm that the tender is risk-free.'),reportSection('Missing information',list(t.missing_information),'Check the original tender documents for any details not included in this report.'));
  const review=select('review_status',t.review_status||'pending',[['pending','Needs review'],['approved','Approve & shortlist'],['rejected','Archive / reject']]);
  const feedback=select('feedback',t.feedback||'',[['','Not rated yet'],['relevant','Relevant to our company'],['irrelevant','Not relevant to our company']]);
  const save=button('Save review','check',e=>busy(e.currentTarget,async()=>{if(review.value==='approved'&&!confirm('Confirm that your team checked the original notice, current amendments, eligibility requirements, and exact submission time. This approval is valid for live digest inclusion for 24 hours.'))return;await api(`/api/tenders/${encodeURIComponent(t.id)}`,{method:'PATCH',body:{review_status:review.value,feedback:feedback.value}});await reload();closeModal();toast('Review saved.');}),'primary');
  left.append(el('div',{class:'review-controls'},el('h3',{},'Your company’s decision'),note('Approval confirms a check of the original notice, amendments, and exact closing time. Live digests require approval within the last 24 hours.'),field('Review status',review),field('Company relevance feedback',feedback,'Your ratings can be used to evaluate matching quality.'),save));
  const right=el('aside',{class:'report-aside'},el('div',{class:'report-fit'},el('div',{},el('span',{class:'tiny-label'},'COMPANY FIT'),el('small',{},'A prioritization score, not bid eligibility.')),el('strong',{},t.fit_score==null?'—':`${Math.round(Number(t.fit_score)||0)}/100`)),el('h3',{},'Source evidence'));
  if(list(t.evidence).length){list(t.evidence).forEach(e=>right.append(el('div',{class:'evidence'},el('strong',{},titleCase(e.field||'Source extract')),el('blockquote',{dir:'auto'},e.quote||e.text||'No quotation available'),e.page!=null?el('small',{},`Document page ${e.page}`):null)));}
  else right.append(el('p',{class:'page-description'},'No quoted evidence was extracted. Verify all fields in the source document.'));
  const sourceButton=source?el('a',{class:'button small',href:source,target:'_blank',rel:'noopener noreferrer'},icon('external'),'Open source'):null;
  right.append(el('div',{class:'spaced'},sourceButton),el('p',{class:'report-meta'},`Source: ${t.source_name||'Uploaded document'}\nImported: ${date(t.created_at,true)}\nLast updated: ${date(t.updated_at||t.created_at,true)}`));
  m.append(el('div',{class:'report-layout'},left,right),el('div',{class:'modal-foot'},button('Original document','file',e=>download(`/api/tenders/${encodeURIComponent(t.id)}/document`,`tenderwise-original-${t.id}.txt`,e.currentTarget)),button('Re-analyze','refresh',e=>busy(e.currentTarget,async()=>{await api(`/api/tenders/${encodeURIComponent(t.id)}/analyze`,{method:'POST'});await reload();openTender(S.data.tenders.find(x=>x.id===t.id)||t);toast('Study updated.');})),button('Download study','download',e=>downloadReport(t,e.currentTarget),'primary')));
}
function reportSection(title,content,fallback) { const n=el('section',{class:'report-section'},el('h3',{},title));if(Array.isArray(content))n.append(content.length?el('ul',{},content.map(s=>el('li',{dir:'auto'},typeof s==='object'?(s.text||JSON.stringify(s)):s))):el('p',{},fallback));else n.append(el('p',{dir:'auto'},content));return n; }
function openImport() {
  const m=modal('Import an opportunity','Start with the original tender notice or document.');
  const body=el('div',{class:'modal-body'});const tabs=el('div',{class:'modal-tabs',role:'tablist','aria-label':'Import method'});const content=el('div');let mode='file';
  function draw() {
    tabs.replaceChildren(...[['file','Upload document'],['text','Paste text'],['url','Import URL']].map(([v,l])=>el('button',{type:'button',role:'tab','aria-selected':mode===v,class:mode===v?'active':'',onclick:()=>{mode=v;draw();}},l)));content.replaceChildren();
    const form=el('form',{class:'form-stack'});let file,textInput,title,url;
    if(mode==='file'){
      file=input('file','','file',{accept:'.pdf,.txt,.html,.htm',required:true});
      form.append(el('label',{class:'dropzone'},icon('upload'),el('strong',{},'Choose your tender document'),el('small',{},'PDF, plain text, or HTML. Scanned PDFs may require OCR.'),file));
    }else if(mode==='text'){
      title=input('title','','text',{placeholder:'Optional title',maxlength:300});textInput=el('textarea',{name:'text',rows:10,required:true,placeholder:'Paste the complete tender notice here…',dir:'auto',minlength:30});url=input('source_url','','url',{placeholder:'https://…'});
      form.append(field('Tender title',title),field('Tender notice',textInput,'Include dates, qualifications, fees, and submission instructions.'),field('Source link (optional)',url));
    }else{url=input('url','','url',{placeholder:'https://example.gov.eg/tender-notice',required:true});form.append(field('Public tender URL',url,'Use a public HTTPS page or PDF that you have permission to process.'),note('Subscription logins, CAPTCHAs, and paid access are not bypassed. Upload the document instead if the source does not permit automated access.',true));}
    if(!S.data.services.ai_configured)form.append(note('No AI key is configured. This import will use the built-in extraction rules and clearly label its limitations. Add an API key on the server to enable AI studies.'));
    const submit=el('button',{class:'button primary',type:'submit'},icon('spark'),'Import & prepare study');const error=el('div',{class:'modal-error',hidden:true,role:'alert'});const progress=el('div',{class:'import-progress',hidden:true},el('span',{class:'spinner'}),'Reading the document and preparing your assessment…');
    form.append(error,progress,submit);
    form.addEventListener('submit',async ev=>{ev.preventDefault();submit.disabled=true;error.hidden=true;progress.hidden=false;try{let result;if(mode==='file'){const fd=new FormData();fd.append('file',file.files[0]);result=await api('/api/import',{method:'POST',body:fd});}else if(mode==='text'){result=await api('/api/import/text',{method:'POST',body:{text:textInput.value,title:title.value||'Imported tender',source_url:url.value||''}});}else result=await api('/api/import/url',{method:'POST',body:{url:url.value}});await reload();closeModal();const id=result?.id||result?.tender?.id;const t=S.data.tenders.find(x=>x.id===id);if(t)openTender(t);toast(result?.duplicate?'This document was already imported. Opening the saved opportunity.':'Tender imported. Review the extracted details before using them.');}catch(e){error.textContent=e.message;error.hidden=false;}finally{submit.disabled=false;progress.hidden=true;}});
    content.append(form);
  }
  body.append(tabs,content);m.append(body);draw();
}
async function seedDemo(btn) { await busy(btn,async()=>{await api('/api/demo/seed',{method:'POST'});await reload();toast('Fictional demo loaded. Sample opportunities are excluded from live messages.');}); }
function renderCompany(main) {
  const c=S.data.company;
  main.append(heading('COMPANY PROFILE','Make every match more meaningful.','Tell TenderWise what your construction company can take on.'));
  const form=el('form',{class:'card'});const grid=el('div',{class:'form-grid'});
  grid.append(field('Company name',input('name',c.name||'','text',{required:true,maxlength:160})),field('Contractor classification / grade',input('contractor_grade',c.contractor_grade||'','text',{placeholder:'Your registered classification',maxlength:160}),'Used to flag requirements for manual verification.'),field('Construction specialisms',input('sectors',list(c.sectors).join(', '),'text',{placeholder:'General construction, roads, civil works…'}),'Separate specialisms with commas.'),field('Operating locations',input('locations',list(c.locations).join(', '),'text',{placeholder:'Cairo, Giza, Alexandria…'}),'Separate locations with commas. Use “All Egypt” if applicable.'),field('Maximum project value (EGP)',input('max_project_value',c.max_project_value,'number',{min:0,step:1,placeholder:'Leave blank if unknown'}),'A capacity limit; not a prediction of tender value.'),field('Available bid security (EGP)',input('available_bid_bond',c.available_bid_bond,'number',{min:0,step:1,placeholder:'Leave blank if unknown'}),'Helps identify opportunities that may exceed available security.'),field('Capabilities, experience & constraints',el('textarea',{name:'notes',rows:5,maxlength:5000,placeholder:'Previous projects, equipment, certificates, staff capacity, restrictions…',dir:'auto'},c.notes||''),'Do not include bank details or private identification numbers.',true));
  form.append(el('div',{class:'card-title'},el('div',{},el('h2',{},'Your company, in context'),el('p',{},'Matching improves when this information is complete and current.'))),note('A match score is an initial assessment. The tender’s current documents and your company records determine actual eligibility.'),grid,el('div',{class:'form-actions'},el('button',{class:'button primary',type:'submit'},icon('check'),'Save company profile')));
  form.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(form);const asList=n=>String(fd.get(n)||'').split(/[,،]/).map(s=>s.trim()).filter(Boolean);const asNum=n=>fd.get(n)===''?null:Number(fd.get(n));busy($('button[type=submit]',form),async()=>{await api('/api/company',{method:'PUT',body:{name:fd.get('name'),contractor_grade:fd.get('contractor_grade'),sectors:asList('sectors'),locations:asList('locations'),max_project_value:asNum('max_project_value'),available_bid_bond:asNum('available_bid_bond'),notes:fd.get('notes')}});await reload();toast('Company profile saved. Match scores updated and previous approvals reset for review.');});});main.append(form);
}
function renderSources(main) {
  main.append(heading('SOURCE MANAGEMENT','A connected view of opportunity.','Add sources you are authorized to collect from. Every adapter keeps its own health and provenance.',[button('Add source','plus',openSource,'primary')]));
  const grid=el('div',{class:'two-column'});const sourceList=el('section',{'aria-label':'Connected sources'});
  if(!S.data.sources.length)sourceList.append(el('div',{class:'empty-state'},icon('layers'),el('h3',{},'Connect your first source'),el('p',{},'Use an authorized RSS or Atom feed, JSON feed, or configured HTML listing. You can also import tender documents directly.'),button('Add source','plus',openSource,'primary')));
  S.data.sources.forEach(s=>{
    const collect=button('Check now','refresh',e=>busy(e.currentTarget,async()=>{const result=await api(`/api/sources/${encodeURIComponent(s.id)}/collect`,{method:'POST'});await reload();toast(resultSummary(result,'Source checked.'));}),'small');collect.disabled=!s.enabled||!s.permission_confirmed;
    const remove=button('Remove','trash',e=>{if(confirm(`Remove source “${s.name}”? Previously imported tenders will remain.`))busy(e.currentTarget,async()=>{await api(`/api/sources/${encodeURIComponent(s.id)}`,{method:'DELETE'});await reload();toast('Source removed.');});},'text small');
    const toggle=button(s.enabled?'Pause':'Enable',s.enabled?'clock':'check',e=>busy(e.currentTarget,async()=>{await api(`/api/sources/${encodeURIComponent(s.id)}`,{method:'PATCH',body:{enabled:!s.enabled}});await reload();toast(s.enabled?'Source paused.':'Source enabled.');}),'small');
    sourceList.append(el('article',{class:'source-row'},el('div',{class:'source-top'},el('div',{},el('h3',{},s.name),el('p',{class:'source-url'},s.url)),tag(s.enabled?titleCase(s.status||'Ready to check'):'Disabled',s.last_error?'amber':s.enabled?'green':'')),el('div',{class:'tender-tags'},tag(String(s.type||'feed').toUpperCase()),tag(s.permission_confirmed?'ACCESS CONFIRMED':'ACCESS UNCONFIRMED',s.permission_confirmed?'green':'amber')),s.last_error?el('div',{class:'source-error'},s.last_error):null,el('div',{class:'source-footer'},el('small',{},s.last_checked?`Last check: ${date(s.last_checked,true)}`:'Not checked yet'),el('div',{class:'button-group'},collect,toggle,remove))));
  });
  const aside=el('aside',{class:'card'},el('h2',{},'Start with reliable access'),el('p',{class:'page-description'},'Adding a website link does not automatically make it a working source connector.'),el('ul',{class:'source-hints'},el('li',{},'Tender Egypt: direct automated access has not been verified. Use an allowed feed/export or upload documents from your subscription.'),el('li',{},'Official notices: use public feeds or permission-based adapters. Check each tender’s current eligibility rules.'),el('li',{},'PDFs and emails: save the original notice as a file and import it with its source link.')),button('Import a document','upload',openImport,'secondary'));
  grid.append(sourceList,aside);main.append(grid);
}
function openSource() {
  const m=modal('Connect a source','Use a feed or listing that permits automated collection.');const form=el('form');const body=el('div',{class:'modal-body form-stack'});
  const advanced=el('textarea',{name:'config',rows:6,spellcheck:false,'aria-label':'Source adapter configuration'},'{}');
  const type=select('type','rss',[['rss','RSS / Atom feed'],['json','JSON feed'],['html','HTML listing (configured selectors)']]);
  body.append(field('Source name',input('name','','text',{required:true,placeholder:'Official construction notices'})),field('Adapter',type),field('Feed / listing URL',input('url','','url',{required:true,placeholder:'https://example.gov.eg/feed'})),el('details',{},el('summary',{class:'details-toggle'},'Advanced adapter configuration'),el('div',{class:'details-content'},field('Configuration JSON',advanced,'Use the adapter field mapping documented in README.md. RSS feeds usually need no configuration.'))),checkbox('permission_confirmed',false,'I have verified that I am authorized to collect and process this source.'),checkbox('enabled',true,'Enable this source for manual and scheduled checks.'));
  const error=el('div',{class:'modal-error',hidden:true,role:'alert'});body.append(error);const submit=el('button',{class:'button primary',type:'submit'},icon('plus'),'Add source');form.append(body,el('div',{class:'modal-foot'},button('Cancel',null,closeModal),submit));
  form.addEventListener('submit',async e=>{e.preventDefault();submit.disabled=true;error.hidden=true;try{const fd=new FormData(form);let config;try{config=JSON.parse(advanced.value||'{}');}catch{throw new Error('The adapter configuration must be valid JSON.');}if(!config||Array.isArray(config)||typeof config!=='object')throw new Error('The adapter configuration must be a JSON object.');await api('/api/sources',{method:'POST',body:{name:fd.get('name'),type:fd.get('type'),url:fd.get('url'),permission_confirmed:fd.has('permission_confirmed'),enabled:fd.has('enabled'),config}});await reload();closeModal();toast('Source saved. Use “Check now” to verify the connection.');}catch(ex){error.textContent=ex.message;error.hidden=false;}finally{submit.disabled=false;}});m.append(form);
}
function renderAutomation(main) {
  const s=S.data.settings;const services=S.data.services;
  main.append(heading('AUTOMATION & DELIVERY','The right updates, at the right time.','Schedule source checks and prepare a reviewed WhatsApp digest.',[button('Run source check','refresh',e=>busy(e.currentTarget,async()=>{const r=await api('/api/jobs/run',{method:'POST'});await reload();toast(resultSummary(r,'Scheduled workflow completed.'));}))]));
  const grid=el('div',{class:'two-column'});const left=el('section');const form=el('form',{class:'card'});
  const time=input('digest_time',`${String(s.digest_hour??8).padStart(2,'0')}:${String(s.digest_minute??0).padStart(2,'0')}`,'time',{required:true});
  const recipient=input('whatsapp_recipient',s.whatsapp_recipient||'','tel',{placeholder:'+201012345678',autocomplete:'tel'});
  const formGrid=el('div',{class:'form-grid'},field('Daily check / digest time',time),field('Timezone',input('timezone',s.timezone||'Africa/Cairo','text',{required:true})),field('Recipient WhatsApp number',recipient,'Include the country code, e.g. +20 for Egypt.',true),field('Approved template name',input('whatsapp_template_name',s.whatsapp_template_name||'','text',{placeholder:'tender_digest'}),'The approved template must have one body parameter for the digest.'),field('Template language',input('whatsapp_language',s.whatsapp_language||'en','text',{placeholder:'en'}),'Use the exact language code approved by Meta.'));
  form.append(el('div',{class:'card-title'},el('div',{},el('h2',{},'Daily workflow'),el('p',{},'The server must be running for its local scheduler to execute.'))),formGrid,el('div',{class:'form-stack spaced'},checkbox('schedule_enabled',!!s.schedule_enabled,'Enable daily source checks and digest preparation.'),checkbox('require_human_review',s.require_human_review!==false,'Require a fresh human approval before sending each live opportunity. Switch off for hands-free draft alerts from recently collected notices.'),checkbox('whatsapp_opt_in',!!s.whatsapp_opt_in,'The recipient has explicitly agreed to receive these tender updates.'),checkbox('whatsapp_template_approved',!!s.whatsapp_template_approved,'Meta has approved this exact template and language, with one body parameter for the digest.'),checkbox('whatsapp_enabled',!!s.whatsapp_enabled,'Enable WhatsApp delivery using the configured server credentials.'),checkbox('whatsapp_test_mode',s.whatsapp_test_mode!==false,'Keep scheduled messages in test mode (preview only, no live delivery).')),note('Live digests exclude fictional, closed, rejected and previously sent versions. Fresh approval is required by default. Hands-free mode sends recently collected draft assessments and marks unreviewed records clearly.',true),el('div',{class:'form-actions'},el('button',{class:'button primary',type:'submit'},icon('check'),'Save automation settings')));
  form.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(form);const [hour,minute]=String(fd.get('digest_time')).split(':').map(Number);busy($('button[type=submit]',form),async()=>{await api('/api/settings',{method:'PUT',body:{...s,schedule_enabled:fd.has('schedule_enabled'),require_human_review:fd.has('require_human_review'),digest_hour:hour,digest_minute:minute,timezone:fd.get('timezone'),whatsapp_recipient:fd.get('whatsapp_recipient'),whatsapp_opt_in:fd.has('whatsapp_opt_in'),whatsapp_template_approved:fd.has('whatsapp_template_approved'),whatsapp_enabled:fd.has('whatsapp_enabled'),whatsapp_template_name:fd.get('whatsapp_template_name'),whatsapp_language:fd.get('whatsapp_language'),whatsapp_test_mode:fd.has('whatsapp_test_mode')}});await reload();toast('Automation settings saved.');});});
  left.append(form);
  const connections=el('div',{class:'card'},el('h2',{},'Delivery readiness'),connectionCard('WhatsApp credentials',services.whatsapp_configured?'Server credentials are configured.':'Add the sender ID, access token, and Graph API version to the server environment.',services.whatsapp_configured),connectionCard('Recipient consent',s.whatsapp_opt_in?'Consent is recorded in this workspace.':'Confirm consent before enabling delivery.',s.whatsapp_opt_in),connectionCard('Scheduled delivery',s.schedule_enabled?(s.whatsapp_test_mode!==false?'Daily workflow enabled in test mode.':'Daily workflow enabled. Live delivery also needs WhatsApp enabled.'):'Daily workflow is disabled.',s.schedule_enabled));left.append(connections);
  const right=el('aside');const preview=el('section',{class:'card'},el('div',{class:'section-heading'},el('h2',{},'Digest preview'),el('span',{class:'tag'},'REVIEW BEFORE SENDING')));const previewText=el('pre',{class:'digest-preview',dir:'auto'},'Loading digest…');const previewMeta=el('p',{class:'page-description'});let previewLive=false;
  const previewTabs=el('div',{class:'modal-tabs',role:'tablist','aria-label':'Digest preview type'});
  function drawPreviewTabs(){previewTabs.replaceChildren(...[[false,'Test preview'],[true,'Live digest']].map(([v,l])=>el('button',{type:'button',role:'tab','aria-selected':previewLive===v,class:previewLive===v?'active':'',onclick:()=>{previewLive=v;drawPreviewTabs();loadDigest();}},l)));}
  const refresh=button('Refresh preview','refresh',e=>busy(e.currentTarget,loadDigest),'text small');
  const dry=button('Save test preview','check',e=>sendDigest(false,e.currentTarget),'secondary');
  const live=button('Send on WhatsApp','chat',e=>sendDigest(true,e.currentTarget),'primary');
  live.disabled=true;
  preview.append(previewTabs,previewText,previewMeta,refresh,el('div',{class:'button-group spaced'},dry,live),el('p',{class:'page-notice'},'Test previews may contain clearly labeled fictional or unreviewed records. Select Live digest to review the exact live candidates. Reports remain private in this dashboard.'));
  async function loadDigest(){dry.disabled=true;live.disabled=true;const requestedLive=previewLive;try{const d=await api(`/api/digest?live=${previewLive?'true':'false'}`);if(requestedLive!==previewLive)return;previewText.textContent=d.text||(previewLive?'No unsent real opportunities meet your review policy.':'No opportunities are available for a test preview.');const ids=d.tender_ids||[];previewMeta.textContent=previewLive?`${ids.length} live ${ids.length===1?'candidate':'candidates'} · ${s.require_human_review!==false?'Fresh approval required':'Fresh draft alerts allowed'} · Fictional records excluded`:`${ids.length} preview ${ids.length===1?'entry':'entries'} · Test only, no live delivery`;dry.disabled=previewLive||!ids.length;live.disabled=!previewLive||!ids.length||!services.whatsapp_configured||!s.whatsapp_opt_in||!s.whatsapp_enabled||!s.whatsapp_template_approved||s.whatsapp_test_mode!==false;}catch(e){previewText.textContent=e.message;dry.disabled=true;live.disabled=true;}}
  const history=el('section',{class:'card'},el('h2',{},'Delivery history'));
  if(!S.data.outbox.length)history.append(el('p',{class:'page-description'},'Your test previews and live delivery attempts will appear here.'));
  else S.data.outbox.slice(0,8).forEach(o=>history.append(el('article',{class:'outbox-item'},el('div',{class:'section-heading'},tag(titleCase(o.status||'Recorded'),['sent','delivered','read'].includes(o.status)?'green':o.error?'red':''),el('small',{},date(o.created_at,true))),el('p',{dir:'auto'},o.digest||o.message||''),o.error?el('p',{class:'source-error'},o.error):null,o.status==='failed'&&['provider_rejected','invalid_configuration','invalid_payload'].includes(o.error)?button('Retry after correcting setup','refresh',e=>sendDigest(true,e.currentTarget,true),'small'):null)));
  right.append(preview,history);grid.append(left,right);main.append(grid);drawPreviewTabs();loadDigest();
}
function connectionCard(title,copy,ok) { return el('div',{class:'connection-card'},el('div',{},el('strong',{},title),el('small',{},copy)),tag(ok?'READY':'NEEDS SETUP',ok?'green':'amber')); }
async function sendDigest(live,btn,retry_failed=false){if(live&&!confirm(`${retry_failed?'Retry a definitely rejected digest after correcting its configuration?':'Send the current live digest?'} Recipient: ${S.data.settings.whatsapp_recipient||'the configured WhatsApp recipient'}. This uses the official API and may incur messaging charges.`))return;await busy(btn,async()=>{const r=await api('/api/digest/send',{method:'POST',body:{live,retry_failed}});await reload();toast(resultSummary(r,live?'Delivery request recorded. Check delivery history for its status.':'Test preview saved. No WhatsApp message was sent.'),['failed','delivery_unknown','blocked'].includes(r?.status));});}
function resultSummary(r,fallback) { if(typeof r?.message==='string')return r.message;if(typeof r?.detail==='string')return r.detail;if(typeof r?.summary==='string')return r.summary;if(r?.errors?.length)return `Source check finished with issues: ${r.errors.join('; ')}`;const failures=Array.isArray(r?.sources)?r.sources.filter(s=>s.status==='error'):[];if(failures.length)return `${failures.length} source check(s) failed. Open Sources for details.`;if(r?.delivery?.status==='blocked')return r.delivery.detail||'Delivery needs configuration.';if(r?.imported!=null)return `${r.imported} imported${r.updated!=null?`, ${r.updated} updated`:''}${r.duplicates!=null?`, ${r.duplicates} already known`:''}.`;if(r?.status)return `${fallback} Status: ${titleCase(r.status)}.`;return fallback; }
function renderSetup(main) {
  const services=S.data.services;
  main.append(heading('SETUP & PROJECT GUIDE','A useful system. A project you can explain.','Start with a real document, verify the results, then connect your automation.'));
  const grid=el('div',{class:'settings-overview'});const readiness=el('section',{class:'card'},el('div',{class:'card-title'},el('div',{},el('h2',{},'Your runtime'),el('p',{},'Credentials stay on the server and are never displayed here.'))));
  readiness.append(connectionCard('Tender analysis',services.ai_configured?`API configured${services.model?` · ${services.model}`:''}`:'Rules-based extraction is available. Add OPENAI_API_KEY and OPENAI_MODEL to enable AI.',services.ai_configured),connectionCard('WhatsApp delivery',services.whatsapp_configured?'Sender configuration is present. Consent and template approval are checked separately.':'Set WHATSAPP_ACCESS_TOKEN, WHATSAPP_PHONE_NUMBER_ID, and WHATSAPP_API_VERSION.',services.whatsapp_configured),connectionCard('Workspace access',services.admin_auth?'Admin token authentication is enabled.':'Local-only access. Set ADMIN_TOKEN before exposing this application.',services.admin_auth),button('Enter admin token','shield',openConnection,'secondary spaced'));
  const data=el('section',{class:'card'},el('div',{class:'card-title'},el('div',{},el('h2',{},'Data & demonstration'),el('p',{},'Keep your real company data private.'))),el('p',{class:'page-description'},'Export your workspace for backup. Demo opportunities are clearly marked fictional and excluded from real WhatsApp delivery.'),el('div',{class:'button-group spaced'},button('Export workspace','download',e=>exportWorkspace(e.currentTarget)),button('Load fictional demo','grid',e=>seedDemo(e.currentTarget),'secondary')),el('p',{class:'page-notice'},'The source code, installation instructions, environment settings, and evaluation guide are included in the project folder.'));
  grid.append(readiness,data);main.append(grid);
  const guide=el('section',{class:'card'},el('div',{class:'card-title'},el('div',{},el('h2',{},'Your first working workflow'),el('p',{},'Build confidence with one complete, reviewed opportunity.'))),el('div',{class:'help-grid'},[['01 · Add your company','Save its locations, specialisms, classification, and capacity. Leave unknown amounts blank instead of guessing.'],['02 · Import a tender','Upload a real PDF, paste a notice, or use a public URL you are authorized to process. Scanned PDFs need OCR before analysis.'],['03 · Review the assessment','Check the deadline, bid security, requirements, and supporting quotes against the original document. Add company notes and shortlist the opportunity.'],['04 · Connect and test delivery','Configure server credentials, record recipient consent, and approve your WhatsApp template. Save a test preview before enabling live delivery.']].map(([t,p])=>el('div',{class:'help-step'},el('h3',{},t),el('p',{},p)))));
  main.append(guide,note('For your portfolio: explain the model provider honestly, evaluate extraction against human-checked examples, compare matching with a simple keyword baseline, and record your dad’s feedback and time saved.'));
}
function openConnection() {
  const m=modal('Workspace connection','Only needed when ADMIN_TOKEN is enabled on the server.');const form=el('form');const body=el('div',{class:'modal-body form-stack'});const token=input('token',S.token,'password',{placeholder:'Enter the server admin token',autocomplete:'off'});
  body.append(field('Admin token',token,'Stored only in this browser session. It is sent only to this application’s API.'),note('AI and WhatsApp service keys belong in the server environment. Do not paste them here.'));
  const submit=el('button',{class:'button primary',type:'submit'},icon('check'),'Connect');form.append(body,el('div',{class:'modal-foot'},button('Cancel',null,closeModal),submit));
  form.addEventListener('submit',e=>{e.preventDefault();busy(submit,async()=>{S.token=token.value.trim();if(S.token)sessionStorage.setItem('tenderwise-token',S.token);else sessionStorage.removeItem('tenderwise-token');await reload();closeModal();toast('Workspace connected.');});});m.append(form);
}
async function download(path,filename,btn){await busy(btn,async()=>{const r=await api(path,{raw:true});const disposition=r.headers.get('content-disposition')||'';const stated=/filename="?([^";]+)"?/i.exec(disposition);if(stated)filename=stated[1].split(/[\\/]/).pop();else if((r.headers.get('content-type')||'').includes('application/pdf'))filename=filename.replace(/\.txt$/i,'.pdf');const blob=await r.blob();const u=URL.createObjectURL(blob);const a=el('a',{href:u,download:filename});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);});}
async function exportWorkspace(btn){await download('/api/export',`tenderwise-workspace-${new Date().toISOString().slice(0,10)}.json`,btn);}
async function downloadReport(t,btn){await download(`/api/tenders/${encodeURIComponent(t.id)}/report`,`tenderwise-study-${String(t.id).replace(/[^a-zA-Z0-9_-]/g,'')}.html`,btn);}
function showBootError(e){$('#connection-dot').className='status-dot error';$('#connection-label').textContent='Connection required';$('#main').replaceChildren(el('section',{class:'error-workspace'},el('p',{class:'eyebrow'},'WORKSPACE CONNECTION'),el('h1',{},'Let’s reconnect your opportunity desk.'),el('p',{class:'page-description'},e.message||'The application server could not be reached.'),el('div',{class:'button-group spaced'},button('Try again','refresh',ev=>busy(ev.currentTarget,()=>reload()),'primary'),button('Enter admin token','shield',openConnection,'secondary'))));}
$('#today-label').textContent=new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'long',year:'numeric',timeZone:'Africa/Cairo'}).format(new Date());
$('#refresh-button').append(icon('refresh'));
$('#refresh-button').addEventListener('click',e=>busy(e.currentTarget,async()=>{await reload();toast('Workspace refreshed.');}));
$('#connection-button').addEventListener('click',openConnection);
$('#profile-shortcut').addEventListener('click',()=>navigate('company'));
$('#mobile-menu').addEventListener('click',()=>{const open=$('#sidebar').classList.toggle('is-open');$('#mobile-menu').setAttribute('aria-expanded',String(open));});
document.addEventListener('click',e=>{if(window.innerWidth<=760&&!$('#sidebar').contains(e.target)&&!$('#mobile-menu').contains(e.target)){$('#sidebar').classList.remove('is-open');$('#mobile-menu').setAttribute('aria-expanded','false');}});
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeModal();}});
window.addEventListener('hashchange',()=>{const p=location.hash.slice(1);if(pages[p]&&S.page!==p){S.page=p;renderNav();renderPage();}});
S.page=pages[location.hash.slice(1)]?location.hash.slice(1):'overview';renderNav();reload().catch(showBootError);
