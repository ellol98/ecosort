"""TenderWise: evidence-based tender review for construction companies."""

__version__ = "1.0.0"
