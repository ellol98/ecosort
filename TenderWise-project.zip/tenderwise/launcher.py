"""Portable, beginner-friendly installer/launcher. Python 3.11+ required."""
import os
import subprocess
import sys
import venv
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def already_running():
    import json
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:8765/health", timeout=1) as response:
            body = json.loads(response.read(2000))
        return body.get("status") == "ok" and body.get("version") == "1.0.0"
    except Exception:
        return False


def main():
    os.chdir(ROOT)
    if sys.version_info < (3, 11):
        raise SystemExit("Install Python 3.11 or newer from python.org, then run START.bat again.")
    if already_running():
        print("TenderWise is already running at http://127.0.0.1:8765", flush=True)
        if "--no-browser" not in sys.argv:
            webbrowser.open("http://127.0.0.1:8765")
        return
    executable = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if Path(sys.prefix).resolve() != (ROOT / ".venv").resolve():
        if not executable.exists():
            print("Creating a private Python environment for TenderWise...", flush=True)
            venv.create(ROOT / ".venv", with_pip=True)
        subprocess.check_call([str(executable), str(Path(__file__).resolve()), *sys.argv[1:]])
        return
    marker = ROOT / ".venv" / "tenderwise-requirements.sha256"
    import hashlib
    dependencies = ROOT / "requirements.lock.txt"
    if not dependencies.exists():
        dependencies = ROOT / "requirements.txt"
    fingerprint = hashlib.sha256(dependencies.read_bytes()).hexdigest()
    if not marker.exists() or marker.read_text() != fingerprint:
        print("Installing application dependencies. The first run needs internet access...", flush=True)
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(dependencies)])
        marker.write_text(fingerprint)
    print("\nTenderWise is starting at http://127.0.0.1:8765\nKeep this window open. Press Ctrl+C to stop.\n", flush=True)
    if "--no-browser" not in sys.argv:
        # This is a user-run launcher; the application itself never drives a browser.
        import threading
        threading.Timer(2, lambda: webbrowser.open("http://127.0.0.1:8765")).start()
    import uvicorn
    uvicorn.run("tenderwise.app:app", host="127.0.0.1", port=8765, proxy_headers=False)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
