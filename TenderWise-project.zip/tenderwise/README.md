# TenderWise

An evidence-based tender assistant for Egyptian construction companies. Collect permitted notices, extract requirements from Arabic/English documents, compare opportunities with a company profile, review short bid/no-bid assessments, and deliver approved opportunities through the official WhatsApp Cloud API.

**Start with [START_HERE.md](START_HERE.md).** Windows users can double-click `START.bat` after installing Python 3.11+.

## Implemented

- Responsive local web dashboard: opportunities, company profile, sources, automation, setup guide.
- PDF/TXT/HTML uploads, pasted text and public HTTPS document imports.
- Optional OpenAI Responses API extraction with a strict JSON schema and `store:false`.
- Conservative offline extraction for labeled fields; explicit AI/rules/demo labels.
- Verbatim evidence checks, source/page references, SHA-256 hashes, original uploads and changed-document history.
- Transparent construction matching: scope, location, deadlines and configured financial limits. Eligibility remains subject to confirmation.
- Printable HTML mini-studies: scope, requirements, fees, bond, missing information, risks, matching reasons and next steps. Browser Print can save a PDF.
- Permission-gated RSS/Atom, JSON and configurable HTML listing adapters; collection health and errors.
- Daily Cairo-time scheduler, manual collection jobs, per-run AI request budget.
- Official WhatsApp template payloads, dry runs, consent/approval controls, exact digest batching, durable deduplication and signed status webhooks.
- SQLite persistence, relevance feedback, backups/export, API authentication, Docker deployment recipe and automated tests.
- Six fictional demo notices that cannot be sent as live opportunities.

## Run

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.lock.txt
python -m uvicorn tenderwise.app:app --host 127.0.0.1 --port 8765 --no-proxy-headers
```

Open http://127.0.0.1:8765. API documentation is at `/docs`; supply `Authorization: Bearer <ADMIN_TOKEN>` for protected calls when configured.

## Design

```text
Allowed sources / uploaded documents
                 |
   Bounded extraction + source provenance
                 |
 Optional AI API or conservative labeled-field parser
                 |
 Verbatim evidence validation + date/currency checks
                 |
 SQLite records + document versions + company matching
                 |
 Human review -> exact bounded digest -> persistent outbox
                 |
 Official WhatsApp API -> signed delivery-status webhook
```

The UI is plain HTML/CSS/JavaScript with no external CDN or build step. Python/FastAPI serves both UI and API. APScheduler runs one daily job in the same server process. Use exactly one application worker when scheduling is enabled.

## AI approach

An API is a delivery mechanism for a pretrained model. Sending tender documents as context is not training. This application makes one structured extraction request per new document when configured. It has no browsing, file, shell or messaging tools available to the model. Python performs matching and delivery authorization.

Important facts need verified source excerpts. String values and requirements must appear in supporting quotations; unverified facts are removed. Amounts require explicit EGP context. Ambiguous dates, other currencies, multipliers and conflicting deadlines are left unknown. These checks reduce errors but do not establish the truth, completeness, legal meaning or freshness of a source. Risks remain draft decision support. Scoring is a heuristic, not model confidence or a bid-winning probability. Evidence confidence describes field coverage, not calibrated accuracy.

## Current boundaries

- No claim of all Egyptian tenders, a verified TenderEgypt connector, subscription access or permission to collect from a provider.
- Source adapters read public server-rendered content; they cannot bypass authentication, CAPTCHAs or website restrictions. Pagination and source-specific selectors require configuration/testing. Collection is capped at 25 records per source/run and does not guarantee full feed coverage.
- Scanned PDFs require OCR externally. Partial scanned pages are flagged. PDF parsing should be isolated for public multi-user deployments.
- AI reviews at most 60,000 extracted characters and explicitly flags truncation. This is not a complete BOQ costing, engineering design or financial feasibility model.
- Date-only deadlines are shown as calendar dates; the exact submission time must be checked. Unknown deadlines are excluded from open/live digests.
- Reports and documents require administrator authentication when enabled; no public report-sharing links are generated.
- Live WhatsApp needs your own Meta setup, recipient consent and an approved matching template. By default, opportunities need a fresh human approval. Turn off `require_human_review` in Automation for hands-free draft alerts from notices collected within 24 hours; unreviewed records are labeled as drafts. Fictional, rejected, closed, stale and already sent versions remain excluded. API acceptance is not delivery. Ambiguous delivery failures are not automatically retried; a definite provider rejection can be explicitly retried using `retry_failed:true` after correction.
- Each WhatsApp message contains a bounded mini-study: scope, deadline, location, stated bid security, fit/recommendation and a review point when available. Scheduled runs send at most `MAX_WHATSAPP_BATCHES_PER_RUN` messages (default 3; configurable 1–10). Omitted opportunities stay unsent for a later batch rather than being marked delivered.
- Local scheduling stops when the server is stopped. SQLite/single-worker design is intended for a family business or small pilot, not a multi-tenant service.

## Tests

```sh
python -m pip install -r requirements-dev.txt
python -m pytest -q
python -m tenderwise.evaluate
```

Tests are offline: provider responses and downloads are mocked. They verify application behavior, not live provider permissions, actual model quality or message delivery. The evaluation fixture is synthetic and is labeled accordingly. See `docs/PORTFOLIO.md` for a real-data evaluation protocol.

`requirements.lock.txt` records the runtime versions actually tested. `requirements.txt` provides compatible version ranges for development. The launcher uses the pinned versions by default.

## Configuration and deployment

Copy `.env.example` to `.env`, then restart after changes. Never commit `.env`, `data/` or backups containing your dad's private business information. `ADMIN_TOKEN` is required for non-loopback access. Runtime secrets stay server-side and are not returned by the API. Source URLs must not contain credentials. Use HTTPS and an appropriate reverse proxy for remote deployment.

- [Source configuration](docs/SOURCES.md)
- [WhatsApp setup](docs/WHATSAPP.md)
- [Deployment and persistent storage](docs/DEPLOYMENT.md)
- [Portfolio and evaluation](docs/PORTFOLIO.md)
- [Verification record](docs/VERIFICATION.md)

## Primary references

- [TenderEgypt plans](https://tenderegypt.com/plans): subscriptions, existing delivery services and document availability.
- [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs): structured response contracts; factual errors are still possible.
- [WhatsApp messaging policy](https://whatsappbusiness.com/policy/): consent, templates and customer-service windows.
- [World Bank opportunities](https://projects.worldbank.org/en/projects-operations/opportunities): current versus upcoming/potential opportunities.

No third-party tender documents or proprietary datasets are bundled. Demo content is invented. MIT licensed; see LICENSE.
